const fs = require('fs');
const docx = require('docx');
const {
  Document, Packer, Paragraph, TextRun,
  Header, Footer, AlignmentType, HeadingLevel,
  ExternalHyperlink, PageNumber, ShadingType,
  Table, TableRow, TableCell, WidthType,
} = docx;

const FONT = 'Calibri';
const COLOR_ACCENT = '01696F';
const COLOR_RED = 'A12C2C';
const COLOR_STAGE = '8B98A8';
const COLOR_GOLD = 'B8860B';

function heading(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 160 },
    children: [new TextRun({ text, bold: true, size: 32, font: FONT, color: COLOR_ACCENT })],
  });
}

function subheading(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 280, after: 120 },
    children: [new TextRun({ text, bold: true, size: 26, font: FONT, color: COLOR_RED })],
  });
}

function body(text) {
  return new Paragraph({
    spacing: { before: 40, after: 80, line: 380 },
    children: [new TextRun({ text, size: 22, font: FONT })],
  });
}

function bold(text) {
  return new Paragraph({
    spacing: { before: 40, after: 80, line: 380 },
    children: [new TextRun({ text, bold: true, size: 22, font: FONT })],
  });
}

function bullet(text) {
  return new Paragraph({
    spacing: { before: 30, after: 30, line: 360 },
    indent: { left: 720 },
    children: [
      new TextRun({ text: '\u2022  ', size: 22, font: FONT, color: COLOR_ACCENT }),
      new TextRun({ text, size: 22, font: FONT }),
    ],
  });
}

function step(num, title, text) {
  return [
    new Paragraph({
      spacing: { before: 200, after: 60 },
      children: [
        new TextRun({ text: `STEP ${num}: `, bold: true, size: 24, font: FONT, color: COLOR_ACCENT }),
        new TextRun({ text: title, bold: true, size: 24, font: FONT, color: COLOR_ACCENT }),
      ],
    }),
    new Paragraph({
      spacing: { before: 20, after: 80, line: 380 },
      indent: { left: 360 },
      children: [new TextRun({ text, size: 22, font: FONT })],
    }),
  ];
}

function note(text) {
  return new Paragraph({
    spacing: { before: 40, after: 80 },
    indent: { left: 720 },
    children: [new TextRun({ text: `\u2192 ${text}`, italics: true, size: 20, font: FONT, color: COLOR_STAGE })],
  });
}

function divider() {
  return new Paragraph({
    spacing: { before: 200, after: 200 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: '\u2014 \u2014 \u2014 \u2014 \u2014', color: COLOR_STAGE, size: 20 })],
  });
}

function makeCell(text, bold, color, fill) {
  return new TableCell({
    children: [new Paragraph({
      children: [new TextRun({ text, bold: bold || false, size: 20, font: FONT, color: color || '000000' })],
    })],
    shading: fill ? { fill, type: ShadingType.CLEAR } : undefined,
  });
}

const content = [
  // Cover
  new Paragraph({
    spacing: { before: 2000, after: 200 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'THE ENDICOTT EDGE', bold: true, size: 56, font: FONT, color: COLOR_ACCENT })],
  }),
  new Paragraph({
    spacing: { before: 0, after: 100 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'TRUTH \u2605 VERIFIED', bold: true, size: 28, font: FONT, color: COLOR_RED })],
  }),
  new Paragraph({
    spacing: { before: 200, after: 400 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'CapCut Production Workflow', size: 36, font: FONT, color: '555555' })],
  }),
  new Paragraph({
    spacing: { before: 100, after: 100 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'Step-by-step guide for editing and producing\nfour 35-40 minute podcast episodes', size: 22, font: FONT, color: COLOR_STAGE, italics: true })],
  }),

  // === OVERVIEW ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  heading('OVERVIEW'),
  body('This workflow covers two production tracks for each episode:'),
  bullet('PODCAST VERSION: Audio-only MP3 for Apple Podcasts, Spotify, and other podcast platforms.'),
  bullet('YOUTUBE VERSION: Full video MP4 with cover art, dashboard screenshots, image cues, and subtitles.'),
  body('Each episode follows the same 10-step workflow. Once you set up your first episode, the process repeats for all four.'),

  subheading('What You Need Before Starting'),
  bullet('Recorded episode audio (your raw recording from Audacity, GarageBand, or your recording software)'),
  bullet('Conversational podcast scripts (podcast-scripts-conversational.docx) — for stage directions, image cues, and timing'),
  bullet('Episode cover art (cover-ep1/2/3/4-v3-final.png) — for YouTube video thumbnails and image inserts'),
  bullet('YouTube thumbnails (youtube-thumb-ep1/2/3/4-final.png) — for YouTube upload'),
  bullet('Dashboard screenshots from https://iran-conflict-tracker.pplx.app — capture the timeline tab, economic tab, military tab, and analysis tab'),
  bullet('Intro/outro music (royalty-free track of your choice)'),
  bullet('CapCut installed on your computer (desktop version recommended for 35-40 min episodes)'),

  divider(),

  // === SETUP ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  heading('PROJECT SETUP (DO THIS ONCE)'),

  subheading('Create a Master Project Template'),
  body('Set up one project with your branding elements. You will duplicate this for each episode to save time.'),

  ...step(1, 'Create New Project', 'Open CapCut Desktop. Click "New Project." Set the aspect ratio to 16:9 (1920x1080) for YouTube production. You will export a separate audio-only MP3 for podcast platforms from the same timeline.'),

  ...step(2, 'Import Your Assets', 'Drag and drop all of the following into your media library:'),
  bullet('Your recorded episode audio (WAV or MP3)'),
  bullet('Episode cover art PNG file'),
  bullet('Dashboard screenshots (4-6 per episode — see Image Cue List below)'),
  bullet('Intro music track (MP3 or WAV)'),
  bullet('Outro music track (MP3 or WAV)'),
  bullet('Any sound effect files (air raid siren, jet engine, ticking clock, etc.)'),

  ...step(3, 'Set Up Your Tracks', 'Arrange your timeline with these track layers (top to bottom):'),
  bullet('Track 1 (Video): Episode cover art, dashboard screenshots, image cues'),
  bullet('Track 2 (Audio): Your recorded voice (main track)'),
  bullet('Track 3 (Audio): Intro/outro music'),
  bullet('Track 4 (Audio): Sound effects and transitions'),

  ...step(4, 'Save as Template', 'Once your tracks are set up and your music is placed, save the project as "EndicottEdge-Master-Template." Duplicate this file for each episode:'),
  bullet('EndicottEdge-Ep1-TheWarThatIsntAWar'),
  bullet('EndicottEdge-Ep2-EconomicDDay'),
  bullet('EndicottEdge-Ep3-CarriersAndCombat'),
  bullet('EndicottEdge-Ep4-TheReconciliation'),

  divider(),

  // === EDITING WORKFLOW ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  heading('EPISODE EDITING WORKFLOW (REPEAT FOR EACH EPISODE)'),

  subheading('Phase A: Audio Cleanup'),

  ...step(5, 'Import and Place Main Audio', 'Drag your recorded episode audio onto Track 2. This is your main timeline. Everything else syncs to this track.'),

  ...step(6, 'Clean Up the Audio', 'Go through the recording and edit for quality:'),
  bullet('Remove long pauses (anything over 2 seconds that feels unnatural) — use the Split tool (Ctrl+B or Cmd+B) to cut and delete'),
  bullet('Remove mistakes and retakes — split before and after the error, delete the bad take'),
  bullet('Remove filler words ("um," "uh," "like") if they break flow — but keep some for natural conversational feel'),
  bullet('Remove background noise: Select audio > Audio > Noise Reduction > Auto'),
  bullet('Normalize audio levels: Select all audio > Audio > Normalize (target: -3 dB peak)'),
  bullet('Apply compression: Audio > Effects > Dynamics > Compressor (ratio 3:1, threshold -18 dB) — this evens out your voice levels'),
  note('Keep the conversational feel. Your scripts are written in a natural tone — don\'t over-edit. A few "ums" and pauses make it sound authentic.'),

  ...step(7, 'Add Intro and Outro Music', 'Place your intro music at the start of Track 3:'),
  bullet('Intro music: 5-10 second sting, fade in over 1 second, fade out over 2 seconds as your voice begins'),
  bullet('Gap between intro music and your voice: 0.5 seconds (feels natural, not rushed)'),
  bullet('Outro music: 10-15 seconds, starts as you say your closing tagline, fade in over 2 seconds, fade out over 3 seconds at the end'),
  bullet('Duck the music: Set music track volume to -15 dB during any sections where music plays under your voice'),

  subheading('Phase B: Video Assembly (YouTube Version Only)'),

  ...step(8, 'Place Visual Elements', 'Add visual elements to Track 1, timed to your script\'s stage directions. Refer to your conversational script for [IMAGE: ...] cues. Here is the placement guide for each episode:'),

  // Image cue tables per episode
  subheading('Episode 1: "The War That Isn\'t a War" — Image Cues'),
  new Table({
    rows: [
      new TableRow({ children: [
        makeCell('Timestamp', true, 'FFFFFF', COLOR_ACCENT),
        makeCell('Visual', true, 'FFFFFF', COLOR_ACCENT),
        makeCell('Duration', true, 'FFFFFF', COLOR_ACCENT),
        makeCell('Source', true, 'FFFFFF', COLOR_ACCENT),
      ]}),
      new TableRow({ children: [
        makeCell('0:00', false),
        makeCell('Episode 1 cover art', false),
        makeCell('5 sec', false),
        makeCell('cover-ep1-v3-final.png', false),
      ]}),
      new TableRow({ children: [
        makeCell('2:00', false),
        makeCell('Operation Epic Fury dashboard (timeline tab)', false),
        makeCell('15 sec', false),
        makeCell('Dashboard screenshot', false),
      ]}),
      new TableRow({ children: [
        makeCell('10:00', false),
        makeCell('"Terminated" declaration — timeline entries May-Jun', false),
        makeCell('15 sec', false),
        makeCell('Dashboard screenshot', false),
      ]}),
      new TableRow({ children: [
        makeCell('18:00', false),
        makeCell('September statements (Rhetorical Shifts tab)', false),
        makeCell('15 sec', false),
        makeCell('Dashboard screenshot', false),
      ]}),
      new TableRow({ children: [
        makeCell('26:00', false),
        makeCell('Analysis tab — all 25 analysis points', false),
        makeCell('20 sec', false),
        makeCell('Dashboard screenshot', false),
      ]}),
      new TableRow({ children: [
        makeCell('34:00', false),
        makeCell('Episode 2 cover art (next episode preview)', false),
        makeCell('5 sec', false),
        makeCell('cover-ep2-v3-final.png', false),
      ]}),
    ],
    width: { size: 100, type: WidthType.PERCENTAGE },
  }),

  subheading('Episode 2: "Economic D-Day" — Image Cues'),
  new Table({
    rows: [
      new TableRow({ children: [
        makeCell('Timestamp', true, 'FFFFFF', COLOR_ACCENT),
        makeCell('Visual', true, 'FFFFFF', COLOR_ACCENT),
        makeCell('Duration', true, 'FFFFFF', COLOR_ACCENT),
        makeCell('Source', true, 'FFFFFF', COLOR_ACCENT),
      ]}),
      new TableRow({ children: [
        makeCell('0:00', false),
        makeCell('Episode 2 cover art', false),
        makeCell('5 sec', false),
        makeCell('cover-ep2-v3-final.png', false),
      ]}),
      new TableRow({ children: [
        makeCell('2:00', false),
        makeCell('Economic Pressure Tracker (Economic tab)', false),
        makeCell('15 sec', false),
        makeCell('Dashboard screenshot', false),
      ]}),
      new TableRow({ children: [
        makeCell('10:00', false),
        makeCell('Sanctions escalation timeline (timeline tab, filtered)', false),
        makeCell('15 sec', false),
        makeCell('Dashboard screenshot', false),
      ]}),
      new TableRow({ children: [
        makeCell('20:00', false),
        makeCell('Operation Economic Outcast — Treasury actions', false),
        makeCell('15 sec', false),
        makeCell('Dashboard screenshot', false),
      ]}),
      new TableRow({ children: [
        makeCell('28:00', false),
        makeCell('Analysis tab — economic/military gap', false),
        makeCell('20 sec', false),
        makeCell('Dashboard screenshot', false),
      ]}),
      new TableRow({ children: [
        makeCell('36:00', false),
        makeCell('Episode 3 cover art (next episode preview)', false),
        makeCell('5 sec', false),
        makeCell('cover-ep3-v3-final.png', false),
      ]}),
    ],
    width: { size: 100, type: WidthType.PERCENTAGE },
  }),

  subheading('Episode 3: "Carriers and Combat" — Image Cues'),
  new Table({
    rows: [
      new TableRow({ children: [
        makeCell('Timestamp', true, 'FFFFFF', COLOR_ACCENT),
        makeCell('Visual', true, 'FFFFFF', COLOR_ACCENT),
        makeCell('Duration', true, 'FFFFFF', COLOR_ACCENT),
        makeCell('Source', true, 'FFFFFF', COLOR_ACCENT),
      ]}),
      new TableRow({ children: [
        makeCell('0:00', false),
        makeCell('Episode 3 cover art', false),
        makeCell('5 sec', false),
        makeCell('cover-ep3-v3-final.png', false),
      ]}),
      new TableRow({ children: [
        makeCell('2:00', false),
        makeCell('Operation Epic Fury — military ops tab', false),
        makeCell('15 sec', false),
        makeCell('Dashboard screenshot', false),
      ]}),
      new TableRow({ children: [
        makeCell('10:00', false),
        makeCell('Carrier build-up — Carrier Presence tab', false),
        makeCell('15 sec', false),
        makeCell('Dashboard screenshot', false),
      ]}),
      new TableRow({ children: [
        makeCell('18:00', false),
        makeCell('Strike timeline (Military Operations tab)', false),
        makeCell('15 sec', false),
        makeCell('Dashboard screenshot', false),
      ]}),
      new TableRow({ children: [
        makeCell('28:00', false),
        makeCell('USS Abraham Lincoln 264-day deployment', false),
        makeCell('15 sec', false),
        makeCell('Dashboard screenshot', false),
      ]}),
      new TableRow({ children: [
        makeCell('36:00', false),
        makeCell('Episode 4 cover art (next episode preview)', false),
        makeCell('5 sec', false),
        makeCell('cover-ep4-v3-final.png', false),
      ]}),
    ],
    width: { size: 100, type: WidthType.PERCENTAGE },
  }),

  subheading('Episode 4: "The Reconciliation" — Image Cues'),
  new Table({
    rows: [
      new TableRow({ children: [
        makeCell('Timestamp', true, 'FFFFFF', COLOR_ACCENT),
        makeCell('Visual', true, 'FFFFFF', COLOR_ACCENT),
        makeCell('Duration', true, 'FFFFFF', COLOR_ACCENT),
        makeCell('Source', true, 'FFFFFF', COLOR_ACCENT),
      ]}),
      new TableRow({ children: [
        makeCell('0:00', false),
        makeCell('Episode 4 cover art', false),
        makeCell('5 sec', false),
        makeCell('cover-ep4-v3-final.png', false),
      ]}),
      new TableRow({ children: [
        makeCell('2:00', false),
        makeCell('Rhetorical Shifts tab — all declaratory statements', false),
        makeCell('15 sec', false),
        makeCell('Dashboard screenshot', false),
      ]}),
      new TableRow({ children: [
        makeCell('12:00', false),
        makeCell('Military Operations + Carrier Presence tabs', false),
        makeCell('15 sec', false),
        makeCell('Dashboard screenshot', false),
      ]}),
      new TableRow({ children: [
        makeCell('22:00', false),
        makeCell('Economic Pressure Tracker tab', false),
        makeCell('15 sec', false),
        makeCell('Dashboard screenshot', false),
      ]}),
      new TableRow({ children: [
        makeCell('30:00', false),
        makeCell('Analysis tab — full gap analysis (all 25 points)', false),
        makeCell('20 sec', false),
        makeCell('Dashboard screenshot', false),
      ]}),
      new TableRow({ children: [
        makeCell('38:00', false),
        makeCell('Dashboard URL on screen + "Truth Verified" closing card', false),
        makeCell('10 sec', false),
        makeCell('Text overlay in CapCut', false),
      ]}),
    ],
    width: { size: 100, type: WidthType.PERCENTAGE },
  }),

  ...step(9, 'Add Transitions and Effects', 'Between each visual element on Track 1, add smooth transitions:'),
  bullet('Default transition: Cross dissolve (0.5 seconds) between dashboard screenshots'),
  bullet('Cover art to screenshot: Fade to black (0.3 sec), then fade in new image'),
  bullet('Screenshot back to cover art: Cross dissolve (0.5 sec)'),
  bullet('Ken Burns effect: Select image > Video > Zoom (slow zoom in over the display duration) — adds subtle motion to static screenshots'),
  bullet('Text overlay: Add "The Endicott Edge" watermark in bottom-right corner of all screenshots (white text, 30% opacity, font: Montserrat or Arial)'),

  subheading('Phase C: Sound Effects'),
  body('Your scripts include stage directions for sound effects. Add these on Track 4:'),
  bullet('Air raid siren: When discussing Operation Epic Fury opening strikes'),
  bullet('Jet engine sound: When discussing aircraft carrier operations'),
  bullet('Ticking clock: When discussing the gap between "terminated" and continued operations'),
  bullet('News broadcast sting: When quoting official statements'),
  bullet('Whoosh transition: Between major segment changes'),
  note('Keep all sound effects at -20 dB or lower. They should support the narrative, not distract from your voice.'),

  subheading('Phase D: Subtitles and Captions'),

  ...step(10, 'Generate Auto-Captions', 'CapCut can auto-generate subtitles from your audio:'),
  bullet('Click Text > Auto Captions'),
  bullet('Select English (US)'),
  bullet('Let CapCut process the full episode (this takes 2-5 minutes for a 35-40 min episode)'),
  bullet('Review and correct any errors — especially names: Hegseth, Caine, CENTCOM, IRGC, Abraham Lincoln, Theodore Roosevelt'),
  bullet('Style the captions: White text, black outline (2px), bottom-center, font size 24, font: Arial or Calibri'),
  bullet('Export captions as SRT file (for YouTube upload as a separate caption file)'),

  divider(),

  // === EXPORT ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  heading('EXPORT SETTINGS'),

  subheading('Podcast Audio Export (MP3)'),
  body('Export from the same project — CapCut will export just the audio tracks.'),
  new Table({
    rows: [
      new TableRow({ children: [
        makeCell('Setting', true, 'FFFFFF', COLOR_ACCENT),
        makeCell('Value', true, 'FFFFFF', COLOR_ACCENT),
      ]}),
      new TableRow({ children: [makeCell('Format', false), makeCell('MP3', false)] }),
      new TableRow({ children: [makeCell('Bitrate', false), makeCell('192 kbps', false)] }),
      new TableRow({ children: [makeCell('Sample Rate', false), makeCell('44100 Hz', false)] }),
      new TableRow({ children: [makeCell('Channels', false), makeCell('Stereo', false)] }),
      new TableRow({ children: [makeCell('Loudness', false), makeCell('-16 LUFS (podcast standard)', false)] }),
      new TableRow({ children: [makeCell('File Name', false), makeCell('EndicottEdge-Ep[N]-[Title].mp3', false)] }),
    ],
    width: { size: 100, type: WidthType.PERCENTAGE },
  }),

  subheading('YouTube Video Export (MP4)'),
  new Table({
    rows: [
      new TableRow({ children: [
        makeCell('Setting', true, 'FFFFFF', COLOR_ACCENT),
        makeCell('Value', true, 'FFFFFF', COLOR_ACCENT),
      ]}),
      new TableRow({ children: [makeCell('Format', false), makeCell('MP4 (H.264)', false)] }),
      new TableRow({ children: [makeCell('Resolution', false), makeCell('1920 x 1080 (Full HD)', false)] }),
      new TableRow({ children: [makeCell('Frame Rate', false), makeCell('30 fps', false)] }),
      new TableRow({ children: [makeCell('Bitrate', false), makeCell('8-10 Mbps (or Auto)', false)] }),
      new TableRow({ children: [makeCell('Audio Bitrate', false), makeCell('192 kbps AAC', false)] }),
      new TableRow({ children: [makeCell('Audio Sample Rate', false), makeCell('44100 Hz', false)] }),
      new TableRow({ children: [makeCell('Loudness', false), makeCell('-14 LUFS (YouTube standard)', false)] }),
      new TableRow({ children: [makeCell('File Name', false), makeCell('EndicottEdge-Ep[N]-[Title].mp4', false)] }),
    ],
    width: { size: 100, type: WidthType.PERCENTAGE },
  }),

  note('If your episode runs long (close to 40 minutes), the MP4 file will be 1-2 GB. This is normal for 1080p. YouTube handles files up to 256 GB.'),

  divider(),

  // === PRODUCTION SCHEDULE ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  heading('PRODUCTION SCHEDULE'),

  body('Estimated time per episode using this workflow:'),

  new Table({
    rows: [
      new TableRow({ children: [
        makeCell('Task', true, 'FFFFFF', COLOR_ACCENT),
        makeCell('Estimated Time', true, 'FFFFFF', COLOR_ACCENT),
      ]}),
      new TableRow({ children: [makeCell('Audio cleanup (pauses, mistakes, noise)', false), makeCell('1-2 hours', false)] }),
      new TableRow({ children: [makeCell('Audio leveling and compression', false), makeCell('30 min', false)] }),
      new TableRow({ children: [makeCell('Adding intro/outro music', false), makeCell('15 min', false)] }),
      new TableRow({ children: [makeCell('Adding sound effects', false), makeCell('30 min', false)] }),
      new TableRow({ children: [makeCell('Placing visual elements (Track 1)', false), makeCell('30-45 min', false)] }),
      new TableRow({ children: [makeCell('Adding transitions and Ken Burns', false), makeCell('30 min', false)] }),
      new TableRow({ children: [makeCell('Generating and correcting captions', false), makeCell('45-60 min', false)] }),
      new TableRow({ children: [makeCell('Exporting audio (MP3)', false), makeCell('10 min', false)] }),
      new TableRow({ children: [makeCell('Exporting video (MP4)', false), makeCell('15-30 min', false)] }),
      new TableRow({ children: [makeCell('TOTAL PER EPISODE', true, COLOR_ACCENT), makeCell('4-6 hours', true, COLOR_ACCENT)] }),
    ],
    width: { size: 100, type: WidthType.PERCENTAGE },
  }),

  body(''),
  bold('Full series production estimate: 16-24 hours across 4 episodes.'),
  body(''),
  body('Recommended approach: Edit one episode per day over 4 days. Do not rush — quality matters more than speed for a podcast series launch.'),

  divider(),

  // === UPLOAD ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  heading('POST-EXPORT: UPLOAD GUIDE'),

  subheading('Podcast Upload (to your podcast host)'),
  bullet('Log in to your podcast hosting platform (Buzzsprout, Podbean, Libsyn, or Spotify for Podcasters)'),
  bullet('Upload the MP3 file'),
  bullet('Set episode title (from show-descriptions-plain.txt)'),
  bullet('Copy/paste the podcast description from show-descriptions-plain.txt'),
  bullet('Upload the episode cover art (cover-ep[N]-v3-final.png)'),
  bullet('Set episode number and season (Season 1, Episodes 1-4)'),
  bullet('Schedule or publish immediately'),

  subheading('YouTube Upload'),
  bullet('Go to YouTube Studio > Create > Upload Video'),
  bullet('Upload the MP4 file'),
  bullet('Set video title (from show-descriptions-plain.txt — YouTube version)'),
  bullet('Copy/paste the YouTube description (with timestamps and hashtags)'),
  bullet('Upload the YouTube thumbnail (youtube-thumb-ep[N]-final.png)'),
  bullet('Upload the SRT caption file (Subtitles > Add > Upload file)'),
  bullet('Set visibility to Scheduled or Public'),
  bullet('Add to playlist: "Mixed Messages: The Iran Conflict"'),

  subheading('Dashboard Screenshots — How to Capture'),
  body('For the image cues listed above, take screenshots of your live dashboard at https://iran-conflict-tracker.pplx.app:'),
  bullet('Full Timeline tab: Open dashboard > click "Full Timeline" tab > screenshot'),
  bullet('Rhetorical Shifts: Open dashboard > click "Rhetorical Shifts" > screenshot'),
  bullet('Economic Pressure Tracker: Open dashboard > click "Economic Pressure" > screenshot'),
  bullet('Military Operations: Open dashboard > click "Military Operations" > screenshot'),
  bullet('Carrier Presence: Open dashboard > click "Carrier Presence" > screenshot'),
  bullet('Analysis: Open dashboard > click "Analysis" > screenshot'),
  note('Take screenshots at 1920x1080 resolution for best quality in your video. On Mac: Cmd+Shift+4, drag to select. On Windows: Win+Shift+S.'),

  divider(),

  // === TIPS ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  heading('PRODUCTION TIPS'),

  subheading('Audio Quality'),
  bullet('Record in a quiet room with soft surfaces (carpet, curtains, blankets) to reduce echo'),
  bullet('Use a pop filter on your microphone to reduce plosives ("p" and "b" sounds)'),
  bullet('Record at a consistent distance from the microphone (about 6 inches)'),
  bullet('Export your raw recording as WAV (uncompressed) before importing into CapCut'),

  subheading('Editing Efficiency'),
  bullet('Edit in 15-minute sessions — take a 5-minute break between sessions to keep your ears fresh'),
  bullet('Use keyboard shortcuts: Split (Ctrl+B/Cmd+B), Delete (Backspace), Undo (Ctrl+Z/Cmd+Z)'),
  bullet('Mark sections with CapCut\'s markers feature as you go through the script'),
  bullet('Edit the first episode completely before starting Episode 2 — you\'ll develop a rhythm'),

  subheading('Backup'),
  bullet('Save your CapCut project after each editing session'),
  bullet('Keep raw recordings in a separate folder: "EndicottEdge/Raw Recordings/"'),
  bullet('Keep exported files in: "EndicottEdge/Exports/"'),
  bullet('Back up everything to cloud storage (Google Drive, iCloud, Dropbox) after each episode is complete'),

  divider(),

  new Paragraph({
    spacing: { before: 400, after: 200 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'Truth Verified.', size: 28, font: FONT, color: COLOR_ACCENT, bold: true })],
  }),
  new Paragraph({
    spacing: { before: 0, after: 400 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'The Endicott Edge', size: 22, font: FONT, color: COLOR_STAGE, italics: true })],
  }),
];

const doc = new Document({
  styles: {
    default: { document: { run: { font: FONT, size: 22 } } },
    paragraphStyles: [
      {
        id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 32, bold: true, font: FONT, color: COLOR_ACCENT },
        paragraph: { spacing: { before: 360, after: 160 }, outlineLevel: 0 },
      },
      {
        id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 26, bold: true, font: FONT, color: COLOR_RED },
        paragraph: { spacing: { before: 280, after: 120 }, outlineLevel: 1 },
      },
    ],
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1080, right: 1080, bottom: 1080, left: 1080 },
      },
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({ text: 'The Endicott Edge \u2014 CapCut Production Workflow', italics: true, color: '999999', size: 16, font: FONT })],
        })],
      }),
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({ text: 'Page ', size: 16, font: FONT, color: '999999' }),
            new TextRun({ children: [PageNumber.CURRENT], size: 16, font: FONT, color: '999999' }),
            new TextRun({ text: ' of ', size: 16, font: FONT, color: '999999' }),
            new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 16, font: FONT, color: '999999' }),
          ],
        })],
      }),
    },
    children: content,
  }],
});

(async () => {
  const buf = await Packer.toBuffer(doc);
  fs.writeFileSync('/home/user/workspace/iran-dashboard/capcut-workflow.docx', buf);
  console.log('CapCut workflow generated');
})();
