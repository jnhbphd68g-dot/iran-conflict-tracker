const fs = require('fs');
const docx = require('docx');
const {
  Document, Packer, Paragraph, TextRun,
  Header, Footer, AlignmentType, HeadingLevel,
  ExternalHyperlink, PageNumber,
} = docx;

const FONT = 'Calibri';
const COLOR_ACCENT = '01696F';
const COLOR_RED = 'A12C2C';
const COLOR_STAGE = '8B98A8';
const COLOR_SOURCE = '5A6878';

function heading(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 160 },
    children: [new TextRun({ text, bold: true, size: 32, font: FONT, color: COLOR_ACCENT })],
  });
}

function subheading(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 280, after: 120 },
    children: [new TextRun({ text, bold: true, size: 26, font: FONT, color: COLOR_RED })],
  });
}

function label(text) {
  return new Paragraph({
    spacing: { before: 120, after: 60 },
    children: [new TextRun({ text, bold: true, size: 22, font: FONT, color: COLOR_ACCENT })],
  });
}

function body(text) {
  return new Paragraph({
    spacing: { before: 40, after: 80, line: 380 },
    children: [new TextRun({ text, size: 22, font: FONT })],
  });
}

function italic(text) {
  return new Paragraph({
    spacing: { before: 40, after: 80, line: 380 },
    children: [new TextRun({ text, italics: true, size: 22, font: FONT, color: COLOR_STAGE })],
  });
}

function divider() {
  return new Paragraph({
    spacing: { before: 200, after: 200 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: '\u2014 \u2014 \u2014 \u2014 \u2014', color: COLOR_STAGE, size: 20 })],
  });
}

function link(text, url) {
  return new Paragraph({
    spacing: { before: 40, after: 80 },
    children: [
      new ExternalHyperlink({
        children: [new TextRun({ text, style: 'Hyperlink', size: 22 })],
        link: url,
      }),
    ],
  });
}

const content = [
  // Cover
  new Paragraph({
    spacing: { before: 2000, after: 200 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'THE ENDICOTT EDGE', bold: true, size: 56, font: FONT, color: COLOR_ACCENT })],
  }),
  new Paragraph({
    spacing: { before: 0, after: 100 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'TRUTH \u2605 VERIFIED', bold: true, size: 28, font: FONT, color: COLOR_RED })],
  }),
  new Paragraph({
    spacing: { before: 200, after: 400 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'Show & Episode Descriptions', size: 36, font: FONT, color: '555555' })],
  }),
  new Paragraph({
    spacing: { before: 200, after: 100 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'Ready to copy and paste into Apple Podcasts, Spotify,\nYouTube, and social media', size: 22, font: FONT, color: COLOR_STAGE, italics: true })],
  }),

  // === SHOW DESCRIPTION ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  heading('SHOW DESCRIPTION'),
  italic('Use this for your podcast host (Buzzsprout, Podbean, etc.), Apple Podcasts, Spotify, and YouTube channel description.'),

  label('Short Version (for Apple Podcasts \u2014 4000 character limit)'),
  body('The White House says the war is "taken care of." The Pentagon says it will "continue major combat operations." Both can\'t be right.'),
  body('The Endicott Edge breaks down the gap between what politicians say and what the government actually does. We track every statement, every vote, and every policy shift \u2014 then map them against the facts. No spin. No party lines. Just the data, the documents, and the truth.'),
  body('Hosted from Orlando, Florida, The Endicott Edge is a political podcast for people who are tired of being told what to think and ready to see the evidence for themselves.'),
  body('Truth Verified.'),
  body(''),
  body('CURRENT SERIES: Mixed Messages \u2014 The Iran Conflict'),
  body('A 4-episode deep dive into the 2026 Iran conflict. We tracked 52 timeline events \u2014 every statement, every strike, every sanction \u2014 from Operation Epic Fury in February to the September declarations of peace. Every quote cited. Every date verified. Every source linked to official government publications.'),
  body('The full interactive dashboard: https://iran-conflict-tracker.pplx.app'),
  body(''),
  body('Follow The Endicott Edge:'),
  new Paragraph({
    spacing: { before: 40, after: 40, line: 380 },
    children: [
      new TextRun({ text: 'Twitter/X: ', size: 22, font: FONT }),
      new ExternalHyperlink({ children: [new TextRun({ text: '@TheEndicottEdge', style: 'Hyperlink', size: 22 })], link: 'https://twitter.com/TheEndicottEdge' }),
    ],
  }),
  new Paragraph({
    spacing: { before: 40, after: 40, line: 380 },
    children: [
      new TextRun({ text: 'Instagram: ', size: 22, font: FONT }),
      new ExternalHyperlink({ children: [new TextRun({ text: '@TheEndicottEdge', style: 'Hyperlink', size: 22 })], link: 'https://instagram.com/TheEndicottEdge' }),
    ],
  }),
  new Paragraph({
    spacing: { before: 40, after: 40, line: 380 },
    children: [
      new TextRun({ text: 'Facebook: ', size: 22, font: FONT }),
      new ExternalHyperlink({ children: [new TextRun({ text: '@TheEndicottEdge', style: 'Hyperlink', size: 22 })], link: 'https://facebook.com/TheEndicottEdge' }),
    ],
  }),
  new Paragraph({
    spacing: { before: 40, after: 40, line: 380 },
    children: [
      new TextRun({ text: 'LinkedIn: ', size: 22, font: FONT }),
      new ExternalHyperlink({ children: [new TextRun({ text: '@TheEndicottEdge', style: 'Hyperlink', size: 22 })], link: 'https://linkedin.com/company/TheEndicottEdge' }),
    ],
  }),
  new Paragraph({
    spacing: { before: 40, after: 40, line: 380 },
    children: [
      new TextRun({ text: 'YouTube: ', size: 22, font: FONT }),
      new ExternalHyperlink({ children: [new TextRun({ text: '@TheEndicottEdge', style: 'Hyperlink', size: 22 })], link: 'https://youtube.com/@TheEndicottEdge' }),
    ],
  }),
  body(''),
  body('Real Talk. Real Strategies. Real Results.'),
  body('Truth \u2605 Verified'),

  divider(),

  // === EPISODE 1 ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  heading('EPISODE 1: "THE WAR THAT ISN\'T A WAR"'),

  label('Podcast Description (Apple Podcasts / Spotify)'),

  body('The White House says the war is "terminated." The Pentagon says it will "continue major combat operations." Two carriers patrol the Arabian Sea. Fifty thousand troops remain deployed.'),
  body(''),
  body('Both can\'t be right.'),
  body(''),
  body('In Episode 1 of Mixed Messages: The Iran Conflict, we trace the rhetorical arc \u2014 from Operation Epic Fury\'s 100-aircraft opening salvo in February to the September declarations that the war is "taken care of." We map every statement from the White House, the Pentagon, and CENTCOM against what the military was actually doing on the ground. The gap is undeniable.'),
  body(''),
  body('On February 28, 2026, the U.S. launched Operation Epic Fury \u2014 more than 100 aircraft striking more than 1,000 targets in 24 hours. By May 1st, the President declared the war "terminated." But CENTCOM conducted four rounds of strikes in July alone. On September 5th and 8th, there were two naval engagements between U.S. forces and the IRGC. And the Vice President said: "The U.S. is not at war at all."'),
  body(''),
  body('Every quote cited. Every date verified. Every source linked.'),
  body(''),
  body('Full interactive dashboard: https://iran-conflict-tracker.pplx.app'),
  body(''),
  body('The Endicott Edge | Truth Verified'),

  label('YouTube Description'),
  body('The White House says the war is "terminated." The Pentagon says it will "continue major combat operations." Both can\'t be right.'),
  body(''),
  body('In Episode 1 of Mixed Messages: The Iran Conflict, The Endicott Edge traces the rhetorical arc \u2014 from "only just begun" to "terminated" to "taken care of" \u2014 and maps it against what the military was actually doing the entire time. The gap is undeniable.'),
  body(''),
  body('Sources cited in this episode:'),
  body('\u2022 Defense.gov \u2014 Operation Epic Fury briefing (Feb 28)'),
  body('\u2022 Defense.gov Transcript \u2014 Hegseth/Caine press briefing (Mar 19)'),
  body('\u2022 White House Statements \u2014 "Terminated" declaration (May 1)'),
  body('\u2022 CENTCOM News Releases \u2014 Strikes (Jul 7, 8, 13, 20)'),
  body('\u2022 CBS News \u2014 VP Vance "not at war" (Sep 10)'),
  body('\u2022 White House Statements \u2014 "Taken care of" (Sep 17)'),
  body(''),
  body('Full interactive dashboard with 52 timeline events: https://iran-conflict-tracker.pplx.app'),
  body(''),
  body('\u25B6 TIMESTAMPS:'),
  body('0:00 \u2014 Cold Open'),
  body('2:00 \u2014 The Opening Salvo (Operation Epic Fury)'),
  body('10:00 \u2014 The Great Pivot ("Terminated")'),
  body('18:00 \u2014 The September Denial'),
  body('26:00 \u2014 The Core Analysis'),
  body('34:00 \u2014 Closing & Next Episode Preview'),
  body(''),
  body('\u2014\u2014\u2014'),
  body('The Endicott Edge | Truth Verified'),
  body('Real Talk. Real Strategies. Real Results.'),
  body(''),
  body('#IranConflict #ForeignPolicy #NationalSecurity #PoliticalPodcast #CENTCOM #Pentagon #WhiteHouse #Podcast #GovernmentAccountability #TheEndicottEdge'),

  divider(),

  // === EPISODE 2 ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  heading('EPISODE 2: "ECONOMIC D-DAY"'),

  label('Podcast Description (Apple Podcasts / Spotify)'),

  body('The Treasury Secretary compared a sanctions campaign to D-Day. The White House said the war was "terminated." Four months apart.'),
  body(''),
  body('In Episode 2 of Mixed Messages: The Iran Conflict, we follow the money. While the White House was telling you the war was over, the Treasury Department was just getting started \u2014 launching an "economic D-Day" that targeted five vital sectors of the Iranian economy simultaneously.'),
  body(''),
  body('We trace eleven documented economic actions \u2014 from Executive Order 14382 in February (25% tariffs on anyone trading with Iran) to Operation Economic Outcast in August ("economic D-Day") to H.R. 5334 signed into law in September. Over 1,000 entities sanctioned. A shadow fleet of tankers targeted. An IRGC extortion scheme in the Strait of Hormuz disrupted.'),
  body(''),
  body('The economic war escalated while the military rhetoric de-escalated. Good cop, bad cop \u2014 and the bad cop has the Treasury Department\'s bank account.'),
  body(''),
  body('Every action cited. Every date verified. Every source linked.'),
  body(''),
  body('Full interactive dashboard: https://iran-conflict-tracker.pplx.app'),
  body(''),
  body('The Endicott Edge | Truth Verified'),

  label('YouTube Description'),
  body('The Treasury Secretary called it "economic D-Day." The White House said the war was "terminated." Both happened. Four months apart.'),
  body(''),
  body('In Episode 2 of Mixed Messages: The Iran Conflict, The Endicott Edge follows the money \u2014 tracing 11 economic actions from Executive Order 14382 to H.R. 5334 signed into law. Over 1,000 entities sanctioned. Five economic sectors targeted simultaneously. An IRGC extortion scheme in the Strait of Hormuz disrupted. All while the White House declared peace.'),
  body(''),
  body('Sources cited in this episode:'),
  body('\u2022 White House \u2014 Executive Order 14382 (Feb 6)'),
  body('\u2022 U.S. Department of State \u2014 Shadow fleet sanctions (Feb 6)'),
  body('\u2022 Treasury Department \u2014 OFAC sanctions, 35 entities (Apr 28)'),
  body('\u2022 Treasury Department \u2014 Operation Economic Fury (Jun 10)'),
  body('\u2022 Treasury Department \u2014 IRGC Hormuz extortion scheme (Jul 29)'),
  body('\u2022 Treasury Department \u2014 Operation Economic Outcast (Aug 24)'),
  body('\u2022 White House \u2014 H.R. 5334 signed into law (Sep 18)'),
  body(''),
  body('Full interactive dashboard: https://iran-conflict-tracker.pplx.app'),
  body(''),
  body('\u25B6 TIMESTAMPS:'),
  body('0:00 \u2014 Cold Open'),
  body('2:00 \u2014 The First Strike (Before the Bombs)'),
  body('10:00 \u2014 The Escalation Ladder'),
  body('20:00 \u2014 The D-Day Itself'),
  body('28:00 \u2014 What It All Means'),
  body('36:00 \u2014 Closing & Next Episode Preview'),
  body(''),
  body('\u2014\u2014\u2014'),
  body('The Endicott Edge | Truth Verified'),
  body('Real Talk. Real Strategies. Real Results.'),
  body(''),
  body('#Sanctions #EconomicWarfare #IranConflict #OFAC #Treasury #ForeignPolicy #PoliticalPodcast #GovernmentAccountability #TheEndicottEdge #Podcast'),

  divider(),

  // === EPISODE 3 ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  heading('EPISODE 3: "CARRIERS AND COMBAT"'),

  label('Podcast Description (Apple Podcasts / Spotify)'),

  body('264 days at sea. 1.5 million pounds of ordnance. The longest carrier deployment since Vietnam. In a war that\'s "taken care of."'),
  body(''),
  body('In Episode 3 of Mixed Messages: The Iran Conflict, we follow the carriers. Because you can spin a press release. You can write a speech. But you can\'t hide a 100,000-ton aircraft carrier.'),
  body(''),
  body('We trace thirteen documented military operations \u2014 from Operation Epic Fury\'s 100-aircraft opening salvo, to the submarine torpedo attack off Sri Lanka (the first since World War II), to the CENTCOM strike timeline, to the presidentially directed blockade of Iranian ports. Two carriers remained on station in the Arabian Sea. The USS Abraham Lincoln spent 264 consecutive days at sea without a port call. And the USS Theodore Roosevelt is preparing to deploy for seven months \u2014 taking us into 2027.'),
  body(''),
  body('The most powerful navy in the history of the world, with three carriers in the region, couldn\'t put one inside the Persian Gulf. That tells you about the threat environment.'),
  body(''),
  body('Every operation cited. Every date verified. Every source linked.'),
  body(''),
  body('Full interactive dashboard: https://iran-conflict-tracker.pplx.app'),
  body(''),
  body('The Endicott Edge | Truth Verified'),

  label('YouTube Description'),
  body('264 days at sea. 1.5 million pounds of ordnance. The longest carrier deployment since Vietnam. In a war that\'s "taken care of."'),
  body(''),
  body('In Episode 3 of Mixed Messages: The Iran Conflict, The Endicott Edge follows the carriers \u2014 because you can spin a press release, but you can\'t hide a 100,000-ton aircraft carrier. Thirteen documented military operations. A submarine torpedo attack. A presidentially directed blockade. All in a war that\'s "not at war at all."'),
  body(''),
  body('Sources cited in this episode:'),
  body('\u2022 Defense.gov \u2014 Operation Epic Fury briefing (Feb 28)'),
  body('\u2022 Defense.gov Transcript \u2014 Hegseth/Caine (Mar 19)'),
  body('\u2022 CENTCOM News Releases \u2014 Strikes (Jul 7, 8, 13, 20)'),
  body('\u2022 CENTCOM \u2014 Naval targets (Sep 1)'),
  body('\u2022 CBS News \u2014 Naval engagements (Sep 5-8)'),
  body('\u2022 USNI News Fleet Tracker \u2014 Carrier deployments (Sep 14)'),
  body('\u2022 CENTCOM SASC Posture Statement \u2014 Blockade confirmation'),
  body('\u2022 The Atlantic \u2014 Navy as silent partner (Sep 7)'),
  body(''),
  body('Full interactive dashboard: https://iran-conflict-tracker.pplx.app'),
  body(''),
  body('\u25B6 TIMESTAMPS:'),
  body('0:00 \u2014 Cold Open'),
  body('2:00 \u2014 Operation Epic Fury: The First 24 Hours'),
  body('10:00 \u2014 The Carrier Build-Up'),
  body('18:00 \u2014 The Strike Timeline'),
  body('28:00 \u2014 The Abraham Lincoln & The Long War'),
  body('36:00 \u2014 Closing & Next Episode Preview'),
  body(''),
  body('\u2014\u2014\u2014'),
  body('The Endicott Edge | Truth Verified'),
  body('Real Talk. Real Strategies. Real Results.'),
  body(''),
  body('#USNavy #AircraftCarrier #CENTCOM #MilitaryOperations #IranConflict #NationalSecurity #PoliticalPodcast #DefensePolicy #TheEndicottEdge #Podcast'),

  divider(),

  // === EPISODE 4 ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  heading('EPISODE 4: "THE RECONCILIATION"'),

  label('Podcast Description (Apple Podcasts / Spotify)'),

  body('The gap between rhetoric and reality is the story of this conflict. Series finale.'),
  body(''),
  body('In Episode 4 of Mixed Messages: The Iran Conflict, we bring it all together. Over four episodes, we tracked 52 timeline events, 11 economic actions, 13 military operations, and 25 analysis points \u2014 all cited to official government sources. Now we answer the one question that matters: can declaratory policy and observed force posture ever be reconciled?'),
  body(''),
  body('The White House says "terminated." The Pentagon says "continue major combat operations." The Treasury launches an "economic D-Day." Congress extends sanctions into law. And 50,000 troops remain deployed with two carriers in the Arabian Sea. This isn\'t a difference of opinion. It\'s institutional awareness of a sustained conflict that the political leadership declines to acknowledge.'),
  body(''),
  body('Former Defense Secretary Leon Panetta assessed the war would continue through March 2027. The operational data supports that assessment. The carrier deployment timeline supports it. The CENTCOM strike data supports it. The only person who doesn\'t support it is the President.'),
  body(''),
  body('The operational reality will persist regardless of the declaratory policy. The war is not over. The war continues.'),
  body(''),
  body('Full interactive dashboard: https://iran-conflict-tracker.pplx.app'),
  body(''),
  body('The Endicott Edge | Truth Verified'),

  label('YouTube Description'),
  body('The gap between rhetoric and reality is the story of this conflict. Series finale.'),
  body(''),
  body('In Episode 4 of Mixed Messages: The Iran Conflict, The Endicott Edge brings it all together \u2014 52 timeline events, 11 economic actions, 13 military operations, and 25 analysis points. Can declaratory policy and observed force posture ever be reconciled?'),
  body(''),
  body('Sources cited in this episode:'),
  body('\u2022 Defense.gov \u2014 Operation Epic Fury briefing (Feb 28)'),
  body('\u2022 Defense.gov Transcript \u2014 Hegseth/Caine (Mar 19)'),
  body('\u2022 White House Statements \u2014 "Terminated" (May 1), "Taken care of" (Sep 17)'),
  body('\u2022 CBS News \u2014 VP Vance "not at war" (Sep 10)'),
  body('\u2022 Treasury Department \u2014 Operation Economic Outcast (Aug 24)'),
  body('\u2022 White House \u2014 H.R. 5334 signed into law (Sep 18)'),
  body('\u2022 USNI News Fleet Tracker \u2014 Carrier posture (Sep 14)'),
  body('\u2022 CENTCOM SASC Posture Statement \u2014 Blockade'),
  body('\u2022 The Guardian \u2014 Leon Panetta interview (Sep 6)'),
  body('\u2022 CNN \u2014 Pentagon memo report (Sep 15)'),
  body('\u2022 The Atlantic \u2014 Navy coverage (Sep 7)'),
  body(''),
  body('Full interactive dashboard: https://iran-conflict-tracker.pplx.app'),
  body(''),
  body('\u25B6 TIMESTAMPS:'),
  body('0:00 \u2014 Cold Open'),
  body('2:00 \u2014 What They Said (Declaratory Policy)'),
  body('12:00 \u2014 What They Did (Force Posture)'),
  body('22:00 \u2014 The Hegseth-Caine Transcript'),
  body('30:00 \u2014 The Gap and What It Means'),
  body('38:00 \u2014 Series Closing'),
  body(''),
  body('\u2014\u2014\u2014'),
  body('The Endicott Edge | Truth Verified'),
  body('Real Talk. Real Strategies. Real Results.'),
  body(''),
  body('#IranConflict #ForeignPolicy #NationalSecurity #GovernmentAccountability #PolicyAnalysis #PoliticalPodcast #SeriesFinale #TheEndicottEdge #Podcast #TruthVerified'),

  divider(),

  // === SOCIAL MEDIA TEASERS ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  heading('SOCIAL MEDIA TEASERS'),
  italic('Short promotional copy for each episode \u2014 ready for posts, stories, or email newsletters.'),

  subheading('Episode 1 Teaser'),
  body('"The hostilities have terminated." \u2014 May 1'),
  body('"The U.S. is not at war at all." \u2014 Sep 10'),
  body('"We will continue major combat operations." \u2014 Mar 19'),
  body(''),
  body('Three statements. Three different officials. Same war. The gap between what they say and what they do is the story.'),
  body(''),
  body('\ud83c\udfa7 Episode 1: "The War That Isn\'t a War" \u2014 streaming now.'),
  body('Dashboard: https://iran-conflict-tracker.pplx.app'),

  subheading('Episode 2 Teaser'),
  body('The Treasury Secretary called it "economic D-Day." The White House said the war was "terminated." Four months apart.'),
  body(''),
  body('11 economic actions. 1,000+ entities sanctioned. 5 sectors targeted. All while the White House declared peace.'),
  body(''),
  body('\ud83c\udfa7 Episode 2: "Economic D-Day" \u2014 streaming now.'),
  body('Dashboard: https://iran-conflict-tracker.pplx.app'),

  subheading('Episode 3 Teaser'),
  body('264 days at sea. 1.5 million pounds of ordnance. The longest carrier deployment since Vietnam.'),
  body(''),
  body('You can say "taken care of" as many times as you want. The carriers are still there.'),
  body(''),
  body('\ud83c\udfa7 Episode 3: "Carriers and Combat" \u2014 streaming now.'),
  body('Dashboard: https://iran-conflict-tracker.pplx.app'),

  subheading('Episode 4 Teaser'),
  body('52 events. 25 analysis points. 4 episodes. The gap between rhetoric and reality is the story of this conflict.'),
  body(''),
  body('The series finale. The reconciliation \u2014 or rather, the lack of one.'),
  body(''),
  body('\ud83c\udfa7 Episode 4: "The Reconciliation" \u2014 streaming now.'),
  body('Dashboard: https://iran-conflict-tracker.pplx.app'),

  divider(),

  new Paragraph({
    spacing: { before: 400, after: 200 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'Truth Verified.', size: 28, font: FONT, color: COLOR_ACCENT, bold: true })],
  }),
];

const doc = new Document({
  styles: {
    default: { document: { run: { font: FONT, size: 22 } } },
    paragraphStyles: [
      {
        id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 32, bold: true, font: FONT, color: COLOR_ACCENT },
        paragraph: { spacing: { before: 360, after: 160 }, outlineLevel: 0 },
      },
      {
        id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 26, bold: true, font: FONT, color: COLOR_RED },
        paragraph: { spacing: { before: 280, after: 120 }, outlineLevel: 1 },
      },
    ],
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1080, right: 1080, bottom: 1080, left: 1080 },
      },
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({ text: 'The Endicott Edge \u2014 Show & Episode Descriptions', italics: true, color: '999999', size: 16, font: FONT })],
        })],
      }),
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({ text: 'Page ', size: 16, font: FONT, color: '999999' }),
            new TextRun({ children: [PageNumber.CURRENT], size: 16, font: FONT, color: '999999' }),
            new TextRun({ text: ' of ', size: 16, font: FONT, color: '999999' }),
            new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 16, font: FONT, color: '999999' }),
          ],
        })],
      }),
    },
    children: content,
  }],
});

(async () => {
  const buf = await Packer.toBuffer(doc);
  fs.writeFileSync('/home/user/workspace/iran-dashboard/show-descriptions.docx', buf);
  console.log('Show descriptions generated');
})();
