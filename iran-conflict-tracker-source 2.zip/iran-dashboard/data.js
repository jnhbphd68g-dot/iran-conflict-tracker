// Iran Conflict Dashboard Data
// Last updated: September 19, 2026
// Sources cited inline with each entry

const DASHBOARD_DATA = {
  lastUpdated: "September 19, 2026",
  latestCarrierSource: "September 14, 2026 (USNI News Fleet Tracker)",
  dataSource: "Official sources (whitehouse.gov, centcom.mil, treasury.gov/ofac, defense.gov) primary; major wire services (Reuters, AP) and defense tracking (USNI News) secondary",

  // Status overview metrics
  status: {
    warStartDate: "February 28, 2026",
    warDuration: "~7 months",
    estimatedCost: "$33.4B+",
    costSource: "DOD Inspector General estimate, mid-June 2026",
    costRate: "$2-3B/month",
    costRateSource: "Congressional Budget Office, September 2026",
    carriersInRegion: 2,
    carriersInRegionDetail: "USS George Washington & USS George H. W. Bush in Arabian Sea (CENTCOM AOR)",
    totalTroops: "50,000+",
    troopsSource: "CENTCOM, September 2026",
    sanctionsCount: "1,000+",
    sanctionsSource: "Treasury OFAC, April 2026",
    usCasualties: 18,
    casualtiesNote: "U.S. service member deaths (CNN, Sept 2026)",
    carriersPlannedThrough: "Projected through end of 2026 (monitoring outlook)",
    noCarrierInGulf: true,
    noCarrierInGulfNote: "No U.S. carrier publicly confirmed inside the Persian Gulf. Carriers operate in the Arabian Sea / Gulf of Oman. Iran's mining of the Strait of Hormuz has prevented carrier entry into the Persian Gulf since April 2026."
  },

  // Timeline of events - combined rhetorical shifts, military actions, economic actions, carrier movements
  timeline: [
    {
      date: "2026-02-06",
      category: "economic",
      actor: "President Trump",
      office: "White House",
      event: "Executive Order 14382 signed. Imposes additional tariffs (up to 25%) on goods from countries purchasing goods or services from Iran. Declares national emergency re: Iran threat.",
      quote: "The actions and policies of the Government of Iran continue to pose an unusual and extraordinary threat to the national security, foreign policy, and economy of the United States.",
      stance: "legal-economic",
      source: "White House (official)",
      url: "https://www.whitehouse.gov/presidential-actions/2026/02/addressing-threats-to-the-united-states-by-the-government-of-iran/"
    },
    {
      date: "2026-02-06",
      category: "economic",
      actor: "State Department",
      office: "State Department",
      event: "State Department sanctions 14 shadow fleet vessels for illicit Iranian oil trading.",
      stance: "legal-economic",
      source: "State Department (official)",
      url: "https://www.state.gov/releases/office-of-the-spokesperson/2026/02/sanctions-to-combat-illicit-traders-of-iranian-oil-and-the-shadow-fleet"
    },
    {
      date: "2026-02-28",
      category: "military",
      actor: "President Trump / Israel",
      office: "White House",
      event: "Operation Epic Fury begins. Joint US-Israeli airstrikes on Iranian military sites. Supreme Leader Khamenei killed.",
      quote: "The mission of Operation Epic Fury is laser-focused. Destroy Iranian offensive missiles, destroy Iranian missile production, destroy their navy and other security infrastructure, and they will never have nuclear weapons.",
      stance: "escalatory",
      source: "Defense.gov (official)",
      url: "https://www.defense.gov/News/News-Stories/Article/Article/4418826/hegseth-says-epic-fury-goals-in-iran-are-laser-focused/"
    },
    {
      date: "2026-02-28",
      category: "military",
      actor: "Iran",
      office: "Iranian military",
      event: "Iran retaliates, attacking US bases in Bahrain, Kuwait, Jordan, Iraq. Six US troops killed in Kuwait by Shahed drone.",
      stance: "escalatory",
      source: "ABC News",
      url: "https://abcnews.com/Politics/6-months-war-iran-left-pentagon-depleted-fighting/story?id=135980818"
    },
    {
      date: "2026-02-28",
      category: "economic",
      actor: "Iran",
      office: "Iranian military",
      event: "Iran shuts down commercial traffic through the Strait of Hormuz.",
      stance: "escalatory",
      source: "ABC News",
      url: "https://abcnews.com/Politics/6-months-war-iran-left-pentagon-depleted-fighting/story?id=135980818"
    },
    {
      date: "2026-03-02",
      category: "statement",
      actor: "Pete Hegseth",
      office: "Pentagon",
      event: "Defense Secretary briefs on expanding combat operations.",
      quote: "This is not endless war. This is not Iraq. This is not nation building.",
      stance: "deterrent",
      source: "Military.com",
      url: "https://www.military.com/daily-news/headlines/2026/03/02/just-beginning-endless-war-hegseth-defends-expanding-iran-combat.html"
    },
    {
      date: "2026-03-02",
      category: "statement",
      actor: "Gen. Dan Caine",
      office: "Pentagon",
      event: "Chairman of Joint Chiefs describes operation scope.",
      quote: "This work is just beginning.",
      stance: "escalatory",
      source: "Military.com",
      url: "https://www.military.com/daily-news/headlines/2026/03/02/just-beginning-endless-war-hegseth-defends-expanding-iran-combat.html"
    },
    {
      date: "2026-03-02",
      category: "statement",
      actor: "Pete Hegseth",
      office: "Pentagon",
      event: "Hegseth refuses to set a timetable for the war.",
      quote: "I would never hang a timeframe. We will execute on the president's terms.",
      stance: "deterrent",
      source: "Military.com",
      url: "https://www.military.com/daily-news/headlines/2026/03/02/just-beginning-endless-war-hegseth-defends-expanding-iran-combat.html"
    },
    {
      date: "2026-03-04",
      category: "statement",
      actor: "Pete Hegseth",
      office: "Pentagon",
      event: "Hegseth says the campaign has only just begun. Pentagon press briefing with CJCS Caine.",
      quote: "We've only just begun to hunt, dismantle, demoralize, destroy and defeat their capabilities.",
      stance: "escalatory",
      source: "Defense.gov (official)",
      url: "https://www.defense.gov/News/News-Stories/Article/Article/4418826/hegseth-says-epic-fury-goals-in-iran-are-laser-focused/"
    },
    {
      date: "2026-03-04",
      category: "statement",
      actor: "President Trump",
      office: "White House",
      event: "Trump warns of escalation to come.",
      quote: "We haven't even started hitting them hard. The big wave hasn't even happened. The big one is coming soon.",
      stance: "escalatory",
      source: "Politico",
      url: "https://www.politico.com/news/2026/03/04/hegset-iran-war-just-begun-00811889"
    },
    {
      date: "2026-03-06",
      category: "military",
      actor: "Pentagon",
      office: "Pentagon",
      event: "Internal Pentagon memo expects Iran war to continue through September 2026.",
      stance: "operational",
      source: "People's World",
      url: "https://www.peoplesworld.org/article/internal-memo-pentagon-expects-iran-war-through-september/"
    },
    {
      date: "2026-03-15",
      category: "statement",
      actor: "Kevin Hassett",
      office: "White House",
      event: "White House NEC director cites Pentagon estimate of 4-6 weeks for the war.",
      quote: "The Pentagon estimates the Iran war would take between four and six weeks.",
      stance: "de-escalatory",
      source: "Fortune",
      url: "https://fortune.com/2026/03/15/pentagon-iran-war-timeline-six-weeks-trump-kevin-hassett/"
    },
    {
      date: "2026-03-19",
      category: "statement",
      actor: "Pete Hegseth",
      office: "Pentagon",
      event: "Secretary of War Hegseth and Gen. Caine press briefing. Hegseth reiterates objectives remain unchanged.",
      quote: "Our objectives, given directly from our America first president remain exactly what they were on day one. These are not the media's objectives, not Iran's objectives, not new objectives — our objectives, unchanged, on target and on plan: destroy missiles, launchers and Iran's defense industrial base so they cannot rebuild, destroy their navy, and Iran never gets a nuclear weapon.",
      stance: "deterrent",
      source: "Defense.gov transcript (official)",
      url: "https://www.defense.gov/News/Transcripts/Transcript/Article/4438625/"
    },
    {
      date: "2026-03-19",
      category: "statement",
      actor: "Gen. Dan Caine",
      office: "Pentagon",
      event: "CJCS states operations will continue and pressure will intensify.",
      quote: "U.S. Central Command remains on plan to achieve our military objectives. Each day we continue to attack deeper into Iranian territory. And the pressure will continue. In conclusion, we will continue major combat operations.",
      stance: "escalatory",
      source: "Defense.gov transcript (official)",
      url: "https://www.defense.gov/News/Transcripts/Transcript/Article/4438625/"
    },
    {
      date: "2026-06-10",
      category: "economic",
      actor: "Treasury OFAC",
      office: "Treasury",
      event: "Economic Fury: OFAC sanctions 9 individuals and entities supporting Iran's weapons procurement networks.",
      stance: "legal-economic",
      source: "Treasury (official)",
      url: "https://home.treasury.gov/news/press-releases/sb0528"
    },
    {
      date: "2026-06-19",
      category: "statement",
      actor: "President Trump",
      office: "White House",
      event: "White House announces signing of Memorandum of Understanding with Iran. Claims historic breakthrough.",
      quote: "President Donald J. Trump and Vice President JD Vance have secured a historic breakthrough by signing a Memorandum of Understanding with Iran. This agreement ensures Iran will never obtain a nuclear weapon, reopens the Strait of Hormuz to free navigation, and puts America First.",
      stance: "de-escalatory",
      source: "White House (official)",
      url: "https://www.whitehouse.gov/releases/2026/06/president-trumps-iran-agreement-is-america-first-in-action/"
    },
    {
      date: "2026-07-07",
      category: "military",
      actor: "CENTCOM",
      office: "Pentagon",
      event: "CENTCOM completes new round of retaliatory strikes against Iran.",
      stance: "escalatory",
      source: "CENTCOM (official)",
      url: "https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/Article/4535772/us-forces-complete-new-round-of-retaliatory-strikes-against-iran/"
    },
    {
      date: "2026-07-08",
      category: "military",
      actor: "CENTCOM",
      office: "Pentagon",
      event: "CENTCOM completes another round of strikes against Iran.",
      stance: "escalatory",
      source: "CENTCOM (official)",
      url: "https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/Article/4538814/us-forces-complete-another-round-of-strikes-against-iran/"
    },
    {
      date: "2026-07-13",
      category: "military",
      actor: "CENTCOM",
      office: "Pentagon",
      event: "CENTCOM completes new strikes on Iranian military targets.",
      stance: "escalatory",
      source: "CENTCOM (official)",
      url: "https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/Article/4544409/us-forces-complete-new-strikes-on-iranian-military-targets/"
    },
    {
      date: "2026-07-20",
      category: "military",
      actor: "CENTCOM",
      office: "Pentagon",
      event: "CENTCOM finishes latest strikes against Iran at 9 p.m. ET.",
      stance: "escalatory",
      source: "CENTCOM (official)",
      url: "https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/Article/4550818/us-finishes-latest-strikes-against-iran/"
    },
    {
      date: "2026-07-29",
      category: "economic",
      actor: "Treasury OFAC",
      office: "Treasury",
      event: "OFAC disrupts IRGC-backed Strait of Hormuz extortion scheme. Designates Persian Gulf Marine Insurance Company and HormuzSafe. Sanctions 100+ shadow fleet vessels since Jan 2026.",
      quote: "With its economy in freefall and inflation in the triple digits, the regime is desperate for cash. The United States will not allow Iran to hold global commerce hostage.",
      stance: "legal-economic",
      source: "Treasury (official)",
      url: "https://home.treasury.gov/news/press-releases/sb0581"
    },
    {
      date: "2026-09-18",
      category: "economic",
      actor: "President Trump",
      office: "White House",
      event: "President signs H.R. 5334, the Lindsey O. Graham Sanctioning Russia and Iran Act of 2026, into law. Extends and expands statutory sanctions on Iran.",
      stance: "legal-economic",
      source: "White House (official)",
      url: "https://www.whitehouse.gov/briefings-statements/2026/09/congressional-bill-h-r-5334-signed-into-law/"
    },
    {
      date: "2026-04-01",
      category: "statement",
      actor: "President Trump",
      office: "White House",
      event: "Prime-time address to nation on Operation Epic Fury.",
      quote: "Never in the history of warfare has an enemy suffered such clear and devastating large-scale losses in a matter of weeks.",
      stance: "de-escalatory",
      source: "ABC News",
      url: "https://abcnews.com/Politics/6-months-war-iran-left-pentagon-depleted-fighting/story?id=135980818"
    },
    {
      date: "2026-04-07",
      category: "statement",
      actor: "Todd Blanche",
      office: "Attorney General",
      event: "Acting AG discloses DOJ advisory role on Iran war.",
      quote: "We have been providing that guidance as anticipated.",
      stance: "legal-economic",
      source: "WSJ",
      url: "https://www.wsj.com/livecoverage/iran-war-2026-trump-deadline-latest-news/card/justice-department-provided-counsel-on-iran-war-top-official-says-V2m4AAPeN4zqbxqgYBpY"
    },
    {
      date: "2026-04-08",
      category: "statement",
      actor: "President Trump",
      office: "White House",
      event: "Trump declares Iran's uranium 'taken care of' as ceasefire takes hold.",
      quote: "Iran's uranium will be 'perfectly taken care of.'",
      stance: "de-escalatory",
      source: "The Guardian",
      url: "https://www.theguardian.com/world/live/2026/apr/07/iran-war-live-updates-trump-hormuz-threats-deadline-strikes-middle-east-conflict"
    },
    {
      date: "2026-04-13",
      category: "carrier",
      actor: "USS Abraham Lincoln",
      office: "Navy",
      event: "USS Abraham Lincoln enters Gulf of Oman, positions 200km from Iranian coast east of Strait of Hormuz.",
      stance: "operational",
      source: "Baku.ws / BBC",
      url: "https://baku.ws/en/world/media-american-aircraft-carrier-entered-the-gulf-of-oman-200-km-from-the-coast-of-iran"
    },
    {
      date: "2026-04-25",
      category: "carrier",
      actor: "US Navy",
      office: "Pentagon",
      event: "Three US aircraft carriers operate in Middle East for first time since 2003. No carrier publicly confirmed inside the Persian Gulf; public reporting places them outside the Gulf.",
      stance: "operational",
      source: "House of Saud",
      url: "https://houseofsaud.com/three-carriers-middle-east-2026/"
    },
    {
      date: "2026-04-28",
      category: "economic",
      actor: "Treasury OFAC",
      office: "Treasury",
      event: "US imposes sanctions on 35 individuals and entities for aiding Iran's sanctions evasion. Adds to 1,000+ sanctions since Feb 2025.",
      quote: "OFAC warns against doing business with those paying Iran to transit Strait of Hormuz.",
      stance: "legal-economic",
      source: "Reuters",
      url: "https://www.reuters.com/business/finance/us-imposes-sanctions-35-individuals-entities-aiding-irans-sanctions-evasions-2026-04-28/"
    },
    {
      date: "2026-04-29",
      category: "statement",
      actor: "Pete Hegseth",
      office: "Pentagon",
      event: "Hegseth declares mission accomplished, refuses to speculate on war length.",
      quote: "Mission against Iran accomplished.",
      stance: "de-escalatory",
      source: "Military Times",
      url: "https://www.militarytimes.com/news/pentagon-congress/2026/04/29/dont-call-it-a-quagmire-defense-secretary-refuses-to-speculate-on-length-of-iran-war/"
    },
    {
      date: "2026-05-01",
      category: "statement",
      actor: "President Trump",
      office: "White House",
      event: "Trump declares hostilities 'terminated' as War Powers Resolution 60-day deadline arrives.",
      quote: "The hostilities that began on February 28, 2026, have terminated.",
      stance: "de-escalatory",
      source: "Reuters",
      url: "https://www.reuters.com/world/asia-pacific/white-house-says-iran-war-terminated-war-powers-deadline-arrives-2026-05-01/"
    },
    {
      date: "2026-05-03",
      category: "statement",
      actor: "Todd Blanche",
      office: "Attorney General",
      event: "Acting AG on Meet the Press defends administration's legal position on War Powers.",
      quote: "Threatening the life of the president of the United States will never be tolerated.",
      stance: "legal-economic",
      source: "NBC News - Meet the Press",
      url: "https://www.nbcnews.com/meet-the-press/transcripts/meet-press-may-3-2026-rcna343322"
    },
    {
      date: "2026-05-05",
      category: "statement",
      actor: "Marco Rubio",
      office: "State Department",
      event: "Secretary of State declares combat operation over, transitions to 'Project Freedom' escort mission.",
      quote: "Operation Epic Fury is over. We achieved the objectives of that operation. We're now on to this Project Freedom.",
      stance: "de-escalatory",
      source: "CNN",
      url: "https://www.cnn.com/2026/05/05/world/live-news/iran-war-news"
    },
    {
      date: "2026-05-05",
      category: "statement",
      actor: "President Trump",
      office: "White House",
      event: "Trump pauses 'Project Freedom' commercial vessel escort effort.",
      stance: "de-escalatory",
      source: "CNN",
      url: "https://www.cnn.com/2026/05/05/world/live-news/iran-war-news"
    },
    {
      date: "2026-06-22",
      category: "economic",
      actor: "Treasury OFAC",
      office: "Treasury",
      event: "OFAC issues Iran General License X, authorizing sale of Iranian-origin crude oil through August 21, 2026.",
      stance: "legal-economic",
      source: "OFAC",
      url: "https://ofac.treasury.gov/recent-actions/20260622_33"
    },
    {
      date: "2026-07-23",
      category: "military",
      actor: "CENTCOM",
      office: "Pentagon",
      event: "U.S. concludes 13th night of precision strikes on Iranian military targets.",
      stance: "escalatory",
      source: "CENTCOM",
      url: "https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/Article/4554310/us-concludes-13th-night-of-strikes-on-iranian-military-targets/"
    },
    {
      date: "2026-08-08",
      category: "statement",
      actor: "Todd Blanche",
      office: "Attorney General",
      event: "Blanche confirmed as Attorney General. Iran-Oman Strait deal stalls.",
      stance: "legal-economic",
      source: "NPR",
      url: "https://www.npr.org/2026/08/08/nx-s1-5921263/week-in-politics-blanche-confirmed-as-attorney-general-iran-oman-strait-deal-stalls"
    },
    {
      date: "2026-08-24",
      category: "economic",
      actor: "Scott Bessent",
      office: "Treasury",
      event: "Treasury launches 'Operation Economic Outcast' - major sanctions escalation targeting 5 vital lifelines.",
      quote: "Today, at President Trump's direction, the United States Treasury has begun Operation Economic Outcast — an unprecedented campaign against the Islamic Republic of Iran and its enablers.",
      stance: "legal-economic",
      source: "Treasury (official)",
      url: "https://home.treasury.gov/news/press-releases/sb0613"
    },
    {
      date: "2026-08-27",
      category: "military",
      actor: "Pentagon",
      office: "Pentagon",
      event: "After 6 months of war, Pentagon depleted and still fighting. No clear end in sight.",
      quote: "The U.S. is still at war, caught in a Middle East conflict with no obvious end.",
      stance: "operational",
      source: "ABC News",
      url: "https://abcnews.com/Politics/6-months-war-iran-left-pentagon-depleted-fighting/story?id=135980818"
    },
    {
      date: "2026-09-01",
      category: "military",
      actor: "CENTCOM",
      office: "Pentagon",
      event: "CENTCOM completes strikes on IRGC targets including air defense sites, radar, maritime assets, mine-laying capabilities.",
      quote: "U.S. forces are prepared to continue executing operations directed by the Commander in Chief.",
      stance: "escalatory",
      source: "CENTCOM",
      url: "https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/Article/4588389/centcom-completes-strikes-on-irgc-targets-in-iran/"
    },
    {
      date: "2026-09-05",
      category: "military",
      actor: "CENTCOM",
      office: "Pentagon",
      event: "CENTCOM destroys 3 IRGC oil tankers after Iran targets 2 U.S. Navy warships. Official CENTCOM release confirms exchange of fire.",
      quote: "CENTCOM Destroys 3 IRGC Oil Tankers After Iran Targets 2 U.S. Navy Warships.",
      stance: "escalatory",
      source: "CENTCOM (official)",
      url: "https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/"
    },
    {
      date: "2026-09-08",
      category: "military",
      actor: "CENTCOM",
      office: "Pentagon",
      event: "U.S. destroys 5 IRGC tankers after Iran targets another American warship. Second exchange of fire in one week.",
      quote: "U.S. Destroys 5 IRGC Tankers After Iran Targets Another American Warship.",
      stance: "escalatory",
      source: "CENTCOM (official)",
      url: "https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/"
    },
    {
      date: "2026-09-05",
      category: "statement",
      actor: "Adm. Brad Cooper",
      office: "Pentagon",
      event: "CENTCOM commander responds to Iranian carrier attack.",
      quote: "Let the message to the IRGC be clear: If you shoot at two of our ships, we will impose an even higher economic cost — taking out three of yours. We will not hesitate to defend American forces, and if necessary, destroy Iran's limited and exposed oil fleet.",
      stance: "escalatory",
      source: "The War Zone",
      url: "https://www.twz.com/sea/where-are-the-american-aircraft-carriers-september-9-2026"
    },
    {
      date: "2026-09-06",
      category: "statement",
      actor: "Leon Panetta",
      office: "Former Defense Secretary",
      event: "Former Defense Secretary warns war likely to drag on six more months.",
      quote: "I think the likelihood is this war is going to continue for another six months without being resolved. It's no mystery that the United States and Iran are caught in a terrible stalemate.",
      stance: "operational",
      source: "The Guardian",
      url: "https://www.theguardian.com/world/2026/sep/06/iran-war-trump-leon-panetta-interview"
    },
    {
      date: "2026-09-08",
      category: "carrier",
      actor: "US Navy",
      office: "Pentagon",
      event: "USNI Fleet Tracker: Two carriers in Arabian Sea (George Washington CSG-5, George H. W. Bush CSG-10). Abraham Lincoln in South China Sea. Theodore Roosevelt departing San Diego to relieve George Washington.",
      stance: "operational",
      source: "USNI News",
      url: "https://news.usni.org/2026/09/08/usni-news-fleet-and-marine-tracker-sept-8-2026"
    },
    {
      date: "2026-09-10",
      category: "statement",
      actor: "The Atlantic",
      office: "Media/Analysis",
      event: "The Atlantic reports Navy positioning carriers for sustained presence through end of 2026.",
      quote: "Naval forces are being positioned for a sustained presence at least through the end of the year, keeping open the option of escalation.",
      stance: "operational",
      source: "The Atlantic",
      url: "https://www.theatlantic.com/national-security/2026/09/trump-iran-war-navy/688563/"
    },
    {
      date: "2026-09-10",
      category: "statement",
      actor: "VP J.D. Vance",
      office: "White House",
      event: "Vice President denies US is at war.",
      quote: "The U.S. is not at war at all.",
      stance: "de-escalatory",
      source: "The Atlantic",
      url: "https://www.theatlantic.com/national-security/2026/09/trump-iran-war-navy/688563/"
    },
    {
      date: "2026-09-10",
      category: "statement",
      actor: "President Trump",
      office: "White House",
      event: "Trump downplays the conflict.",
      quote: "The conflict was 'small potatoes.'",
      stance: "de-escalatory",
      source: "The Atlantic",
      url: "https://www.theatlantic.com/national-security/2026/09/trump-iran-war-navy/688563/"
    },
    {
      date: "2026-09-14",
      category: "statement",
      actor: "Todd Blanche",
      office: "Attorney General",
      event: "AG Blanche disputes characterization of Iran conflict as a war.",
      quote: "I disagree with that characterization, as does most of Congress.",
      stance: "de-escalatory",
      source: "CBS News",
      url: "https://www.cbsnews.com/live-updates/iran-war-us-trump-oil-strait-of-hormuz/"
    },
    {
      date: "2026-09-15",
      category: "statement",
      actor: "Col. Cedric Leighton",
      office: "CNN Military Analyst",
      event: "CNN military analyst rebuts AG's denial of war status.",
      quote: "It's hard to believe that something that costs at least $28 billion is not a war. These conflicts are, by any other term, they are wars, and to use expressions that cover that up is really a disservice to the American people.",
      stance: "operational",
      source: "CNN",
      url: "https://transcripts.cnn.com/show/cnc/date/2026-09-15/segment/10"
    },
    {
      date: "2026-09-17",
      category: "statement",
      actor: "Mike Johnson",
      office: "Speaker of the House (Congress)",
      event: "House Speaker (congressional ally of White House) declares Iran nuclear issue 'taken care of.'",
      quote: "Iran will not have a nuclear weapon. That was an important objective of American foreign policy for the last half-century. That's taken care of, and now we got to get gas prices down.",
      stance: "de-escalatory",
      source: "CBS News",
      url: "https://www.cbsnews.com/live-updates/iran-war-us-trump-oil-strait-of-hormuz/"
    },
    {
      date: "2026-09-17",
      category: "statement",
      actor: "President Trump",
      office: "White House",
      event: "Trump says war may be ending at campaign rally.",
      quote: "Hopefully we're toward the end of the war. They want to make a deal. We'll see how that works out.",
      stance: "de-escalatory",
      source: "CBS News",
      url: "https://www.cbsnews.com/live-updates/iran-war-us-trump-oil-strait-of-hormuz/"
    },
    {
      date: "2026-09-17",
      category: "economic",
      actor: "Scott Bessent",
      office: "Treasury",
      event: "Treasury Secretary announces continued financial offensive.",
      quote: "Treasury continues to sever every economic lifeline Tehran has left. Financial institutions are in lockstep with the U.S. government in support of Operation Economic Outcast.",
      stance: "legal-economic",
      source: "CBS News",
      url: "https://www.cbsnews.com/live-updates/iran-war-us-trump-oil-strait-of-hormuz/"
    }
  ],

  // Carrier posture data
  carriers: [
    {
      name: "USS George Washington (CVN-73)",
      strikeGroup: "CSG-5",
      homeport: "Yokosuka, Japan",
      position: "Arabian Sea (CENTCOM AOR)",
      status: "Deployed - Operations against Iran",
      notes: "Relieved USS Abraham Lincoln. Operating with Carrier Air Wing 5 and USS Shoup (DDG-86). Enforcing U.S. naval blockade of Iran and providing cover for commercial vessels transiting Strait of Hormuz. Conducting night flight operations as of Sept 15 (Reuters).",
      lastVerified: "Sept 14, 2026",
      source: "USNI News Fleet Tracker (Sept 14)",
      url: "https://news.usni.org/2026/09/14/usni-news-fleet-and-marine-tracker-sept-14-2026"
    },
    {
      name: "USS George H. W. Bush (CVN-77)",
      strikeGroup: "CSG-10",
      homeport: "Norfolk, VA",
      position: "Arabian Sea (CENTCOM AOR)",
      status: "Deployed - Operations against Iran",
      notes: "In region since April 2026. Second carrier in CENTCOM AOR. Operating alongside USS George Washington.",
      lastVerified: "Sept 14, 2026",
      source: "USNI News Fleet Tracker (Sept 14)",
      url: "https://news.usni.org/2026/09/14/usni-news-fleet-and-marine-tracker-sept-14-2026"
    },
    {
      name: "USS Abraham Lincoln (CVN-72)",
      strikeGroup: "CSG-3",
      homeport: "San Diego, CA",
      position: "South China Sea (returning to US)",
      status: "Returning from deployment",
      notes: "264 consecutive days at sea. Dropped 1.5M+ lbs of ordnance. Port visit to Thailand Sep 2-6. Now in South China Sea heading back to San Diego. Expected to arrive late September/early October.",
      lastVerified: "Sept 14, 2026",
      source: "USNI News Fleet Tracker (Sept 14)",
      url: "https://news.usni.org/2026/09/14/usni-news-fleet-and-marine-tracker-sept-14-2026"
    },
    {
      name: "USS Theodore Roosevelt (CVN-71)",
      strikeGroup: "CSG-3 (preparing to relieve)",
      homeport: "San Diego, CA",
      position: "San Diego (preparing to deploy)",
      status: "Preparing to relieve USS George Washington",
      notes: "Returned to San Diego after training. Expected to depart in coming weeks for Arabian Sea. Deployment expected to last 7+ months. Will join ~19 U.S. warships enforcing blockade of Iranian ports (CENTCOM SASC Posture Statement). Navy applying lessons from Lincoln deployment (supply shortages, morale).",
      lastVerified: "Sept 14, 2026",
      source: "USNI News / Stripes / CENTCOM",
      url: "https://www.stripes.com/branches/navy/2026-09-09/navy-lincoln-roosevelt-ford-middle-east-iran-22796716.html"
    },
    {
      name: "CENTCOM SASC Posture Statement (2026)",
      strikeGroup: "—",
      homeport: "—",
      position: "Official posture statement",
      status: "Reference document",
      notes: "Adm. Brad Cooper's posture statement before Senate Armed Services Committee. Confirms: USCENTCOM initiated Operation EPIC FURY at the direction of the President. Air and naval forces continue to enforce presidentially directed blockade against Iranian ports. Maintains 'ready and resilient posture' to deter aggression, defend U.S. forces, and provide credible military power.",
      lastVerified: "2026",
      source: "CENTCOM (official)",
      url: "https://www.centcom.mil/ABOUT-US/SASC-POSTURE-STATEMENT-2026/"
    }
  ],

  // Statement conflict matrix - by issue and office
  conflictMatrix: {
    issues: [
      {
        issue: "War Status",
        whiteHouse: {
          stance: "Not at war / terminated",
          quote: "The hostilities that began on February 28, 2026, have terminated.",
          speaker: "President Trump",
          date: "May 1, 2026",
          url: "https://www.reuters.com/world/asia-pacific/white-house-says-iran-war-terminated-war-powers-deadline-arrives-2026-05-01/"
        },
        attorneyGeneral: {
          stance: "Not a war",
          quote: "I disagree with that characterization, as does most of Congress.",
          speaker: "AG Todd Blanche",
          date: "Sep 14, 2026",
          url: "https://www.cbsnews.com/live-updates/iran-war-us-trump-oil-strait-of-hormuz/"
        },
        pentagon: {
          stance: "Still fighting / sustained operations",
          quote: "The U.S. is still at war, caught in a Middle East conflict with no obvious end.",
          speaker: "ABC News characterization of Pentagon posture",
          date: "Aug 27, 2026",
          url: "https://abcnews.com/Politics/6-months-war-iran-left-pentagon-depleted-fighting/story?id=135980818"
        },
        contradiction: "White House and AG deny war status while Pentagon sustains combat operations, CENTCOM conducts strikes, and 50,000+ troops remain deployed."
      },
      {
        issue: "War Duration",
        whiteHouse: {
          stance: "Ending soon / taken care of",
          quote: "Hopefully we're toward the end of the war. They want to make a deal.",
          speaker: "President Trump",
          date: "Sep 17, 2026",
          url: "https://www.cbsnews.com/live-updates/iran-war-us-trump-oil-strait-of-hormuz/"
        },
        attorneyGeneral: {
          stance: "Not a war (duration irrelevant)",
          quote: "I disagree with that characterization, as does most of Congress.",
          speaker: "AG Todd Blanche",
          date: "Sep 14, 2026",
          url: "https://www.cbsnews.com/live-updates/iran-war-us-trump-oil-strait-of-hormuz/"
        },
        pentagon: {
          stance: "Long war / no endpoint",
          quote: "We've only just begun to hunt, dismantle, demoralize, destroy and defeat their capabilities. (Mar 4) / We wouldn't want to set a definitive timeframe on that. But we are very much on plan. (Mar 19)",
          speaker: "Sec. War Hegseth",
          date: "Mar 4 & Mar 19, 2026",
          url: "https://www.defense.gov/News/Transcripts/Transcript/Article/4438625/"
        },
        contradiction: "White House claims war is ending while Pentagon's own internal memo (Mar 6) projected operations through September. Carriers projected to sustain presence through end of 2026 (monitoring outlook)."
      },
      {
        issue: "Nuclear Program",
        whiteHouse: {
          stance: "Taken care of",
          quote: "Iran's uranium will be 'perfectly taken care of.'",
          speaker: "President Trump",
          date: "Apr 8, 2026",
          url: "https://www.theguardian.com/world/live/2026/apr/07/iran-war-live-updates-trump-hormuz-threats-deadline-strikes-middle-east-conflict"
        },
        attorneyGeneral: {
          stance: "DOJ providing legal counsel",
          quote: "We have been providing that guidance as anticipated.",
          speaker: "Acting AG Todd Blanche",
          date: "Apr 7, 2026",
          url: "https://www.wsj.com/livecoverage/iran-war-2026-trump-deadline-latest-news/card/justice-department-provided-counsel-on-iran-war-top-official-says-V2m4AAPeN4zqbxqgYBpY"
        },
        pentagon: {
          stance: "Continued strikes on nuclear-adjacent targets",
          quote: "U.S. forces are prepared to continue executing operations directed by the Commander in Chief.",
          speaker: "CENTCOM statement",
          date: "Sep 1, 2026",
          url: "https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/Article/4588389/centcom-completes-strikes-on-irgc-targets-in-iran/"
        },
        contradiction: "White House declares nuclear issue resolved while military continues striking IRGC targets including facilities related to missile and nuclear infrastructure."
      },
      {
        issue: "Use of Force",
        whiteHouse: {
          stance: "Operation over / small potatoes",
          quote: "The U.S. is not at war at all. / The conflict was 'small potatoes.'",
          speaker: "VP Vance / President Trump",
          date: "Sep 10, 2026",
          url: "https://www.theatlantic.com/national-security/2026/09/trump-iran-war-navy/688563/"
        },
        attorneyGeneral: {
          stance: "Legal framework maintained",
          quote: "Working with Treasury Secretary Bessent and DHS, we spend a tremendous amount of resources and effort to keep our financial system clear.",
          speaker: "AG Todd Blanche",
          date: "Sep 15, 2026",
          url: "https://transcripts.cnn.com/show/cnc/date/2026-09-15/segment/10"
        },
        pentagon: {
          stance: "Sustained combat posture",
          quote: "Each day we continue to attack deeper into Iranian territory. And the pressure will continue. In conclusion, we will continue major combat operations.",
          speaker: "Gen. Dan Caine, CJCS",
          date: "Mar 19, 2026",
          url: "https://www.defense.gov/News/Transcripts/Transcript/Article/4438625/"
        },
        contradiction: "White House downplays conflict as 'small potatoes' while CENTCOM commander threatens escalation and Navy sustains two-carrier combat presence."
      },
      {
        issue: "Economic Strategy",
        whiteHouse: {
          stance: "Pivot to gas prices",
          quote: "Hopefully we're toward the end of the war. They want to make a deal.",
          speaker: "President Trump",
          date: "Sep 17, 2026",
          url: "https://www.cbsnews.com/live-updates/iran-war-us-trump-oil-strait-of-hormuz/"
        },
        attorneyGeneral: {
          stance: "Financial enforcement",
          quote: "Working with Treasury Secretary Bessent and DHS to keep our financial system clear.",
          speaker: "AG Todd Blanche",
          date: "Sep 15, 2026",
          url: "https://transcripts.cnn.com/show/cnc/date/2026-09-15/segment/10"
        },
        pentagon: {
          stance: "Military-economic escalation",
          quote: "We are launching an economic onslaught against Iran's financial connections around the globe. Our objective is to sever every economic lifeline that sustains this tyrannical regime until Tehran stands alone.",
          speaker: "Treasury Sec. Bessent",
          date: "Aug 24, 2026",
          url: "https://home.treasury.gov/news/press-releases/sb0613"
        },
        contradiction: "White House pivots to domestic gas prices while Treasury launches 'economic D-Day' and CENTCOM destroys IRGC tankers."
      }
    ]
  },

  // Economic vs Military tracker
  economicVsMilitary: {
    economic: [
      { date: "2026-02-06", action: "President signs EO 14382 - imposes tariffs (up to 25%) on countries doing business with Iran. Declares national emergency.", source: "White House (official)", url: "https://www.whitehouse.gov/presidential-actions/2026/02/addressing-threats-to-the-united-states-by-the-government-of-iran/" },
      { date: "2026-02-06", action: "State Dept sanctions 14 shadow fleet vessels for Iranian oil trading", source: "State Department (official)", url: "https://www.state.gov/releases/office-of-the-spokesperson/2026/02/sanctions-to-combat-illicit-traders-of-iranian-oil-and-the-shadow-fleet" },
      { date: "2026-04-28", action: "OFAC sanctions 35 individuals/entities for Iran sanctions evasion (1,000+ total since Feb 2025)", source: "Reuters / Treasury", url: "https://www.reuters.com/business/finance/us-imposes-sanctions-35-individuals-entities-aiding-irans-sanctions-evasions-2026-04-28/" },
      { date: "2026-06-10", action: "Economic Fury: OFAC sanctions 9 entities for supporting Iran's weapons procurement networks", source: "Treasury (official)", url: "https://home.treasury.gov/news/press-releases/sb0528" },
      { date: "2026-06-22", action: "OFAC issues Iran General License X - authorizes Iranian oil sales through Aug 21", source: "OFAC", url: "https://ofac.treasury.gov/recent-actions/20260622_33" },
      { date: "2026-07-29", action: "OFAC disrupts IRGC Strait of Hormuz extortion scheme (Persian Gulf Marine Insurance / HormuzSafe). 100+ shadow fleet vessels sanctioned since Jan 2026.", source: "Treasury (official)", url: "https://home.treasury.gov/news/press-releases/sb0581" },
      { date: "2026-08-24", action: "Operation Economic Outcast launched - 'economic D-Day' - sectoral sanctions on 5 vital lifelines (digital assets, technology, gold, aviation, shipping)", source: "Treasury (official)", url: "https://home.treasury.gov/news/press-releases/sb0613" },
      { date: "2026-09-08", action: "OFAC Counter Terrorism designations + Iran-related General License updates", source: "OFAC", url: "https://ofac.treasury.gov/recent-actions/20260908" },
      { date: "2026-09-16", action: "Iran-related designations + Venezuela license amendments", source: "OFAC", url: "https://ofac.treasury.gov/recent-actions" },
      { date: "2026-09-17", action: "Treasury: 'continues to sever every economic lifeline Tehran has left' - financial institutions briefing", source: "CBS News / Treasury", url: "https://www.cbsnews.com/live-updates/iran-war-us-trump-oil-strait-of-hormuz/" },
      { date: "2026-09-18", action: "President signs H.R. 5334 - Lindsey O. Graham Sanctioning Russia and Iran Act of 2026 - into law", source: "White House (official)", url: "https://www.whitehouse.gov/briefings-statements/2026/09/congressional-bill-h-r-5334-signed-into-law/" }
    ],
    military: [
      { date: "2026-02-28", action: "Operation Epic Fury begins - 100+ aircraft launch, 1,000+ targets in first 24 hours. CJCS Caine: 'culmination of months, years of deliberate planning'", source: "Defense.gov (official)", url: "https://www.defense.gov/News/News-Stories/Article/Article/4418826/hegseth-says-epic-fury-goals-in-iran-are-laser-focused/" },
      { date: "2026-03-04", action: "US submarine torpedoes Iranian warship off Sri Lanka - first since WWII", source: "Politico", url: "https://www.politico.com/news/2026/03/04/hegset-iran-war-just-begun-00811889" },
      { date: "2026-04-13", action: "USS Abraham Lincoln enters Gulf of Oman, 200km from Iranian coast", source: "Baku.ws / BBC", url: "https://baku.ws/en/world/media-american-aircraft-carrier-entered-the-gulf-of-oman-200-km-from-the-coast-of-iran" },
      { date: "2026-04-25", action: "Three carriers in Middle East for first time since 2003 - no carrier publicly confirmed inside Persian Gulf", source: "House of Saud", url: "https://houseofsaud.com/three-carriers-middle-east-2026/" },
      { date: "2026-07-07", action: "CENTCOM completes new round of retaliatory strikes against Iran", source: "CENTCOM (official)", url: "https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/Article/4535772/us-forces-complete-new-round-of-retaliatory-strikes-against-iran/" },
      { date: "2026-07-08", action: "CENTCOM completes another round of strikes against Iran", source: "CENTCOM (official)", url: "https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/Article/4538814/us-forces-complete-another-round-of-strikes-against-iran/" },
      { date: "2026-07-13", action: "CENTCOM completes new strikes on Iranian military targets", source: "CENTCOM (official)", url: "https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/Article/4544409/us-forces-complete-new-strikes-on-iranian-military-targets/" },
      { date: "2026-07-20", action: "CENTCOM finishes latest strikes against Iran at 9 p.m. ET", source: "CENTCOM (official)", url: "https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/Article/4550818/us-finishes-latest-strikes-against-iran/" },
      { date: "2026-07-23", action: "13th night of precision strikes on Iranian military targets", source: "CENTCOM (official)", url: "https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/Article/4554310/us-concludes-13th-night-of-strikes-on-iranian-military-targets/" },
      { date: "2026-09-01", action: "CENTCOM strikes on IRGC air defense, radar, maritime assets, mine-laying capabilities", source: "CENTCOM", url: "https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/Article/4588389/centcom-completes-strikes-on-irgc-targets-in-iran/" },
      { date: "2026-09-08", action: "U.S. destroys 5 IRGC tankers after Iran targets another American warship — second exchange of fire in one week", source: "CENTCOM (official)", url: "https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/" },
      { date: "2026-09-05", action: "CENTCOM destroys 3 IRGC oil tankers after Iran targets 2 U.S. Navy warships — first exchange of fire since late July", source: "CENTCOM (official)", url: "https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/" },
      { date: "2026-09-14", action: "USS Theodore Roosevelt in San Diego preparing to deploy; expected to depart in coming weeks for Arabian Sea to relieve George Washington (per Sept 14 USNI tracker)", source: "USNI News / Stripes", url: "https://www.stripes.com/branches/navy/2026-09-09/navy-lincoln-roosevelt-ford-middle-east-iran-22796716.html" }
    ]
  },

  // Side-by-side analysis
  analysis: {
    declaratoryPolicy: [
      "White House: War 'terminated' (May 1), 'is over' (May 5), 'taken care of' (Sep 17), 'small potatoes' (Sep 10)",
      "VP Vance: 'The U.S. is not at war at all' (Sep 10)",
      "AG Blanche: 'I disagree with that characterization, as does most of Congress' (Sep 14)",
      "Sec. State Rubio (State Dept.): 'We achieved the objectives of that operation' (May 5)",
      "Speaker Johnson (Congress): Nuclear issue 'taken care of' (Sep 17)"
    ],
    observedForcePosture: [
      "Two carriers (George Washington, George H. W. Bush) in Arabian Sea supporting operations against Iran as of Sept 14 (USNI)",
      "Theodore Roosevelt deploying to relieve George Washington - expected lengthy deployment through end of 2026",
      "Abraham Lincoln spent 264 consecutive days at sea, dropped 1.5M+ lbs of ordnance before departing",
      "50,000+ U.S. service members deployed across the Middle East (CENTCOM SASC Posture Statement, 2026)",
      "CENTCOM conducting active strikes on IRGC targets as recently as Sept 8, 2026 (official CENTCOM releases)",
      "CENTCOM SASC Posture Statement: 'USCENTCOM, at the direction of the President, initiated Operation EPIC FURY' and maintains 'ready and resilient posture'",
      "Gen. Caine (Mar 19, Defense.gov): 'Each day we continue to attack deeper into Iranian territory... the pressure will continue'",
      "Sec. War Hegseth (Mar 19, Defense.gov): 'We wouldn't want to set a definitive timeframe... we're very much on track'",
      "Navy positioning for sustained two-carrier presence in/around Gulf through end of year (The Atlantic, Sep 10)",
      "CNO Adm. Caudle: carrier deployment extensions have no clear endpoint - 'the enemy gets a vote'",
      "Pentagon internal memo (Mar 6) projected war through September - now exceeded"
    ],
    reconciliation: [
      "The declaratory policy ('taken care of', 'terminated', 'not at war') is irreconcilable with sustained two-carrier combat presence, 50,000+ deployed troops, and active CENTCOM strikes",
      "Sec. War Hegseth (Mar 19, Defense.gov): 'We wouldn't want to set a definitive timeframe' while Gen. Caine stated: 'we will continue major combat operations' — directly contradicting White House claims of resolution",
      "The rhetorical shift from 'just begun' (Mar 4) to 'terminated' (May 1) to 'not at war' (Sep 10) occurred while force levels remained constant or increased",
      "Economic pressure escalated simultaneously with military de-escalation rhetoric: Operation Economic Outcast (Aug 24, Treasury.gov) launched after White House declared war 'over'",
      "Treasury Sec. Bessent (Aug 24, Treasury.gov): 'America is no longer managing the Iranian threat — we are ending it' — framing as resolution while expanding sanctions",
      "The Pentagon's own projections (internal memo, CNO statements, Hegseth/Caine transcript) contradict White House claims of resolution — suggesting institutional awareness of a sustained conflict the political leadership declines to acknowledge",
      "President signed H.R. 5334 (Sep 18, White House) extending Iran sanctions into law — a legislative action inconsistent with claims the conflict is 'taken care of'",
      "Forward outlook through Dec 2026: Theodore Roosevelt deployment, sustained carrier presence, and continued OFAC actions indicate the operational reality will persist regardless of declaratory policy shifts",
      "Expert assessment (Panetta, Sep 6): war likely to continue another 6 months — through March 2027 — absent resolution"
    ]
  },

  // Methodology note
  methodology: "This dashboard compiles publicly reported statements, military actions, economic measures, and carrier positions. Primary sources are official government publications (whitehouse.gov, centcom.mil, defense.gov, treasury.gov/ofac, justice.gov, state.gov). Secondary sources include major wire services (Reuters, AP), established defense tracking (USNI News Fleet Tracker, Stripes), and major media (CBS, CNN, The Atlantic, Politico) where primary sources are unavailable — these are labeled accordingly. 'Real-time' carrier positioning reflects the latest publicly available reporting (USNI News Fleet Tracker, Sept 14, 2026), not operational tracking. No U.S. carrier is publicly confirmed inside the Persian Gulf; carriers operate in the Arabian Sea / Gulf of Oman area. Quotes are attributed to named speakers with dates and source URLs. The CENTCOM-confirmed exchanges of fire (Sept 5 and Sept 8) are presented as official CENTCOM releases; earlier Iranian claims of striking U.S. carriers are attributed to Iran's state media where referenced. Future projections through end-of-year 2026 are labeled as monitoring outlook, not established fact."
};
