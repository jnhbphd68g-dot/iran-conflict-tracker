const pptxgen = require('pptxgenjs');

const deck = new pptxgen();
deck.layout = 'LAYOUT_WIDE'; // 13.33" x 7.5"
deck.author = 'Perplexity Computer';
deck.company = 'Iran Conflict Policy Tracker';

// === DESIGN TOKENS ===
const COLORS = {
  bgDark: '0A0E14',
  surfaceDark: '111721',
  surfaceDark2: '161E2B',
  border: '283445',
  textPrimary: 'E8EDF3',
  textSecondary: '8B98A8',
  textMuted: '5A6878',
  accent: '3FB950',      // green for "operational"
  accentRed: 'F85149',   // red for "escalatory"
  accentBlue: '58A6FF',  // blue for "carrier"
  accentGold: 'D29922',   // gold for "economic"
  accentPurple: 'BC8CFF', // purple for "statement"
  white: 'FFFFFF',
  surfaceLight: 'F7F6F2',
  textDark: '28251D',
  textMutedLight: '7A7974',
};

const FONTS = {
  heading: 'Trebuchet MS',
  body: 'Calibri',
  mono: 'Consolas',
};

// Helper: source citation at bottom
function addSource(slide, sources) {
  const parts = [];
  sources.forEach((s, i) => {
    if (i > 0) parts.push({ text: ', ' });
    parts.push({ text: s.name, options: { hyperlink: { url: s.url }, color: COLORS.textMuted, fontSize: 9, fontFace: FONTS.body } });
  });
  parts.unshift({ text: 'Source: ', options: { color: COLORS.textMuted, fontSize: 9, fontFace: FONTS.body } });
  slide.addText(parts, { x: 0.5, y: 7.0, w: 12.3, h: 0.35, margin: 0 });
}

// === SLIDE 1: TITLE ===
{
  const sl = deck.addSlide();
  sl.background = { color: COLORS.bgDark };
  // Accent bar
  sl.addShape(deck.shapes.RECTANGLE, { x: 0, y: 0, w: 13.33, h: 0.08, fill: { color: COLORS.accent } });
  
  sl.addText('IRAN CONFLICT POLICY TRACKER', {
    x: 1, y: 1.8, w: 11, h: 0.8,
    fontFace: FONTS.heading, fontSize: 36, bold: true, color: COLORS.white, margin: 0,
  });
  sl.addText('Declaratory Policy vs. Force Posture Monitor', {
    x: 1, y: 2.6, w: 11, h: 0.5,
    fontFace: FONTS.body, fontSize: 20, color: COLORS.accent, margin: 0,
  });
  sl.addText('A Deep Dive Analysis', {
    x: 1, y: 3.3, w: 11, h: 0.4,
    fontFace: FONTS.body, fontSize: 16, color: COLORS.textSecondary, margin: 0,
  });
  sl.addText('Tracking conflicting statements from the White House, Attorney General, and Pentagon\nmapped against real-time U.S. naval force posture in the Persian Gulf region\nFebruary 28 – September 19, 2026', {
    x: 1, y: 4.2, w: 11, h: 1.2,
    fontFace: FONTS.body, fontSize: 13, color: COLORS.textMuted, margin: 0, lineSpacing: 22,
  });
  sl.addText('Updated September 19, 2026  ·  Carrier data: USNI Fleet Tracker, Sept 14', {
    x: 1, y: 6.5, w: 11, h: 0.4,
    fontFace: FONTS.body, fontSize: 11, color: COLORS.textMuted, margin: 0,
  });
}

// === SLIDE 2: KEY METRICS ===
{
  const sl = deck.addSlide();
  sl.background = { color: COLORS.surfaceDark };
  sl.addText('The Conflict at a Glance', {
    x: 0.5, y: 0.4, w: 12, h: 0.6,
    fontFace: FONTS.heading, fontSize: 28, bold: true, color: COLORS.white, margin: 0,
  });
  
  const stats = [
    { value: '~7 months', label: 'Conflict Duration', sub: 'Since Feb 28, 2026', accent: COLORS.accentRed },
    { value: '$33.4B+', label: 'Estimated Cost', sub: '$2-3B/month ongoing', accent: COLORS.accentGold },
    { value: '2', label: 'Carriers in CENTCOM', sub: 'Projected through Dec 2026', accent: COLORS.accentBlue },
    { value: '50,000+', label: 'Troops Deployed', sub: 'CENTCOM SASC Posture', accent: COLORS.accent },
    { value: '1,000+', label: 'Sanctions Imposed', sub: 'Since Feb 2025', accent: COLORS.accentGold },
    { value: '18', label: 'U.S. Casualties', sub: 'Service member deaths', accent: COLORS.accentRed },
  ];
  
  stats.forEach((s, i) => {
    const col = i % 3;
    const row = Math.floor(i / 3);
    const x = 0.5 + col * 4.2;
    const y = 1.4 + row * 2.6;
    
    sl.addShape(deck.shapes.RECTANGLE, {
      x: x, y: y, w: 3.8, h: 2.2,
      fill: { color: COLORS.surfaceDark2 },
      line: { color: COLORS.border, width: 0.5 },
    });
    sl.addShape(deck.shapes.RECTANGLE, {
      x: x, y: y, w: 0.08, h: 2.2,
      fill: { color: s.accent },
    });
    sl.addText(s.value, {
      x: x + 0.3, y: y + 0.3, w: 3.3, h: 0.7,
      fontFace: FONTS.heading, fontSize: 32, bold: true, color: s.accent, margin: 0,
    });
    sl.addText(s.label, {
      x: x + 0.3, y: y + 1.1, w: 3.3, h: 0.4,
      fontFace: FONTS.body, fontSize: 14, bold: true, color: COLORS.white, margin: 0,
    });
    sl.addText(s.sub, {
      x: x + 0.3, y: y + 1.5, w: 3.3, h: 0.3,
      fontFace: FONTS.body, fontSize: 11, color: COLORS.textMuted, margin: 0,
    });
  });
  
  addSource(sl, [
    { name: 'USNI News Fleet Tracker', url: 'https://news.usni.org/2026/09/14/usni-news-fleet-and-marine-tracker-sept-14-2026' },
    { name: 'CENTCOM SASC Posture Statement', url: 'https://www.centcom.mil/ABOUT-US/SASC-POSTURE-STATEMENT-2026/' },
    { name: 'Treasury OFAC', url: 'https://ofac.treasury.gov/sanctions-programs-and-country-information/iran-sanctions' },
  ]);
}

// === SLIDE 3: THE CORE CONTRADICTION ===
{
  const sl = deck.addSlide();
  sl.background = { color: COLORS.surfaceDark };
  sl.addText('The Core Contradiction', {
    x: 0.5, y: 0.4, w: 12, h: 0.6,
    fontFace: FONTS.heading, fontSize: 28, bold: true, color: COLORS.white, margin: 0,
  });
  
  // Left column: Declaratory Policy
  sl.addShape(deck.shapes.RECTANGLE, {
    x: 0.5, y: 1.3, w: 5.8, h: 5.2,
    fill: { color: COLORS.surfaceDark2 }, line: { color: COLORS.border, width: 0.5 },
  });
  sl.addText('WHAT THEY SAY', {
    x: 0.8, y: 1.5, w: 5.2, h: 0.4,
    fontFace: FONTS.heading, fontSize: 14, bold: true, color: COLORS.accent, margin: 0,
  });
  const sayItems = [
    '"The hostilities have terminated." — Trump, May 1',
    '"We achieved the objectives." — Rubio, May 5',
    '"The U.S. is not at war at all." — VP Vance, Sep 10',
    '"Taken care of." — Speaker Johnson, Sep 17',
    '"I disagree with that characterization." — AG Blanche, Sep 15',
    '"Hopefully we\'re toward the end of the war." — Trump, Sep 17',
  ];
  sayItems.forEach((item, i) => {
    sl.addText(item, {
      x: 0.8, y: 2.1 + i * 0.65, w: 5.2, h: 0.55,
      fontFace: FONTS.body, fontSize: 12, color: COLORS.textPrimary, margin: 0,
    });
  });
  
  // Right column: Observed Reality
  sl.addShape(deck.shapes.RECTANGLE, {
    x: 6.8, y: 1.3, w: 6, h: 5.2,
    fill: { color: COLORS.surfaceDark2 }, line: { color: COLORS.border, width: 0.5 },
  });
  sl.addText('WHAT THEY DO', {
    x: 7.1, y: 1.5, w: 5.4, h: 0.4,
    fontFace: FONTS.heading, fontSize: 14, bold: true, color: COLORS.accentRed, margin: 0,
  });
  const doItems = [
    '2 carriers in Arabian Sea (Sept 14)',
    '50,000+ troops deployed across CENTCOM',
    'CENTCOM strikes on IRGC targets (Sep 1, 5, 8)',
    'Operation Economic Outcast — "economic D-Day"',
    'H.R. 5334 signed: Iran sanctions extended into law',
    'Roosevelt deploying to relieve George Washington',
  ];
  doItems.forEach((item, i) => {
    sl.addText(item, {
      x: 7.1, y: 2.1 + i * 0.65, w: 5.4, h: 0.55,
      fontFace: FONTS.body, fontSize: 12, color: COLORS.textPrimary, margin: 0,
    });
  });
  
  addSource(sl, [
    { name: 'White House', url: 'https://www.whitehouse.gov' },
    { name: 'Defense.gov', url: 'https://www.defense.gov' },
    { name: 'CENTCOM', url: 'https://www.centcom.mil' },
    { name: 'Treasury', url: 'https://home.treasury.gov' },
  ]);
}

// === SLIDE 4: TIMELINE PART 1 — THE ESCALATION (FEB-MAR) ===
{
  const sl = deck.addSlide();
  sl.background = { color: COLORS.surfaceDark };
  sl.addText('Timeline Part 1: The Escalation', {
    x: 0.5, y: 0.4, w: 12, h: 0.6,
    fontFace: FONTS.heading, fontSize: 28, bold: true, color: COLORS.white, margin: 0,
  });
  sl.addText('February – March 2026: From first strikes to "only just begun"', {
    x: 0.5, y: 1.0, w: 12, h: 0.4,
    fontFace: FONTS.body, fontSize: 14, color: COLORS.textSecondary, margin: 0,
  });
  
  const events = [
    { date: 'Feb 6', text: 'Trump signs EO 14382 — 25% tariffs on countries doing business with Iran', source: 'White House', color: COLORS.accentGold },
    { date: 'Feb 28', text: 'Operation Epic Fury begins — 100+ aircraft, 1,000+ targets in 24 hours', source: 'Defense.gov', color: COLORS.accentRed },
    { date: 'Mar 2', text: 'Hegseth: "The mission is laser-focused... they will never have nuclear weapons"', source: 'Defense.gov', color: COLORS.accentPurple },
    { date: 'Mar 4', text: 'Hegseth: "We\'ve only just begun to hunt, dismantle, demoralize, destroy"', source: 'Defense.gov', color: COLORS.accentPurple },
    { date: 'Mar 6', text: 'Internal Pentagon memo: war expected through September 2026', source: "People's World", color: COLORS.accentRed },
    { date: 'Mar 15', text: 'White House NEC director: "Pentagon estimates 4-6 weeks for the war"', source: 'Fortune', color: COLORS.accentPurple },
    { date: 'Mar 19', text: 'Hegseth: "We wouldn\'t want to set a definitive timeframe"', source: 'Defense.gov transcript', color: COLORS.accentPurple },
    { date: 'Mar 19', text: 'Caine: "We will continue major combat operations"', source: 'Defense.gov transcript', color: COLORS.accentRed },
  ];
  
  events.forEach((e, i) => {
    const y = 1.7 + i * 0.65;
    sl.addShape(deck.shapes.RECTANGLE, { x: 0.5, y: y, w: 0.06, h: 0.55, fill: { color: e.color } });
    sl.addText(e.date, {
      x: 0.7, y: y, w: 1.0, h: 0.55,
      fontFace: FONTS.mono, fontSize: 11, bold: true, color: COLORS.textSecondary, margin: 0, valign: 'middle',
    });
    sl.addText(e.text, {
      x: 1.8, y: y, w: 8.5, h: 0.55,
      fontFace: FONTS.body, fontSize: 12, color: COLORS.textPrimary, margin: 0, valign: 'middle',
    });
    sl.addText(e.source, {
      x: 10.5, y: y, w: 2.3, h: 0.55,
      fontFace: FONTS.body, fontSize: 10, color: COLORS.textMuted, margin: 0, valign: 'middle', align: 'right',
    });
  });
  
  addSource(sl, [
    { name: 'Defense.gov', url: 'https://www.defense.gov/News/News-Stories/Article/Article/4418826/hegseth-says-epic-fury-goals-in-iran-are-laser-focused/' },
    { name: 'Defense.gov transcript', url: 'https://www.defense.gov/News/Transcripts/Transcript/Article/4438625/' },
    { name: 'White House', url: 'https://www.whitehouse.gov/presidential-actions/2026/02/addressing-threats-to-the-united-states-by-the-government-of-iran/' },
  ]);
}

// === SLIDE 5: TIMELINE PART 2 — THE PIVOT (APR-JUN) ===
{
  const sl = deck.addSlide();
  sl.background = { color: COLORS.surfaceDark };
  sl.addText('Timeline Part 2: The Pivot', {
    x: 0.5, y: 0.4, w: 12, h: 0.6,
    fontFace: FONTS.heading, fontSize: 28, bold: true, color: COLORS.white, margin: 0,
  });
  sl.addText('April – June 2026: From "war is over" to signing an MOU', {
    x: 0.5, y: 1.0, w: 12, h: 0.4,
    fontFace: FONTS.body, fontSize: 14, color: COLORS.textSecondary, margin: 0,
  });
  
  const events = [
    { date: 'Apr 1', text: 'Trump addresses nation: "clear and unchanging objectives"', source: 'White House', color: COLORS.accentPurple },
    { date: 'Apr 8', text: 'White House: "Peace Through Strength — Operation Epic Fury crushes Iranian threat"', source: 'White House', color: COLORS.accent },
    { date: 'Apr 25', text: 'Three carriers in Middle East — no carrier in Persian Gulf', source: 'House of Saud', color: COLORS.accentBlue },
    { date: 'May 1', text: 'Trump: "The hostilities have terminated" (war powers deadline)', source: 'Reuters', color: COLORS.accentPurple },
    { date: 'May 5', text: 'Rubio: "Operation Epic Fury is over. We achieved the objectives"', source: 'State Dept', color: COLORS.accentPurple },
    { date: 'Jun 10', text: 'OFAC sanctions 9 entities supporting Iran weapons procurement', source: 'Treasury', color: COLORS.accentGold },
    { date: 'Jun 19', text: 'White House: Trump-Vance sign MOU with Iran — "historic breakthrough"', source: 'White House', color: COLORS.accent },
  ];
  
  events.forEach((e, i) => {
    const y = 1.7 + i * 0.7;
    sl.addShape(deck.shapes.RECTANGLE, { x: 0.5, y: y, w: 0.06, h: 0.6, fill: { color: e.color } });
    sl.addText(e.date, {
      x: 0.7, y: y, w: 1.0, h: 0.6,
      fontFace: FONTS.mono, fontSize: 11, bold: true, color: COLORS.textSecondary, margin: 0, valign: 'middle',
    });
    sl.addText(e.text, {
      x: 1.8, y: y, w: 8.5, h: 0.6,
      fontFace: FONTS.body, fontSize: 12, color: COLORS.textPrimary, margin: 0, valign: 'middle',
    });
    sl.addText(e.source, {
      x: 10.5, y: y, w: 2.3, h: 0.6,
      fontFace: FONTS.body, fontSize: 10, color: COLORS.textMuted, margin: 0, valign: 'middle', align: 'right',
    });
  });
  
  addSource(sl, [
    { name: 'White House', url: 'https://www.whitehouse.gov/releases/2026/06/president-trumps-iran-agreement-is-america-first-in-action/' },
    { name: 'Reuters', url: 'https://www.reuters.com/world/asia-pacific/white-house-says-iran-war-terminated-war-powers-deadline-arrives-2026-05-01/' },
    { name: 'Treasury', url: 'https://home.treasury.gov/news/press-releases/sb0528' },
  ]);
}

// === SLIDE 6: TIMELINE PART 3 — SUSTAINED OPERATIONS (JUL-SEP) ===
{
  const sl = deck.addSlide();
  sl.background = { color: COLORS.surfaceDark };
  sl.addText('Timeline Part 3: Sustained Operations', {
    x: 0.5, y: 0.4, w: 12, h: 0.6,
    fontFace: FONTS.heading, fontSize: 28, bold: true, color: COLORS.white, margin: 0,
  });
  sl.addText('July – September 2026: "Taken care of" while strikes continue', {
    x: 0.5, y: 1.0, w: 12, h: 0.4,
    fontFace: FONTS.body, fontSize: 14, color: COLORS.textSecondary, margin: 0,
  });
  
  const events = [
    { date: 'Jul 7-20', text: 'CENTCOM conducts 4 rounds of strikes against Iran', source: 'CENTCOM', color: COLORS.accentRed },
    { date: 'Jul 29', text: 'OFAC disrupts IRGC Strait of Hormuz extortion scheme (100+ vessels sanctioned)', source: 'Treasury', color: COLORS.accentGold },
    { date: 'Aug 24', text: 'Operation Economic Outcast — "economic D-Day" — 5 sectoral sanctions', source: 'Treasury', color: COLORS.accentGold },
    { date: 'Sep 1', text: 'CENTCOM strikes on IRGC air defense, radar, maritime assets', source: 'CENTCOM', color: COLORS.accentRed },
    { date: 'Sep 5', text: 'CENTCOM destroys 3 IRGC tankers after Iran targets 2 U.S. warships', source: 'CENTCOM', color: COLORS.accentRed },
    { date: 'Sep 8', text: 'U.S. destroys 5 IRGC tankers — second exchange of fire in one week', source: 'CENTCOM', color: COLORS.accentRed },
    { date: 'Sep 10', text: 'Trump: "small potatoes" / VP Vance: "not at war at all"', source: 'The Atlantic', color: COLORS.accentPurple },
    { date: 'Sep 15', text: 'AG Blanche: "I disagree with that characterization"', source: 'CNN', color: COLORS.accentPurple },
    { date: 'Sep 17', text: 'Johnson: "taken care of" / Trump: "toward the end of the war"', source: 'CBS News', color: COLORS.accentPurple },
    { date: 'Sep 18', text: 'Trump signs H.R. 5334 — Graham Sanctioning Russia and Iran Act', source: 'White House', color: COLORS.accentGold },
  ];
  
  events.forEach((e, i) => {
    const y = 1.6 + i * 0.55;
    sl.addShape(deck.shapes.RECTANGLE, { x: 0.5, y: y, w: 0.06, h: 0.5, fill: { color: e.color } });
    sl.addText(e.date, {
      x: 0.7, y: y, w: 1.2, h: 0.5,
      fontFace: FONTS.mono, fontSize: 10, bold: true, color: COLORS.textSecondary, margin: 0, valign: 'middle',
    });
    sl.addText(e.text, {
      x: 2.0, y: y, w: 8.3, h: 0.5,
      fontFace: FONTS.body, fontSize: 11, color: COLORS.textPrimary, margin: 0, valign: 'middle',
    });
    sl.addText(e.source, {
      x: 10.5, y: y, w: 2.3, h: 0.5,
      fontFace: FONTS.body, fontSize: 9, color: COLORS.textMuted, margin: 0, valign: 'middle', align: 'right',
    });
  });
  
  addSource(sl, [
    { name: 'CENTCOM', url: 'https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/' },
    { name: 'Treasury', url: 'https://home.treasury.gov/news/press-releases/sb0613' },
    { name: 'White House', url: 'https://www.whitehouse.gov/briefings-statements/2026/09/congressional-bill-h-r-5334-signed-into-law/' },
  ]);
}

// === SLIDE 7: CONFLICT MATRIX ===
{
  const sl = deck.addSlide();
  sl.background = { color: COLORS.surfaceDark };
  sl.addText('Statement Conflict Matrix', {
    x: 0.5, y: 0.3, w: 12, h: 0.5,
    fontFace: FONTS.heading, fontSize: 26, bold: true, color: COLORS.white, margin: 0,
  });
  
  const headerStyle = { fill: { color: COLORS.surfaceDark2 }, fontSize: 11, bold: true, color: COLORS.white, fontFace: FONTS.body, align: 'center', valign: 'middle' };
  const cellStyle = { fontSize: 10, color: COLORS.textPrimary, fontFace: FONTS.body, valign: 'top' };
  const cellStyleAlt = { fontSize: 10, color: COLORS.textPrimary, fontFace: FONTS.body, valign: 'top', fill: { color: COLORS.surfaceDark2 } };
  
  const rows = [
    [
      { text: 'Issue', options: headerStyle },
      { text: 'White House', options: headerStyle },
      { text: 'Attorney General', options: headerStyle },
      { text: 'Pentagon', options: headerStyle },
    ],
    [
      { text: 'War Status', options: { ...cellStyle, bold: true } },
      { text: '"Terminated" (May 1)\n"Not at war" (Sep 10)', options: cellStyle },
      { text: '"I disagree with that characterization"\n— AG Blanche (Sep 15)', options: cellStyleAlt },
      { text: '"We will continue major combat operations"\n— Gen. Caine (Mar 19)', options: cellStyle },
    ],
    [
      { text: 'Duration', options: { ...cellStyleAlt, bold: true } },
      { text: '"4-6 weeks" (Mar 15)\n"Toward the end" (Sep 17)', options: cellStyleAlt },
      { text: '—', options: cellStyleAlt },
      { text: '"Only just begun" (Mar 4)\n"No definitive timeframe" (Mar 19)', options: cellStyleAlt },
    ],
    [
      { text: 'Nuclear Program', options: { ...cellStyle, bold: true } },
      { text: '"Taken care of" (Sep 17)\n"Never obtain a weapon" (Jun 19)', options: cellStyle },
      { text: '—', options: cellStyle },
      { text: 'CENTCOM strikes IRGC targets including missile/nuclear infrastructure (Sep 1)', options: cellStyle },
    ],
    [
      { text: 'Use of Force', options: { ...cellStyleAlt, bold: true } },
      { text: '"Small potatoes" (Sep 10)', options: cellStyleAlt },
      { text: '"Financial enforcement focus"', options: cellStyleAlt },
      { text: '"Each day we attack deeper into Iranian territory"\n— Gen. Caine (Mar 19)', options: cellStyleAlt },
    ],
    [
      { text: 'Economic Strategy', options: { ...cellStyle, bold: true } },
      { text: '"Toward the end of the war"\n— Trump (Sep 17)', options: cellStyle },
      { text: '"Working with Treasury to keep financial system clear"', options: cellStyle },
      { text: '"Economic onslaught... sever every lifeline"\n— Sec. Bessent (Aug 24)', options: cellStyle },
    ],
  ];
  
  sl.addTable(rows, {
    x: 0.5, y: 1.0, w: 12.3,
    colW: [1.8, 3.5, 3.5, 3.5],
    rowH: [0.4, 1.1, 1.0, 1.0, 0.9, 1.0],
    border: { type: 'solid', color: COLORS.border, pt: 0.5 },
    margin: [4, 6, 4, 6],
  });
  
  addSource(sl, [
    { name: 'Defense.gov', url: 'https://www.defense.gov/News/Transcripts/Transcript/Article/4438625/' },
    { name: 'Treasury', url: 'https://home.treasury.gov/news/press-releases/sb0613' },
    { name: 'CNN', url: 'https://transcripts.cnn.com/show/cnc/date/2026-09-15/segment/10' },
  ]);
}

// === SLIDE 8: ECONOMIC PRESSURE TRACKER ===
{
  const sl = deck.addSlide();
  sl.background = { color: COLORS.surfaceDark };
  sl.addText('Economic Pressure Campaign', {
    x: 0.5, y: 0.4, w: 12, h: 0.6,
    fontFace: FONTS.heading, fontSize: 28, bold: true, color: COLORS.white, margin: 0,
  });
  sl.addText('11 official actions from February to September 2026', {
    x: 0.5, y: 1.0, w: 12, h: 0.4,
    fontFace: FONTS.body, fontSize: 14, color: COLORS.textSecondary, margin: 0,
  });
  
  const actions = [
    { date: 'Feb 6', text: 'EO 14382 — 25% tariffs on countries trading with Iran', src: 'White House' },
    { date: 'Feb 6', text: 'State Dept sanctions 14 shadow fleet vessels', src: 'State Dept' },
    { date: 'Apr 28', text: 'OFAC sanctions 35 individuals/entities (1,000+ total)', src: 'Treasury' },
    { date: 'Jun 10', text: 'Economic Fury: 9 entities sanctioned for weapons procurement', src: 'Treasury' },
    { date: 'Jun 22', text: 'Iran General License X — authorizes oil sales through Aug 21', src: 'OFAC' },
    { date: 'Jul 29', text: 'OFAC disrupts Strait of Hormuz extortion scheme (100+ vessels)', src: 'Treasury' },
    { date: 'Aug 24', text: 'Operation Economic Outcast — "economic D-Day" — 5 lifelines targeted', src: 'Treasury' },
    { date: 'Sep 8', text: 'OFAC counter-terrorism designations + license updates', src: 'OFAC' },
    { date: 'Sep 17', text: 'Treasury: "sever every economic lifeline Tehran has left"', src: 'Treasury' },
    { date: 'Sep 18', text: 'H.R. 5334 — Graham Sanctioning Russia and Iran Act signed', src: 'White House' },
  ];
  
  actions.forEach((a, i) => {
    const y = 1.6 + i * 0.55;
    sl.addShape(deck.shapes.RECTANGLE, { x: 0.5, y: y, w: 0.06, h: 0.5, fill: { color: COLORS.accentGold } });
    sl.addText(a.date, {
      x: 0.7, y: y, w: 1.0, h: 0.5,
      fontFace: FONTS.mono, fontSize: 10, bold: true, color: COLORS.textSecondary, margin: 0, valign: 'middle',
    });
    sl.addText(a.text, {
      x: 1.8, y: y, w: 8.5, h: 0.5,
      fontFace: FONTS.body, fontSize: 11, color: COLORS.textPrimary, margin: 0, valign: 'middle',
    });
    sl.addText(a.src, {
      x: 10.5, y: y, w: 2.3, h: 0.5,
      fontFace: FONTS.body, fontSize: 9, color: COLORS.textMuted, margin: 0, valign: 'middle', align: 'right',
    });
  });
  
  addSource(sl, [
    { name: 'Treasury', url: 'https://home.treasury.gov/news/press-releases/sb0613' },
    { name: 'White House', url: 'https://www.whitehouse.gov/presidential-actions/2026/02/addressing-threats-to-the-united-states-by-the-government-of-iran/' },
  ]);
}

// === SLIDE 9: MILITARY OPERATIONS TRACKER ===
{
  const sl = deck.addSlide();
  sl.background = { color: COLORS.surfaceDark };
  sl.addText('Military Operations Tracker', {
    x: 0.5, y: 0.4, w: 12, h: 0.6,
    fontFace: FONTS.heading, fontSize: 28, bold: true, color: COLORS.white, margin: 0,
  });
  sl.addText('13 documented military actions from February to September 2026', {
    x: 0.5, y: 1.0, w: 12, h: 0.4,
    fontFace: FONTS.body, fontSize: 14, color: COLORS.textSecondary, margin: 0,
  });
  
  const actions = [
    { date: 'Feb 28', text: 'Operation Epic Fury — 100+ aircraft, 1,000+ targets in 24 hours', src: 'Defense.gov' },
    { date: 'Mar 4', text: 'US submarine torpedoes Iranian warship off Sri Lanka — first since WWII', src: 'Politico' },
    { date: 'Apr 13', text: 'USS Abraham Lincoln enters Gulf of Oman, 200km from Iranian coast', src: 'Baku.ws' },
    { date: 'Apr 25', text: 'Three carriers in Middle East — no carrier in Persian Gulf', src: 'House of Saud' },
    { date: 'Jul 7-20', text: 'CENTCOM conducts 4 rounds of strikes (Jul 7, 8, 13, 20)', src: 'CENTCOM' },
    { date: 'Jul 23', text: '13th night of precision strikes on Iranian military targets', src: 'CENTCOM' },
    { date: 'Sep 1', text: 'CENTCOM strikes IRGC air defense, radar, maritime, mine-laying', src: 'CENTCOM' },
    { date: 'Sep 5', text: 'CENTCOM destroys 3 IRGC tankers — Iran targeted 2 U.S. warships', src: 'CENTCOM' },
    { date: 'Sep 8', text: 'U.S. destroys 5 IRGC tankers — second exchange in one week', src: 'CENTCOM' },
    { date: 'Sep 14', text: 'Roosevelt in San Diego preparing to deploy; relieve George Washington', src: 'USNI/Stripes' },
  ];
  
  actions.forEach((a, i) => {
    const y = 1.6 + i * 0.55;
    sl.addShape(deck.shapes.RECTANGLE, { x: 0.5, y: y, w: 0.06, h: 0.5, fill: { color: COLORS.accentRed } });
    sl.addText(a.date, {
      x: 0.7, y: y, w: 1.2, h: 0.5,
      fontFace: FONTS.mono, fontSize: 10, bold: true, color: COLORS.textSecondary, margin: 0, valign: 'middle',
    });
    sl.addText(a.text, {
      x: 2.0, y: y, w: 8.3, h: 0.5,
      fontFace: FONTS.body, fontSize: 11, color: COLORS.textPrimary, margin: 0, valign: 'middle',
    });
    sl.addText(a.src, {
      x: 10.5, y: y, w: 2.3, h: 0.5,
      fontFace: FONTS.body, fontSize: 9, color: COLORS.textMuted, margin: 0, valign: 'middle', align: 'right',
    });
  });
  
  addSource(sl, [
    { name: 'Defense.gov', url: 'https://www.defense.gov/News/News-Stories/Article/Article/4418826/hegseth-says-epic-fury-goals-in-iran-are-laser-focused/' },
    { name: 'CENTCOM', url: 'https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/' },
    { name: 'USNI News', url: 'https://news.usni.org/2026/09/14/usni-news-fleet-and-marine-tracker-sept-14-2026' },
  ]);
}

// === SLIDE 10: CARRIER POSTURE ===
{
  const sl = deck.addSlide();
  sl.background = { color: COLORS.surfaceDark };
  sl.addText('Carrier Posture (Sept 14, 2026)', {
    x: 0.5, y: 0.4, w: 12, h: 0.6,
    fontFace: FONTS.heading, fontSize: 28, bold: true, color: COLORS.white, margin: 0,
  });
  
  const carriers = [
    {
      name: 'USS George Washington (CVN-73)',
      status: 'Deployed — Arabian Sea',
      detail: 'CSG-5 · Homeport: Yokosuka · Enforcing blockade, night flight operations',
      color: COLORS.accent,
    },
    {
      name: 'USS George H. W. Bush (CVN-77)',
      status: 'Deployed — Arabian Sea',
      detail: 'CSG-10 · Homeport: Norfolk · In region since April 2026',
      color: COLORS.accent,
    },
    {
      name: 'USS Abraham Lincoln (CVN-72)',
      status: 'Returning — South China Sea',
      detail: '264 days at sea · 1.5M+ lbs ordnance · Heading to San Diego',
      color: COLORS.textSecondary,
    },
    {
      name: 'USS Theodore Roosevelt (CVN-71)',
      status: 'Preparing — San Diego',
      detail: 'CSG-3 · Expected to deploy in coming weeks to relieve GW',
      color: COLORS.accentGold,
    },
  ];
  
  carriers.forEach((c, i) => {
    const y = 1.2 + i * 1.35;
    sl.addShape(deck.shapes.RECTANGLE, {
      x: 0.5, y: y, w: 12.3, h: 1.2,
      fill: { color: COLORS.surfaceDark2 }, line: { color: COLORS.border, width: 0.5 },
    });
    sl.addShape(deck.shapes.RECTANGLE, { x: 0.5, y: y, w: 0.08, h: 1.2, fill: { color: c.color } });
    sl.addText(c.name, {
      x: 0.8, y: y + 0.15, w: 7, h: 0.35,
      fontFace: FONTS.heading, fontSize: 14, bold: true, color: COLORS.white, margin: 0,
    });
    sl.addText(c.status, {
      x: 8.5, y: y + 0.15, w: 4, h: 0.35,
      fontFace: FONTS.body, fontSize: 12, bold: true, color: c.color, margin: 0, align: 'right',
    });
    sl.addText(c.detail, {
      x: 0.8, y: y + 0.55, w: 11.5, h: 0.5,
      fontFace: FONTS.body, fontSize: 11, color: COLORS.textSecondary, margin: 0,
    });
  });
  
  // Regional note
  sl.addShape(deck.shapes.RECTANGLE, {
    x: 0.5, y: 6.6, w: 12.3, h: 0.4,
    fill: { color: COLORS.border },
  });
  sl.addText('No U.S. carrier is publicly confirmed inside the Persian Gulf. All carriers operate in the Arabian Sea / Gulf of Oman area.', {
    x: 0.7, y: 6.6, w: 12, h: 0.4,
    fontFace: FONTS.body, fontSize: 11, color: COLORS.textSecondary, margin: 0, valign: 'middle', italic: true,
  });
  
  addSource(sl, [
    { name: 'USNI News Fleet Tracker', url: 'https://news.usni.org/2026/09/14/usni-news-fleet-and-marine-tracker-sept-14-2026' },
    { name: 'CENTCOM SASC Posture', url: 'https://www.centcom.mil/ABOUT-US/SASC-POSTURE-STATEMENT-2026/' },
  ]);
}

// === SLIDE 11: RECONCILIATION ANALYSIS ===
{
  const sl = deck.addSlide();
  sl.background = { color: COLORS.surfaceDark };
  sl.addText('Reconciliation Assessment', {
    x: 0.5, y: 0.4, w: 12, h: 0.6,
    fontFace: FONTS.heading, fontSize: 28, bold: true, color: COLORS.white, margin: 0,
  });
  
  const columns = [
    {
      title: 'Declaratory Policy',
      color: COLORS.accent,
      items: [
        'War "terminated" (May 1)',
        '"Not at war at all" (Sep 10)',
        '"Taken care of" (Sep 17)',
        'AG: "I disagree"',
        'MOU signed with Iran (Jun 19)',
        '"Toward the end" (Sep 17)',
      ],
    },
    {
      title: 'Observed Force Posture',
      color: COLORS.accentRed,
      items: [
        '2 carriers in Arabian Sea',
        '50,000+ troops deployed',
        'CENTCOM strikes Sep 1, 5, 8',
        'Caine: "continue major combat"',
        'Hegseth: "no definitive timeframe"',
        'Roosevelt deploying to relieve GW',
      ],
    },
    {
      title: 'The Gap',
      color: COLORS.accentGold,
      items: [
        'Rhetoric shifted from "just begun" to "terminated" while force levels held constant',
        'Economic Outcast launched AFTER "war is over"',
        'H.R. 5334 extends sanctions — inconsistent with "taken care of"',
        'Pentagon projections contradict White House claims',
        'Panetta: 6 more months likely (through Mar 2027)',
        'Forward outlook: operational reality persists regardless of rhetoric',
      ],
    },
  ];
  
  columns.forEach((col, i) => {
    const x = 0.5 + i * 4.3;
    sl.addShape(deck.shapes.RECTANGLE, {
      x: x, y: 1.2, w: 4, h: 5.4,
      fill: { color: COLORS.surfaceDark2 }, line: { color: COLORS.border, width: 0.5 },
    });
    sl.addShape(deck.shapes.RECTANGLE, { x: x, y: 1.2, w: 4, h: 0.08, fill: { color: col.color } });
    sl.addText(col.title, {
      x: x + 0.2, y: 1.4, w: 3.6, h: 0.4,
      fontFace: FONTS.heading, fontSize: 14, bold: true, color: col.color, margin: 0,
    });
    col.items.forEach((item, j) => {
      sl.addText(item, {
        x: x + 0.2, y: 2.0 + j * 0.75, w: 3.6, h: 0.7,
        fontFace: FONTS.body, fontSize: 11, color: COLORS.textPrimary, margin: 0, valign: 'top',
      });
    });
  });
  
  addSource(sl, [
    { name: 'Defense.gov', url: 'https://www.defense.gov/News/Transcripts/Transcript/Article/4438625/' },
    { name: 'Treasury', url: 'https://home.treasury.gov/news/press-releases/sb0613' },
    { name: 'White House', url: 'https://www.whitehouse.gov/briefings-statements/2026/09/congressional-bill-h-r-5334-signed-into-law/' },
  ]);
}

// === SLIDE 12: KEY QUOTES ===
{
  const sl = deck.addSlide();
  sl.background = { color: COLORS.bgDark };
  sl.addText('Key Quotes: The Rhetorical Arc', {
    x: 0.5, y: 0.4, w: 12, h: 0.6,
    fontFace: FONTS.heading, fontSize: 28, bold: true, color: COLORS.white, margin: 0,
  });
  
  const quotes = [
    { quote: '"We\'ve only just begun to hunt, dismantle, demoralize, destroy and defeat their capabilities."', speaker: 'Sec. War Hegseth', date: 'Mar 4, 2026', color: COLORS.accentRed },
    { quote: '"The hostilities have terminated."', speaker: 'President Trump', date: 'May 1, 2026', color: COLORS.accent },
    { quote: '"We wouldn\'t want to set a definitive timeframe. But we are very much on plan."', speaker: 'Sec. War Hegseth', date: 'Mar 19, 2026', color: COLORS.accentGold },
    { quote: '"Each day we continue to attack deeper into Iranian territory. The pressure will continue."', speaker: 'Gen. Caine, CJCS', date: 'Mar 19, 2026', color: COLORS.accentRed },
    { quote: '"The U.S. is not at war at all."', speaker: 'VP Vance', date: 'Sep 10, 2026', color: COLORS.accent },
    { quote: '"I disagree with that characterization, as does most of Congress."', speaker: 'AG Todd Blanche', date: 'Sep 15, 2026', color: COLORS.accentPurple },
    { quote: '"Hopefully we\'re toward the end of the war. They want to make a deal."', speaker: 'President Trump', date: 'Sep 17, 2026', color: COLORS.accent },
    { quote: '"An economic onslaught... sever every economic lifeline."', speaker: 'Treasury Sec. Bessent', date: 'Aug 24, 2026', color: COLORS.accentGold },
  ];
  
  quotes.forEach((q, i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    const x = 0.5 + col * 6.3;
    const y = 1.2 + row * 1.45;
    
    sl.addShape(deck.shapes.RECTANGLE, {
      x: x, y: y, w: 5.8, h: 1.3,
      fill: { color: COLORS.surfaceDark }, line: { color: COLORS.border, width: 0.5 },
    });
    sl.addShape(deck.shapes.RECTANGLE, { x: x, y: y, w: 0.06, h: 1.3, fill: { color: q.color } });
    sl.addText(q.quote, {
      x: x + 0.25, y: y + 0.1, w: 5.3, h: 0.7,
      fontFace: FONTS.body, fontSize: 11, color: COLORS.textPrimary, margin: 0, italic: true,
    });
    sl.addText(`— ${q.speaker}, ${q.date}`, {
      x: x + 0.25, y: y + 0.85, w: 5.3, h: 0.35,
      fontFace: FONTS.body, fontSize: 10, color: COLORS.textMuted, margin: 0,
    });
  });
  
  addSource(sl, [
    { name: 'Defense.gov', url: 'https://www.defense.gov/News/Transcripts/Transcript/Article/4438625/' },
    { name: 'CNN', url: 'https://transcripts.cnn.com/show/cnc/date/2026-09-15/segment/10' },
    { name: 'Treasury', url: 'https://home.treasury.gov/news/press-releases/sb0613' },
  ]);
}

// === SLIDE 13: SOURCES & METHODOLOGY ===
{
  const sl = deck.addSlide();
  sl.background = { color: COLORS.surfaceDark };
  sl.addText('Sources & Methodology', {
    x: 0.5, y: 0.4, w: 12, h: 0.6,
    fontFace: FONTS.heading, fontSize: 28, bold: true, color: COLORS.white, margin: 0,
  });
  
  const sources = [
    { category: 'Primary Government Sources', items: [
      'White House (whitehouse.gov) — EO 14382, MOU, H.R. 5334, Operation Economic Outcast',
      'Defense.gov — Hegseth briefings, transcripts, fact sheets',
      'CENTCOM (centcom.mil) — Operation Epic Fury, strike releases, SASC Posture Statement',
      'Treasury (treasury.gov) — OFAC sanctions, Operation Economic Outcast, Hormuz disruption',
      'State Department — Shadow fleet sanctions',
    ]},
    { category: 'Secondary Sources', items: [
      'USNI News Fleet Tracker — Carrier positions (Sept 14, 2026)',
      'Reuters, CBS News, CNN — Key quotes and statements',
      'The Atlantic — "Trump is Preparing for a Long War"',
      'Politico — Hegseth "only just begun" coverage',
      'Stripes — Carrier deployment details',
    ]},
    { category: 'Methodology Notes', items: [
      'Primary government sources prioritized over media reporting',
      'Quotes attributed to named speakers with dates and source URLs',
      'No U.S. carrier publicly confirmed inside Persian Gulf',
      'Future projections labeled as monitoring outlook, not established fact',
      '52 timeline events, 11 economic actions, 13 military actions tracked',
    ]},
  ];
  
  sources.forEach((s, i) => {
    const y = 1.2 + i * 1.9;
    sl.addText(s.category, {
      x: 0.5, y: y, w: 12, h: 0.35,
      fontFace: FONTS.heading, fontSize: 14, bold: true, color: COLORS.accent, margin: 0,
    });
    s.items.forEach((item, j) => {
      sl.addText(`• ${item}`, {
        x: 0.7, y: y + 0.35 + j * 0.3, w: 11.5, h: 0.28,
        fontFace: FONTS.body, fontSize: 11, color: COLORS.textSecondary, margin: 0,
      });
    });
  });
}

// === SLIDE 14: CLOSING ===
{
  const sl = deck.addSlide();
  sl.background = { color: COLORS.bgDark };
  sl.addShape(deck.shapes.RECTANGLE, { x: 0, y: 0, w: 13.33, h: 0.08, fill: { color: COLORS.accent } });
  
  sl.addText('The gap between rhetoric and reality', {
    x: 1, y: 2.0, w: 11, h: 0.6,
    fontFace: FONTS.heading, fontSize: 28, bold: true, color: COLORS.white, margin: 0,
  });
  sl.addText('is the story of this conflict.', {
    x: 1, y: 2.6, w: 11, h: 0.6,
    fontFace: FONTS.heading, fontSize: 28, bold: true, color: COLORS.accent, margin: 0,
  });
  
  sl.addText('The White House says the war is "taken care of."\nThe Pentagon says it will "continue major combat operations."\nTwo carriers patrol the Arabian Sea. 50,000 troops remain deployed.\nThe Treasury launches an "economic D-Day."\nAnd Congress extends Iran sanctions into law.\n\nThe operational reality persists — regardless of the rhetoric.', {
    x: 1, y: 3.5, w: 11, h: 2.5,
    fontFace: FONTS.body, fontSize: 14, color: COLORS.textSecondary, margin: 0, lineSpacing: 24,
  });
  
  sl.addText('Iran Conflict Policy Tracker  ·  Updated September 19, 2026', {
    x: 1, y: 6.5, w: 11, h: 0.4,
    fontFace: FONTS.body, fontSize: 11, color: COLORS.textMuted, margin: 0,
  });
}

// === EXPORT ===
(async () => {
  await deck.writeFile({ fileName: '/home/user/workspace/iran-dashboard/deep-dive-manuscript.pptx' });
  console.log('PPTX generated successfully');
})();
