const fs = require('fs');
const docx = require('docx');
const {
  Document, Packer, Paragraph, TextRun,
  Header, Footer, AlignmentType, HeadingLevel,
  ExternalHyperlink, PageNumber, ShadingType,
  Table, TableRow, TableCell, WidthType, BorderStyle,
} = docx;

const FONT = 'Calibri';
const COLOR_ACCENT = '01696F';
const COLOR_RED = 'A12C2C';
const COLOR_GREEN = '437A22';
const COLOR_STAGE = '8B98A8';
const COLOR_DONE = '437A22';
const COLOR_TODO = '555555';

function checkItem(text, done = false) {
  const box = done ? '\u2611' : '\u2610';
  const color = done ? COLOR_DONE : COLOR_TODO;
  return new Paragraph({
    spacing: { before: 40, after: 40, line: 360 },
    indent: { left: 360 },
    children: [
      new TextRun({ text: `${box}  `, size: 24, font: FONT, color }),
      new TextRun({ text, size: 22, font: FONT, color }),
    ],
  });
}

function sectionTitle(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 160 },
    children: [new TextRun({ text, bold: true, size: 32, font: FONT, color: COLOR_ACCENT })],
  });
}

function subTitle(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 280, after: 120 },
    children: [new TextRun({ text, bold: true, size: 26, font: FONT, color: COLOR_RED })],
  });
}

function note(text) {
  return new Paragraph({
    spacing: { before: 60, after: 100 },
    indent: { left: 720 },
    children: [new TextRun({ text: `\u2192 ${text}`, italics: true, size: 20, font: FONT, color: COLOR_STAGE })],
  });
}

function divider() {
  return new Paragraph({
    spacing: { before: 200, after: 200 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: '\u2014 \u2014 \u2014 \u2014 \u2014', color: COLOR_STAGE, size: 20 })],
  });
}

const content = [
  // Cover
  new Paragraph({
    spacing: { before: 2000, after: 200 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'THE ENDICOTT EDGE', bold: true, size: 56, font: FONT, color: COLOR_ACCENT })],
  }),
  new Paragraph({
    spacing: { before: 0, after: 100 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'TRUTH \u2605 VERIFIED', bold: true, size: 28, font: FONT, color: COLOR_RED })],
  }),
  new Paragraph({
    spacing: { before: 200, after: 100 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'Mixed Messages: The Iran Conflict', size: 32, font: FONT, color: '555555' })],
  }),
  new Paragraph({
    spacing: { before: 100, after: 400 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'Podcast Launch Checklist', size: 36, font: FONT, color: COLOR_ACCENT, bold: true })],
  }),
  new Paragraph({
    spacing: { before: 200, after: 100 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'Complete step-by-step guide to launch your 4-episode series\non podcast platforms and YouTube', size: 22, font: FONT, color: COLOR_STAGE, italics: true })],
  }),
  new Paragraph({
    spacing: { before: 300, after: 0 },
    alignment: AlignmentType.CENTER,
    children: [
      new ExternalHyperlink({
        children: [new TextRun({ text: 'https://iran-conflict-tracker.pplx.app', style: 'Hyperlink', size: 20 })],
        link: 'https://iran-conflict-tracker.pplx.app',
      }),
    ],
  }),

  // === PHASE 1: CONTENT ASSETS ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  sectionTitle('PHASE 1: CONTENT ASSETS (PRE-PRODUCTION)'),
  new Paragraph({
    spacing: { before: 0, after: 160 },
    children: [new TextRun({ text: 'All assets below have been created and are ready to use.', italics: true, size: 22, font: FONT, color: COLOR_STAGE })],
  }),

  subTitle('Scripts & Research'),
  checkItem('Deep Dive Manuscript (14-slide PPTX) — importable to Google Slides', true),
  note('File: deep-dive-manuscript.pptx'),
  checkItem('4 conversational podcast scripts (DOCX) with stage directions, pauses, image cues, and running times', true),
  note('File: podcast-scripts-conversational.docx'),
  note('Ep 1: The War That Isn\'t a War (~35-40 min)'),
  note('Ep 2: Economic D-Day (~35-40 min)'),
  note('Ep 3: Carriers and Combat (~35-40 min)'),
  note('Ep 4: The Reconciliation (~35-40 min)'),
  checkItem('Interactive dashboard with 52 timeline events, all sources cited', true),
  note('URL: https://iran-conflict-tracker.pplx.app'),

  subTitle('Visual Assets'),
  checkItem('4 podcast episode covers (1:1 square, 3000x3000px) with Endicott Edge branding', true),
  note('Ep 1 cover, Ep 2 cover, Ep 3 cover, Ep 4 cover'),
  checkItem('YouTube channel banner (16:9 widescreen) with Endicott Edge branding', true),
  checkItem('4 YouTube video thumbnails (1280x720, 16:9) with hook text and host image', true),
  note('Ep 1: "THE WAR THAT ISN\'T A WAR"'),
  note('Ep 2: "ECONOMIC D-DAY"'),
  note('Ep 3: "CARRIERS & COMBAT"'),
  note('Ep 4: "THE RECONCILIATION"'),

  subTitle('Social Media'),
  checkItem('22 social media posts across X/Twitter, Facebook, Instagram, and LinkedIn', true),
  note('File: social-media-posts.docx'),
  note('Includes series launch teaser, per-episode posts (main + thread), and series wrap-up'),
  checkItem('All posts include dashboard URL and relevant hashtags', true),

  subTitle('Remaining Content Tasks'),
  checkItem('Record intro/outro audio (if using custom intro)'),
  checkItem('Select background music / theme music (royalty-free sources: Epidemic Sound, Artlist, YouTube Audio Library)'),
  checkItem('Record voice-over for any video segments (if producing video versions)'),

  divider(),

  // === PHASE 2: PLATFORM SETUP ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  sectionTitle('PHASE 2: PLATFORM SETUP'),

  subTitle('Podcast Hosting Platform'),
  new Paragraph({
    spacing: { before: 60, after: 120 },
    children: [new TextRun({ text: 'Choose ONE hosting platform. Your show art, RSS feed, and episode distribution all run through this service.', size: 22, font: FONT, color: COLOR_STAGE, italics: true })],
  }),
  checkItem('Choose a podcast host: Buzzsprout ($12/mo), Podbean ($14/mo), Libsyn ($15/mo), or Spotify for Podcasters (free)'),
  checkItem('Create account and set up show profile'),
  checkItem('Upload podcast cover art (use Episode 1 cover or your main Endicott Edge show art)'),
  note('Recommended: Use your circular Endicott Edge seal as the main show cover, then use episode-specific covers as episode artwork'),
  checkItem('Write show title: "The Endicott Edge"'),
  checkItem('Write show description (see template below)'),
  new Paragraph({
    spacing: { before: 40, after: 80 },
    indent: { left: 720 },
    children: [
      new TextRun({ text: 'Show Description Template:\n', bold: true, size: 20, font: FONT, color: COLOR_ACCENT }),
      new TextRun({ text: '"The Endicott Edge breaks down the gap between what politicians say and what the government actually does. Host [Your Name] tracks every statement, every vote, and every policy shift — then maps them against the facts. Truth Verified.\n\nCurrent Series: Mixed Messages — The Iran Conflict. A 4-episode deep dive into the 2026 Iran conflict, tracking 52 timeline events from Operation Epic Fury to the September declarations of peace. Every quote cited. Every date verified. Every source linked.\n\nFull interactive dashboard: https://iran-conflict-tracker.pplx.app"', italics: true, size: 20, font: FONT, color: COLOR_STAGE }),
    ],
  }),
  checkItem('Select podcast category: Government & Organizations or News'),
  checkItem('Set explicit content flag: No (clean)'),
  checkItem('Copy your RSS feed URL (provided by hosting platform)'),

  subTitle('Apple Podcasts'),
  checkItem('Go to podcasters.apple.com and sign in with Apple ID'),
  checkItem('Submit your RSS feed URL'),
  note('Apple approval takes 1-5 days — submit early'),
  checkItem('Verify show appears in Apple Podcasts directory'),

  subTitle('Spotify'),
  checkItem('Go to podcasters.spotify.com and sign in'),
  checkItem('Submit your RSS feed URL'),
  note('Spotify approval typically takes 1-2 days'),
  checkItem('Verify show appears in Spotify directory'),

  subTitle('YouTube'),
  checkItem('Create or use existing YouTube channel'),
  checkItem('Upload YouTube channel banner'),
  note('File: youtube-banner-v4-final.png'),
  checkItem('Set channel name: "The Endicott Edge"'),
  checkItem('Write channel description (same as podcast show description)'),
  checkItem('Add channel keywords: political podcast, Iran conflict, foreign policy, national security, government accountability, truth verified'),
  checkItem('Upload channel trailer (optional — can add later)'),

  subTitle('Social Media Accounts'),
  checkItem('Create or update X/Twitter account (@[YourHandle])'),
  checkItem('Create or update Facebook page ("The Endicott Edge")'),
  checkItem('Create or update Instagram account (@[YourHandle])'),
  checkItem('Create or update LinkedIn page'),
  checkItem('Use your Endicott Edge seal/logo as profile picture on all platforms'),
  checkItem('Add dashboard URL to all bios: https://iran-conflict-tracker.pplx.app'),

  divider(),

  // === PHASE 3: RECORDING ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  sectionTitle('PHASE 3: RECORDING & EDITING'),

  subTitle('Pre-Recording'),
  checkItem('Review conversational script for each episode'),
  checkItem('Print or load scripts on tablet/teleprompter'),
  checkItem('Test microphone levels and audio quality'),
  checkItem('Set up recording software (Audacity, GarageBand, Adobe Audition, or Descript)'),
  checkItem('Prepare any image/video inserts referenced in scripts ([IMAGE: ...] cues)'),

  subTitle('Recording Each Episode'),
  new Paragraph({
    spacing: { before: 60, after: 80 },
    children: [new TextRun({ text: 'Record in this order for best pacing:', italics: true, size: 22, font: FONT, color: COLOR_STAGE })],
  }),
  checkItem('Record Episode 1: "The War That Isn\'t a War" (target: 35-40 min)'),
  checkItem('Record Episode 2: "Economic D-Day" (target: 35-40 min)'),
  checkItem('Record Episode 3: "Carriers and Combat" (target: 35-40 min)'),
  checkItem('Record Episode 4: "The Reconciliation" (target: 35-40 min)'),

  subTitle('Audio Editing'),
  checkItem('Edit each episode — remove mistakes, long pauses, retakes'),
  checkItem('Add intro music (5-10 second theme sting)'),
  checkItem('Add outro music (10-15 second fade)'),
  checkItem('Insert any sound effects referenced in stage directions (air raid siren, jet engines, ticking clock)'),
  checkItem('Insert image cues as video overlays (if producing video versions)'),
  note('Image cues from scripts: dashboard screenshots, title cards, timeline tabs'),
  checkItem('Master audio levels (loudness target: -16 LUFS for podcasts, -14 LUFS for YouTube)'),
  checkItem('Export audio: MP3 at 128-192 kbps for podcast, WAV for backup'),
  checkItem('Export video: MP4 at 1080p for YouTube (if producing video versions)'),

  divider(),

  // === PHASE 4: PUBLISHING ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  sectionTitle('PHASE 4: PUBLISHING'),

  subTitle('Podcast Episodes (Audio)'),
  new Paragraph({
    spacing: { before: 60, after: 80 },
    children: [new TextRun({ text: 'Upload all 4 episodes to your podcast host. Schedule them for staggered release or publish all at once.', italics: true, size: 22, font: FONT, color: COLOR_STAGE })],
  }),
  checkItem('Upload Episode 1 audio file to podcast host'),
  checkItem('Set Episode 1 title: "The War That Isn\'t a War | The Endicott Edge"'),
  checkItem('Write Episode 1 description (include key quotes, sources, dashboard link)'),
  checkItem('Set Episode 1 cover art (use Ep 1 cover image)'),
  checkItem('Upload Episode 2 audio file to podcast host'),
  checkItem('Set Episode 2 title: "Economic D-Day | The Endicott Edge"'),
  checkItem('Write Episode 2 description'),
  checkItem('Set Episode 2 cover art'),
  checkItem('Upload Episode 3 audio file to podcast host'),
  checkItem('Set Episode 3 title: "Carriers and Combat | The Endicott Edge"'),
  checkItem('Write Episode 3 description'),
  checkItem('Set Episode 3 cover art'),
  checkItem('Upload Episode 4 audio file to podcast host'),
  checkItem('Set Episode 4 title: "The Reconciliation | The Endicott Edge"'),
  checkItem('Write Episode 4 description'),
  checkItem('Set Episode 4 cover art'),

  subTitle('Scheduling Strategy (Choose One)'),
  new Paragraph({
    spacing: { before: 60, after: 80 },
    children: [new TextRun({ text: 'Option A — All at Once (Binge Release)', bold: true, size: 22, font: FONT, color: COLOR_ACCENT })],
  }),
  note('Publish all 4 episodes on launch day. Best for building momentum and getting listeners hooked.'),
  new Paragraph({
    spacing: { before: 60, after: 80 },
    children: [new TextRun({ text: 'Option B — Weekly Release', bold: true, size: 22, font: FONT, color: COLOR_ACCENT })],
  }),
  note('Publish one episode per week for 4 weeks. Best for sustaining engagement and building audience over time.'),
  new Paragraph({
    spacing: { before: 60, after: 80 },
    children: [new TextRun({ text: 'Option C — Two at Launch, Then Weekly', bold: true, size: 22, font: FONT, color: COLOR_ACCENT })],
  }),
  note('Publish Episodes 1-2 on launch day, then Episodes 3-4 on subsequent weeks. Hybrid approach.'),

  subTitle('YouTube Videos'),
  checkItem('Upload Episode 1 video to YouTube with thumbnail'),
  note('Thumbnail: youtube-thumb-ep1-final.png'),
  checkItem('Upload Episode 2 video to YouTube with thumbnail'),
  note('Thumbnail: youtube-thumb-ep2-final.png'),
  checkItem('Upload Episode 3 video to YouTube with thumbnail'),
  note('Thumbnail: youtube-thumb-ep3-final.png'),
  checkItem('Upload Episode 4 video to YouTube with thumbnail'),
  note('Thumbnail: youtube-thumb-ep4-final.png'),
  checkItem('Create YouTube playlist: "Mixed Messages: The Iran Conflict"'),
  checkItem('Add all 4 videos to playlist'),
  checkItem('Set playlist description with dashboard link'),
  checkItem('Add end screens linking to next episode'),
  checkItem('Add cards linking to the dashboard URL'),

  subTitle('Episode Descriptions Template'),
  new Paragraph({
    spacing: { before: 40, after: 80 },
    indent: { left: 720 },
    children: [
      new TextRun({ text: 'YouTube/Podcast Description Template:\n', bold: true, size: 20, font: FONT, color: COLOR_ACCENT }),
      new TextRun({ text: '"The White House says the war is "taken care of." The Pentagon says it will "continue major combat operations." Both can\'t be right.\n\nIn Episode [N] of Mixed Messages: The Iran Conflict, [Your Name] breaks down [episode topic]. Every quote cited. Every date verified. Every source linked.\n\nFull interactive dashboard with 52 timeline events: https://iran-conflict-tracker.pplx.app\n\n\u2014\u2014\u2014\nThe Endicott Edge | Truth Verified\nReal Talk. Real Strategies. Real Results.\nFollow us: [social media links]"\n\nAdd timestamps for each segment:\n00:00 - Cold Open\n02:00 - Segment 1\n10:00 - Segment 2\n18:00 - Segment 3\n26:00 - Segment 4\n34:00 - Closing"', italics: true, size: 20, font: FONT, color: COLOR_STAGE }),
    ],
  }),

  divider(),

  // === PHASE 5: LAUNCH ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  sectionTitle('PHASE 5: LAUNCH DAY'),

  subTitle('Pre-Launch (Day Before)'),
  checkItem('Confirm all episodes are scheduled/published on podcast host'),
  checkItem('Confirm all YouTube videos are scheduled'),
  checkItem('Prepare social media posts from the promotion pack'),
  note('File: social-media-posts.docx — 22 posts ready to copy/paste'),
  checkItem('Test dashboard link on mobile and desktop'),
  checkItem('Prepare email newsletter (if you have a list)'),

  subTitle('Launch Day'),
  checkItem('Verify episodes are live on Apple Podcasts'),
  checkItem('Verify episodes are live on Spotify'),
  checkItem('Verify YouTube videos are published'),
  checkItem('Post series launch teaser on X/Twitter (thread format)'),
  checkItem('Post series launch teaser on Facebook'),
  checkItem('Post series launch teaser on Instagram'),
  checkItem('Post series launch teaser on LinkedIn'),
  checkItem('Share dashboard link on all platforms'),
  checkItem('Send email newsletter (if applicable)'),
  checkItem('Ask 3-5 friends/family to listen, rate, and review on Apple Podcasts'),
  note('Apple Podcasts reviews are critical for discoverability — ask early listeners to leave 5-star reviews'),

  subTitle('Day After Launch'),
  checkItem('Post Episode 1 specific content on all platforms'),
  checkItem('Engage with comments on YouTube'),
  checkItem('Respond to social media mentions'),
  checkItem('Check podcast download analytics'),
  checkItem('Check YouTube view analytics'),

  divider(),

  // === PHASE 6: ONGOING ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  sectionTitle('PHASE 6: ONGOING (WEEKS 2-4)'),

  subTitle('If Weekly Release Schedule'),
  checkItem('Week 2: Publish Episode 2 + post Episode 2 social media content'),
  checkItem('Week 3: Publish Episode 3 + post Episode 3 social media content'),
  checkItem('Week 4: Publish Episode 4 (finale) + post Episode 4 social media content'),
  checkItem('Week 4: Post series wrap-up content on all platforms'),

  subTitle('If Binge Release (All at Once)'),
  checkItem('Post Episode 1 content (Day 1)'),
  checkItem('Post Episode 2 content (Day 3)'),
  checkItem('Post Episode 3 content (Day 5)'),
  checkItem('Post Episode 4 content + series wrap-up (Day 7)'),

  subTitle('Engagement & Growth'),
  checkItem('Engage with all comments on YouTube and social media'),
  checkItem('Share listener quotes/reactions on social media'),
  checkItem('Cross-promote on relevant subreddits (r/politics, r/geopolitics, r/iran)'),
  note('Read each subreddit\'s rules before posting — some have strict self-promotion guidelines'),
  checkItem('Reach out to other political podcasters for cross-promotion opportunities'),
  checkItem('Consider guest appearances on other shows'),
  checkItem('Monitor Apple Podcasts reviews and respond to listener feedback'),

  subTitle('Content Maintenance'),
  checkItem('Update dashboard with any new Iran conflict developments'),
  note('Contact your Perplexity Computer assistant to update the dashboard — the URL stays the same'),
  checkItem('Record a short "update" episode if major developments occur (5-10 min bonus episode)'),
  checkItem('Post any updates to social media'),

  divider(),

  // === QUICK REFERENCE ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  sectionTitle('QUICK REFERENCE'),

  subTitle('Asset File List'),
  new Paragraph({
    spacing: { before: 40, after: 40, line: 360 },
    children: [
      new TextRun({ text: 'Scripts: ', bold: true, size: 22, font: FONT }),
      new TextRun({ text: 'podcast-scripts-conversational.docx', size: 22, font: FONT, color: COLOR_ACCENT }),
      new TextRun({ text: '\nSlides: ', bold: true, size: 22, font: FONT }),
      new TextRun({ text: 'deep-dive-manuscript.pptx', size: 22, font: FONT, color: COLOR_ACCENT }),
      new TextRun({ text: '\nSocial: ', bold: true, size: 22, font: FONT }),
      new TextRun({ text: 'social-media-posts.docx', size: 22, font: FONT, color: COLOR_ACCENT }),
      new TextRun({ text: '\nEp 1 Cover: ', bold: true, size: 22, font: FONT }),
      new TextRun({ text: 'cover-ep1-v3-final.png', size: 22, font: FONT, color: COLOR_ACCENT }),
      new TextRun({ text: '\nEp 2 Cover: ', bold: true, size: 22, font: FONT }),
      new TextRun({ text: 'cover-ep2-v3-final.png', size: 22, font: FONT, color: COLOR_ACCENT }),
      new TextRun({ text: '\nEp 3 Cover: ', bold: true, size: 22, font: FONT }),
      new TextRun({ text: 'cover-ep3-v3-final.png', size: 22, font: FONT, color: COLOR_ACCENT }),
      new TextRun({ text: '\nEp 4 Cover: ', bold: true, size: 22, font: FONT }),
      new TextRun({ text: 'cover-ep4-v3-final.png', size: 22, font: FONT, color: COLOR_ACCENT }),
      new TextRun({ text: '\nBanner: ', bold: true, size: 22, font: FONT }),
      new TextRun({ text: 'youtube-banner-v4-final.png', size: 22, font: FONT, color: COLOR_ACCENT }),
      new TextRun({ text: '\nThumbnails: ', bold: true, size: 22, font: FONT }),
      new TextRun({ text: 'youtube-thumb-ep1/2/3/4-final.png', size: 22, font: FONT, color: COLOR_ACCENT }),
    ],
  }),

  subTitle('Key Links'),
  new Paragraph({
    spacing: { before: 40, after: 40, line: 360 },
    children: [
      new TextRun({ text: 'Dashboard: ', bold: true, size: 22, font: FONT }),
      new ExternalHyperlink({
        children: [new TextRun({ text: 'https://iran-conflict-tracker.pplx.app', style: 'Hyperlink', size: 22 })],
        link: 'https://iran-conflict-tracker.pplx.app',
      }),
    ],
  }),

  subTitle('Episode Quick Reference'),
  new Table({
    rows: [
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: 'Ep', bold: true, size: 20, font: FONT, color: 'FFFFFF' })] })], shading: { fill: COLOR_ACCENT, type: ShadingType.CLEAR } }),
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: 'Title', bold: true, size: 20, font: FONT, color: 'FFFFFF' })] })], shading: { fill: COLOR_ACCENT, type: ShadingType.CLEAR } }),
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: 'Runtime', bold: true, size: 20, font: FONT, color: 'FFFFFF' })] })], shading: { fill: COLOR_ACCENT, type: ShadingType.CLEAR } }),
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: 'Topic', bold: true, size: 20, font: FONT, color: 'FFFFFF' })] })], shading: { fill: COLOR_ACCENT, type: ShadingType.CLEAR } }),
        ],
      }),
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: '1', size: 20, font: FONT })] })] }),
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: 'The War That Isn\'t a War', size: 20, font: FONT })] })] }),
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: '35-40 min', size: 20, font: FONT })] })] }),
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: 'Rhetoric vs. reality', size: 20, font: FONT })] })] }),
        ],
      }),
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: '2', size: 20, font: FONT })] })] }),
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: 'Economic D-Day', size: 20, font: FONT })] })] }),
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: '35-40 min', size: 20, font: FONT })] })] }),
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: 'Sanctions & economic warfare', size: 20, font: FONT })] })] }),
        ],
      }),
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: '3', size: 20, font: FONT })] })] }),
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: 'Carriers and Combat', size: 20, font: FONT })] })] }),
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: '35-40 min', size: 20, font: FONT })] })] }),
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: 'Military operations & naval posture', size: 20, font: FONT })] })] }),
        ],
      }),
      new TableRow({
        children: [
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: '4', size: 20, font: FONT })] })] }),
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: 'The Reconciliation', size: 20, font: FONT })] })] }),
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: '35-40 min', size: 20, font: FONT })] })] }),
          new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: 'Series finale & gap analysis', size: 20, font: FONT })] })] }),
        ],
      }),
    ],
    width: { size: 100, type: WidthType.PERCENTAGE },
  }),

  divider(),

  // === TIPS ===
  new Paragraph({ pageBreakBefore: true, children: [] }),
  sectionTitle('LAUNCH TIPS & BEST PRACTICES'),

  subTitle('Apple Podcasts Reviews Are Gold'),
  new Paragraph({
    spacing: { before: 40, after: 80 },
    children: [new TextRun({ text: 'Apple\'s algorithm heavily weights reviews and ratings in the first 7 days. Ask everyone you know to leave a 5-star review within the first week. This drives discoverability more than anything else.', size: 22, font: FONT })],
  }),

  subTitle('YouTube SEO'),
  new Paragraph({
    spacing: { before: 40, after: 80 },
    children: [new TextRun({ text: 'In your YouTube video descriptions, include:\n- Full episode title in the first line\n- Relevant keywords: Iran conflict, US military, foreign policy, CENTCOM, sanctions, aircraft carrier, Pentagon, White House\n- Timestamps for each segment\n- Dashboard link\n- Social media links\n\nUse tags: Iran conflict, US foreign policy, military operations, CENTCOM, Pentagon, White House, sanctions, podcast, political podcast, The Endicott Edge', size: 22, font: FONT })],
  }),

  subTitle('Cross-Promotion'),
  new Paragraph({
    spacing: { before: 40, after: 80 },
    children: [new TextRun({ text: 'Share clips (30-60 second segments) on X/Twitter, Instagram Reels, and YouTube Shorts. The most quotable moments from each episode:\n\nEp 1: "The White House says terminated. The Pentagon says continue. Both can\'t be right."\nEp 2: "The Treasury Secretary compared a sanctions campaign to D-Day. Four months after the war was \'terminated.\'"\nEp 3: "264 days at sea. 1.5 million pounds of ordnance. In a war that\'s \'taken care of.\'"\nEp 4: "The gap between rhetoric and reality is the story of this conflict."', size: 22, font: FONT })],
  }),

  subTitle('Engage With Your Audience'),
  new Paragraph({
    spacing: { before: 40, after: 80 },
    children: [new TextRun({ text: 'Respond to every comment on YouTube and every mention on social media in the first 48 hours. This signals to algorithms that your content is generating engagement, which boosts visibility.', size: 22, font: FONT })],
  }),

  subTitle('Track Your Metrics'),
  new Paragraph({
    spacing: { before: 40, after: 80 },
    children: [new TextRun({ text: 'Key metrics to monitor:\n- Apple Podcasts: downloads, completion rate, reviews\n- Spotify: listeners, follow rate, completion rate\n- YouTube: views, watch time, click-through rate (CTR), subscribers gained\n- Social media: impressions, engagement rate, link clicks to dashboard\n\nAim for 40%+ completion rate on podcasts and 20%+ CTR on YouTube thumbnails.', size: 22, font: FONT })],
  }),

  divider(),

  new Paragraph({
    spacing: { before: 400, after: 200 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'You\'ve got this. Truth Verified.', size: 28, font: FONT, color: COLOR_ACCENT, bold: true })],
  }),
  new Paragraph({
    spacing: { before: 0, after: 400 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'The Endicott Edge', size: 22, font: FONT, color: COLOR_STAGE, italics: true })],
  }),
];

const doc = new Document({
  styles: {
    default: { document: { run: { font: FONT, size: 22 } } },
    paragraphStyles: [
      {
        id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 32, bold: true, font: FONT, color: COLOR_ACCENT },
        paragraph: { spacing: { before: 360, after: 160 }, outlineLevel: 0 },
      },
      {
        id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 26, bold: true, font: FONT, color: COLOR_RED },
        paragraph: { spacing: { before: 280, after: 120 }, outlineLevel: 1 },
      },
    ],
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1080, right: 1080, bottom: 1080, left: 1080 },
      },
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({ text: 'The Endicott Edge \u2014 Launch Checklist', italics: true, color: '999999', size: 16, font: FONT })],
        })],
      }),
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({ text: 'Page ', size: 16, font: FONT, color: '999999' }),
            new TextRun({ children: [PageNumber.CURRENT], size: 16, font: FONT, color: '999999' }),
            new TextRun({ text: ' of ', size: 16, font: FONT, color: '999999' }),
            new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 16, font: FONT, color: '999999' }),
          ],
        })],
      }),
    },
    children: content,
  }],
});

(async () => {
  const buf = await Packer.toBuffer(doc);
  fs.writeFileSync('/home/user/workspace/iran-dashboard/podcast-launch-checklist.docx', buf);
  console.log('Launch checklist generated');
})();
