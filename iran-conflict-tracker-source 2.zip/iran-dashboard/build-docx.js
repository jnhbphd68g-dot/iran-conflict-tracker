const fs = require('fs');
const docx = require('docx');
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, PageOrientation, LevelFormat,
  ExternalHyperlink, HeadingLevel, BorderStyle, WidthType, ShadingType,
  PageBreak, PageNumber,
} = docx;

// === STYLING ===
const FONT = 'Calibri';
const FONT_HEADING = 'Calibri';
const COLOR_ACCENT = '01696F';
const COLOR_STAGE = '8B98A8';
const COLOR_SOURCE = '5A6878';
const COLOR_WHITE = 'FFFFFF';
const COLOR_DARK_BG = '111721';

const thinBorder = { style: BorderStyle.SINGLE, size: 1, color: 'B0B0B0' };
const allBorders = { top: thinBorder, bottom: thinBorder, left: thinBorder, right: thinBorder };

// Helper functions
function stageDirection(text) {
  return new Paragraph({
    spacing: { before: 120, after: 60 },
    children: [new TextRun({ text: `[${text}]`, italics: true, color: COLOR_STAGE, size: 20, font: FONT })],
  });
}

function spokenText(text) {
  return new Paragraph({
    spacing: { before: 60, after: 60, line: 360 },
    children: [new TextRun({ text, size: 24, font: FONT })],
  });
}

function segmentHeading(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 360, after: 120 },
    children: [new TextRun({ text, bold: true, size: 28, font: FONT_HEADING, color: COLOR_ACCENT })],
  });
}

function sourceNote(text) {
  return new Paragraph({
    spacing: { before: 40, after: 40 },
    children: [new TextRun({ text, italics: true, color: COLOR_SOURCE, size: 18, font: FONT })],
  });
}

function episodeTitle(text, subtitle, runtime) {
  return [
    new Paragraph({ pageBreakBefore: true, spacing: { before: 0, after: 0 }, children: [] }),
    new Paragraph({
      spacing: { before: 400, after: 100 },
      children: [new TextRun({ text, bold: true, size: 44, font: FONT_HEADING, color: COLOR_ACCENT })],
    }),
    new Paragraph({
      spacing: { before: 0, after: 100 },
      children: [new TextRun({ text: subtitle, size: 28, font: FONT, color: '555555' })],
    }),
    new Paragraph({
      spacing: { before: 0, after: 300 },
      children: [new TextRun({ text: `Estimated runtime: ${runtime}`, italics: true, size: 22, font: FONT, color: COLOR_STAGE })],
    }),
  ];
}

function divider() {
  return new Paragraph({
    spacing: { before: 200, after: 200 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: '— — — — —', color: COLOR_STAGE, size: 20 })],
  });
}

// === EPISODE 1 SCRIPT ===
const ep1 = [
  ...episodeTitle('EPISODE 1: THE WAR THAT ISN\'T A WAR', 'Part 1 of the Mixed Messages Series', '35-40 minutes'),

  stageDirection('COLD OPEN — No music. Hard cut to a quote.'),

  spokenText('"The hostilities that began on February 28, 2026, have terminated."'),
  sourceNote('— President Donald J. Trump, May 1, 2026. Source: Reuters, https://www.reuters.com/world/asia-pacific/white-house-says-iran-war-terminated-war-powers-deadline-arrives-2026-05-01/'),

  stageDirection('PAUSE — 2 seconds. Then a second quote.'),

  spokenText('"Each day we continue to attack deeper into Iranian territory. And the pressure will continue. In conclusion, we will continue major combat operations."'),
  sourceNote('— General Dan Caine, Chairman of the Joint Chiefs of Staff, March 19, 2026. Source: Defense.gov transcript, https://www.defense.gov/News/Transcripts/Transcript/Article/4438625/'),

  stageDirection('PAUSE — 3 seconds. Then the intro music begins.'),

  stageDirection('MUSIC: Theme — driving, mid-tempo, news-documentary feel. 15 seconds. Fade under.'),

  stageDirection('IMAGE: Title card — "MIXED MESSAGES: The Iran Conflict" with episode number.'),

  spokenText('Welcome to Mixed Messages, the podcast where we pull apart the gap between what government officials say and what they actually do. I\'m your host, and today we\'re launching a four-part series on the 2026 Iran conflict — a conflict that, depending on who you ask, is either "taken care of" or "only just begun."'),

  spokenText('Over the next four episodes, we\'ll track the rhetorical shifts from the White House, the Attorney General, and the Pentagon, mapped against what\'s actually happening on the ground — the carrier strike groups in the Arabian Sea, the CENTCOM strikes, the economic sanctions, and the force levels that have stayed remarkably constant even as the language coming out of Washington has swung wildly from escalation to de-escalation and back again.'),

  spokenText('Today, in Part 1, we\'re looking at the core contradiction: how can the White House say the war is "terminated" while the Pentagon says it will "continue major combat operations"? How can the Vice President say "we\'re not at war at all" while two aircraft carriers patrol the Arabian Sea and 50,000 troops remain deployed?'),

  spokenText('Let\'s start at the beginning.'),

  divider(),

  segmentHeading('SEGMENT 1: THE OPENING STRIKE — OPERATION EPIC FURY'),

  stageDirection('IMAGE: Dashboard screenshot — Timeline tab, filtered to February 2026 entries.'),

  spokenText('On February 6, 2026, President Trump signed Executive Order 14382. The order imposed additional tariffs — up to 25 percent — on any country that purchased goods or services from Iran. The language was stark. Trump declared that "the actions and policies of the Government of Iran continue to pose an unusual and extraordinary threat to the national security, foreign policy, and economy of the United States."'),

  sourceNote('Source: White House (official), https://www.whitehouse.gov/presidential-actions/2026/02/addressing-threats-to-the-united-states-by-the-government-of-iran/'),

  spokenText('That was the economic opening shot. Three weeks later, the military one followed.'),

  spokenText('On February 28, 2026, at 1:15 AM Eastern Time, U.S. Central Command launched Operation Epic Fury. More than 100 aircraft launched from land and sea. Over 1,000 targets were struck in the first 24 hours. The operation was a joint U.S.-Israeli campaign against Iran\'s military infrastructure — ballistic missile arsenals, naval assets, drone facilities.'),

  sourceNote('Source: Defense.gov (official), https://www.defense.gov/News/News-Stories/Article/Article/4418826/hegseth-says-epic-fury-goals-in-iran-are-laser-focused/'),

  spokenText('Secretary of War Pete Hegseth held a Pentagon press briefing that same day. His language was precise and aggressive.'),

  spokenText('"The mission of Operation Epic Fury is laser-focused. Destroy Iranian offensive missiles, destroy Iranian missile production, destroy their navy and other security infrastructure, and they will never have nuclear weapons."'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('Notice that word: "never." Not "slow them down." Not "degrade." Never. That\'s a permanent objective — the kind that doesn\'t end in 38 days or six weeks. But at this point, the administration wasn\'t claiming the war would be short. They were just getting started.'),

  divider(),

  segmentHeading('SEGMENT 2: "ONLY JUST BEGUN" — THE RHETORICAL ESCALATION'),

  stageDirection('IMAGE: Dashboard screenshot — Conflict Matrix tab, "Duration" row highlighted.'),

  spokenText('March 2nd. Hegseth appears before the press again. This time, his tone shifts from precision to something more expansive. He says the campaign has "only just begun."'),

  spokenText('"We\'ve only just begun to hunt, dismantle, demoralize, destroy and defeat their capabilities."'),

  sourceNote('Source: Defense.gov (official), https://www.defense.gov/News/News-Stories/Article/Article/4418826/hegseth-says-epic-fury-goals-in-iran-are-laser-focused/'),

  spokenText('Two days later, March 4th, a U.S. submarine torpedoes an Iranian warship off the coast of Sri Lanka — the first submarine torpedo attack since World War II. The escalation is real, and it\'s accelerating.'),

  sourceNote('Source: Politico, https://www.politico.com/news/2026/03/04/hegset-iran-war-just-begun-00811889'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('Then March 6th. An internal Pentagon memo is leaked. It projects the Iran war will continue through September 2026. Not weeks. Not "four to six weeks" as the White House would later claim. Through September.'),

  sourceNote('Source: People\'s World, https://www.peoplesworld.org/article/internal-memo-pentagon-expects-iran-war-through-september/'),

  spokenText('And then March 19th — the moment that, for me, crystallizes the entire contradiction of this conflict. Hegseth and General Dan Caine, the Chairman of the Joint Chiefs, hold a press briefing at the Pentagon. And what they say, on the record, in an official Defense Department transcript, directly contradicts everything the White House would say in the coming months.'),

  spokenText('Hegseth says: "Our objectives, given directly from our America first president, remain exactly what they were on day one. These are not the media\'s objectives, not Iran\'s objectives, not new objectives — our objectives, unchanged, on target and on plan: destroy missiles, launchers and Iran\'s defense industrial base so they cannot rebuild, destroy their navy, and Iran never gets a nuclear weapon."'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('And then a reporter asks about the timeline. How long will this take? And Hegseth says: "We wouldn\'t want to set a definitive timeframe on that. But we are very much on plan."'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('"No definitive timeframe." Remember that phrase. We\'ll come back to it.'),

  spokenText('And then General Caine takes the microphone. And he doesn\'t hedge. He says: "U.S. Central Command remains on plan to achieve our military objectives. Each day we continue to attack deeper into Iranian territory. And the pressure will continue."'),

  stageDirection('PAUSE — 3 seconds'),

  spokenText('"Each day we continue to attack deeper into Iranian territory." And: "The pressure will continue." And then — the line that should be carved into stone: "In conclusion, we will continue major combat operations."'),

  sourceNote('Source: Defense.gov transcript (official), https://www.defense.gov/News/Transcripts/Transcript/Article/4438625/'),

  stageDirection('PAUSE — 3 seconds. Let that sit.'),

  spokenText('So. March 19th. The Pentagon says the war continues. The objectives are unchanged. There\'s no endpoint. They will continue major combat operations. That\'s the Pentagon\'s position, stated on the record, in an official transcript.'),

  spokenText('Now watch what happens next.'),

  divider(),

  segmentHeading('SEGMENT 3: "TERMINATED" — THE MAY PIVOT'),

  stageDirection('IMAGE: Dashboard screenshot — Timeline tab, April-May entries. Show the pivot from "crushes" to "terminated."'),

  spokenText('April 1st. Trump addresses the nation. The White House publishes a release titled "Clear and Unchanging Objectives Drive Decisive Success Against Iranian Regime." The word "peace" starts entering the vocabulary.'),

  sourceNote('Source: White House (official), https://www.whitehouse.gov/releases/2026/04/president-trumps-clear-and-unchanging-objectives-drive-decisive-success-against-iranian-regime/'),

  spokenText('April 8th. The White House publishes "Peace Through Strength: Operation Epic Fury Crushes Iranian Threat as Ceasefire Takes Hold." Peace. Ceasefire. These are new words.'),

  sourceNote('Source: White House (official), https://www.whitehouse.gov/releases/2026/04/peace-through-strength-operation-epic-fury-crushes-iranian-threat-as-ceasefire-takes-hold/'),

  spokenText('And then May 1st. The war powers deadline arrives — the legal deadline under the War Powers Act that requires the president to seek congressional authorization or withdraw forces within 60 days. And Trump makes a declaration.'),

  spokenText('"The hostilities that began on February 28, 2026, have terminated."'),

  stageDirection('PAUSE — 3 seconds'),

  sourceNote('Source: Reuters, https://www.reuters.com/world/asia-pacific/white-house-says-iran-war-terminated-war-powers-deadline-arrives-2026-05-01/'),

  spokenText('"Terminated." Not "paused." Not "scaling down." Terminated. The war is over, according to the White House.'),

  spokenText('Four days later, May 5th, Secretary of State Marco Rubio — speaking for the State Department, not the White House — makes it even more explicit.'),

  spokenText('"Operation Epic Fury is over. We achieved the objectives of that operation. We\'re now on to this Project Freedom."'),

  sourceNote('Source: State Department, https://www.state.gov'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('"We achieved the objectives." Remember what Hegseth said the objectives were? Destroy Iran\'s missiles. Destroy their navy. Ensure they never get nuclear weapons. Did all of that happen in 66 days? The Pentagon\'s own internal memo said the war would last through September. And it\'s now May. The memo was wrong — or the White House is.'),

  spokenText('And then June 19th. The White House announces something extraordinary. A Memorandum of Understanding with Iran.'),

  spokenText('"President Donald J. Trump and Vice President JD Vance have secured a historic breakthrough by signing a Memorandum of Understanding with Iran. This agreement ensures Iran will never obtain a nuclear weapon, reopens the Strait of Hormuz to free navigation, and puts America First."'),

  sourceNote('Source: White House (official), https://www.whitehouse.gov/releases/2026/06/president-trumps-iran-agreement-is-america-first-in-action/'),

  spokenText('A peace deal. An MOU. The war is over, and now there\'s a diplomatic resolution. That\'s the narrative.'),

  spokenText('But here\'s what\'s happening on the ground during this same period. On June 10th, the Treasury sanctions nine entities supporting Iran\'s weapons procurement networks. On April 25th, three U.S. aircraft carriers were operating in the Middle East simultaneously — the first time since 2003. No carrier entered the Persian Gulf, but three were in the region. And the sanctions kept coming.'),

  sourceNote('Source: Treasury (official), https://home.treasury.gov/news/press-releases/sb0528'),

  spokenText('So the White House is signing peace agreements while the Treasury is escalating sanctions. The left hand is declaring peace while the right hand is waging economic war. Keep that in mind for Episode 2.'),

  divider(),

  segmentHeading('SEGMENT 4: "NOT AT WAR AT ALL" — THE SEPTEMBER DENIAL'),

  stageDirection('IMAGE: Dashboard screenshot — Timeline tab, September entries. Show "small potatoes," "not at war," "taken care of."'),

  spokenText('Now we jump to September. The war, according to the White House, has been "terminated" since May. But CENTCOM has been conducting strikes throughout July — four rounds of strikes between July 7th and July 20th. On July 23rd, they completed what they called the "13th night of precision strikes on Iranian military targets."'),

  sourceNote('Source: CENTCOM (official), https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/Article/4554310/us-concludes-13th-night-of-strikes-on-iranian-military-targets/'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('Thirteen nights of strikes. After the war was "terminated."'),

  spokenText('September 1st. CENTCOM completes strikes on IRGC targets — air defense systems, radar, maritime assets, mine-laying capabilities. September 5th. Iran targets two U.S. Navy warships. CENTCOM destroys three IRGC oil tankers in response. September 8th. Iran targets another American warship. The U.S. destroys five more IRGC tankers. Two exchanges of fire in one week. In a war that was "terminated" in May.'),

  sourceNote('Sources: CENTCOM (official), https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/'),

  stageDirection('PAUSE — 3 seconds'),

  spokenText('And what does the White House say about all of this?'),

  spokenText('September 10th. The Atlantic publishes a piece titled "Trump is Preparing for a Long War." In that same timeframe, Trump calls the conflict "small potatoes." And Vice President JD Vance says: "The U.S. is not at war at all."'),

  sourceNote('Source: The Atlantic, https://www.theatlantic.com/national-security/2026/09/trump-iran-war-navy/688563/'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('"Not at war at all." Two carriers in the Arabian Sea. 50,000 troops deployed. CENTCOM conducting active strikes. An 18th U.S. service member has died. And the Vice President says the United States is "not at war at all."'),

  spokenText('September 15th. Attorney General Todd Blanche appears on CNN. When asked about the war, he says: "I disagree with that characterization, as does most of Congress."'),

  sourceNote('Source: CNN transcript, https://transcripts.cnn.com/show/cnc/date/2026-09-15/segment/10'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('"I disagree with that characterization." The Attorney General of the United States disagrees that there\'s a war. The Pentagon is conducting strikes. The Treasury is waging economic war. And the Attorney General disagrees with the characterization.'),

  spokenText('And then September 17th. House Speaker Mike Johnson — not a White House official, but a congressional ally — declares that the Iran nuclear issue is "taken care of." And Trump himself says: "Hopefully we\'re toward the end of the war. They want to make a deal."'),

  sourceNote('Source: CBS News, https://www.cbsnews.com/live-updates/iran-war-us-trump-oil-strait-of-hormuz/'),

  stageDirection('PAUSE — 3 seconds'),

  spokenText('"Toward the end." Not "over." Not "terminated." Toward the end. Even the language has softened from the May declaration of "terminated" to September\'s "toward the end." It\'s a rhetorical retreat — from declaring the war over to hoping it might be ending soon. And even that hope is contradicted by the carrier deployments, the CENTCOM strikes, and the sanctions legislation.'),

  divider(),

  segmentHeading('SEGMENT 5: THE ANALYSIS — WHAT THEY SAY VS WHAT THEY DO'),

  stageDirection('IMAGE: Dashboard screenshot — Analysis tab. Three-column layout visible.'),

  spokenText('So let\'s lay this out. This is what we\'ve tracked.'),

  spokenText('On the declaratory side — what they say — we have: "terminated" on May 1st. "We achieved the objectives" on May 5th. "Not at war at all" on September 10th. "Taken care of" on September 17th. "Toward the end" on September 17th. And the Attorney General saying "I disagree with that characterization."'),

  spokenText('On the operational side — what they do — we have: two aircraft carriers in the Arabian Sea as of September 14th. 50,000 troops deployed. CENTCOM conducting strikes as recently as September 8th. Operation Economic Outcast — which Treasury Secretary Bessent called "an economic D-Day" — launched on August 24th, after the war was "terminated." The Treasury disrupting an IRGC extortion scheme in the Strait of Hormuz on July 29th. And on September 18th — one day after Trump said we\'re "toward the end of the war" — the President signed H.R. 5334, the Lindsey O. Graham Sanctioning Russia and Iran Act of 2026, into law, extending and expanding statutory sanctions on Iran.'),

  sourceNote('Source: White House (official), https://www.whitehouse.gov/briefings-statements/2026/09/congressional-bill-h-r-5334-signed-into-law/'),

  stageDirection('PAUSE — 3 seconds'),

  spokenText('You don\'t sign sanctions legislation into law for a conflict that\'s "taken care of." You don\'t deploy a carrier strike group to relieve another one for a war that\'s "terminated." You don\'t conduct strikes — thirteen nights of them — in a country you\'re "not at war with."'),

  spokenText('The declaratory policy — what the White House and Attorney General say — is irreconcilable with the observed force posture — what the Pentagon and Treasury are actually doing. The rhetoric shifted from "only just begun" to "terminated" while force levels remained constant or increased. Economic pressure escalated simultaneously with military de-escalation rhetoric. And the Pentagon\'s own projections — the internal memo, the CNO statements, the Hegseth-Caine transcript — all contradict the White House claims of resolution.'),

  spokenText('This isn\'t a difference of opinion. This is institutional awareness of a sustained conflict that the political leadership declines to acknowledge. The military knows the war continues. The Treasury knows the war continues. CENTCOM knows the war continues — they\'re the ones pulling the trigger. But the White House has decided, for political reasons, to declare it over.'),

  divider(),

  segmentHeading('CLOSING'),

  stageDirection('MUSIC: Theme returns, softer. 10 seconds. Fade under.'),

  spokenText('In our next episode — Part 2, "Economic D-Day" — we\'ll dive deep into the economic pressure campaign. From Executive Order 14382\'s tariffs on countries trading with Iran, to Operation Economic Outcast\'s targeting of five vital economic lifelines, to the shadow fleet sanctions and the IRGC\'s Strait of Hormuz extortion scheme. We\'ll trace how economic warfare escalated even as the White House declared military victory.'),

  spokenText('If you want to see the full dashboard with all 52 timeline events, the conflict matrix, the carrier tracker, and the source citations for every claim in this episode, the link is in the show notes. Every quote, every date, every source — verified and linked.'),

  stageDirection('IMAGE: Dashboard URL — https://iran-conflict-tracker.pplx.app'),

  spokenText('I\'m your host. This has been Mixed Messages, Part 1: The War That Isn\'t a War. Thanks for listening.'),

  stageDirection('MUSIC: Theme swells. 15 seconds. Fade out.'),

  stageDirection('END OF EPISODE 1'),
];

// === EPISODE 2 SCRIPT ===
const ep2 = [
  ...episodeTitle('EPISODE 2: ECONOMIC D-DAY', 'Part 2 of the Mixed Messages Series', '35-40 minutes'),

  stageDirection('COLD OPEN — No music. Hard cut to a quote.'),

  spokenText('"Today, at President Trump\'s direction, the United States Treasury has begun Operation Economic Outcast — an unprecedented campaign against the Islamic Republic of Iran and its enablers. We are launching an economic onslaught against Iran\'s financial connections around the globe. Our objective is to sever every economic lifeline that sustains this tyrannical regime until Tehran stands alone."'),

  sourceNote('— Treasury Secretary Scott Bessent, August 24, 2026. Source: Treasury (official), https://home.treasury.gov/news/press-releases/sb0613'),

  stageDirection('PAUSE — 3 seconds'),

  spokenText('"Economic onslaught." "Sever every economic lifeline." "Until Tehran stands alone." That\'s not the language of de-escalation. That\'s not the language of a war that\'s been "terminated." That\'s the language of total economic warfare — launched by the Treasury Department, on the record, in an official press release, on August 24th, 2026.'),

  spokenText('August 24th. Three months after the White House declared the war "terminated."'),

  stageDirection('MUSIC: Theme. 15 seconds. Fade under.'),

  stageDirection('IMAGE: Title card — "MIXED MESSAGES: Economic D-Day"'),

  spokenText('Welcome back to Mixed Messages. In Part 1, we tracked the core contradiction — the White House saying the war is over while the Pentagon continues combat operations. Today, in Part 2, we\'re looking at the other half of the equation: the economic war.'),

  spokenText('Because while the military rhetoric was de-escalating — from "only just begun" to "terminated" to "not at war at all" — the economic pressure was doing the opposite. It was accelerating. Escalating. Intensifying. The Treasury Department was waging its own war, in parallel, and it was doing so with language that directly contradicted the White House\'s peace narrative.'),

  divider(),

  segmentHeading('SEGMENT 1: THE OPENING SALVO — EXECUTIVE ORDER 14382'),

  stageDirection('IMAGE: Dashboard screenshot — Economic vs Military tab, February entries.'),

  spokenText('Before the first bomb fell, before Operation Epic Fury even launched, the economic war was already underway.'),

  spokenText('February 6th, 2026. Twenty-two days before the first military strike. President Trump signs Executive Order 14382. The order declares a national emergency with respect to Iran and imposes additional tariffs — up to 25 percent — on any country that "directly or indirectly purchases, imports, or otherwise acquires any goods or services from Iran."'),

  sourceNote('Source: White House (official), https://www.whitehouse.gov/presidential-actions/2026/02/addressing-threats-to-the-united-states-by-the-government-of-iran/'),

  spokenText('Think about what that means. The United States was telling every country on Earth: if you buy anything from Iran, we\'ll slap a 25 percent tariff on your exports to us. That\'s not targeted sanctions. That\'s a global embargo enforced through the U.S. tariff system. It\'s economic warfare at a scale we haven\'t seen in modern times.'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('On the same day, the State Department sanctioned 14 vessels from Iran\'s "shadow fleet" — the covert logistics network of tankers that allows Iran to keep oil revenues flowing despite international sanctions.'),

  sourceNote('Source: State Department (official), https://www.state.gov/releases/office-of-the-spokesperson/2026/02/sanctions-to-combat-illicit-traders-of-iranian-oil-and-the-shadow-fleet'),

  spokenText('So February 6th was a one-two punch. The Treasury cut off Iran\'s trading partners with tariffs, and the State Department targeted the oil smuggling network that keeps the regime afloat. This was the economic foundation — laid before a single missile was fired.'),

  divider(),

  segmentHeading('SEGMENT 2: THE SHADOW FLEET AND OFAC\'S CAMPAIGN'),

  stageDirection('IMAGE: Dashboard screenshot — Economic tracker, showing sanctions progression.'),

  spokenText('After the war began on February 28th, the economic pressure didn\'t pause — it accelerated. On April 28th, OFAC — the Treasury\'s Office of Foreign Assets Control — sanctioned 35 individuals and entities for aiding Iran\'s sanctions evasion. The total count of sanctioned entities crossed 1,000 since the campaign began in February 2025.'),

  sourceNote('Source: Reuters / Treasury, https://www.reuters.com/business/finance/us-imposes-sanctions-35-individuals-entities-aiding-irans-sanctions-evasions-2026-04-28/'),

  spokenText('Then June 10th. Treasury launches "Economic Fury" — a sanctions package targeting nine individuals and entities supporting Iran\'s weapons procurement networks. These are the people and companies that help Iran buy the components for its missiles and drones — the same weapons the Pentagon is simultaneously destroying with airstrikes.'),

  sourceNote('Source: Treasury (official), https://home.treasury.gov/news/press-releases/sb0528'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('So the Pentagon destroys the missiles. The Treasury cuts off the supply chain that builds them. It\'s a coordinated campaign — military and economic, working in tandem. But only one half of that campaign is being acknowledged by the White House.'),

  spokenText('June 22nd brings a curious move. OFAC issues "Iran General License X" — authorizing Iranian oil sales through August 21st. A temporary license allowing some oil trade. This is the kind of nuanced, transactional approach that suggests the administration was trying to manage the conflict, not end it. You don\'t issue temporary licenses for a war you\'ve declared "terminated." You issue temporary licenses for a conflict you\'re actively managing.'),

  sourceNote('Source: OFAC, https://ofac.treasury.gov/recent-actions/20260622_33'),

  divider(),

  segmentHeading('SEGMENT 3: OPERATION ECONOMIC OUTCAST — "ECONOMIC D-DAY"'),

  stageDirection('IMAGE: Dashboard screenshot — Economic tracker, August 24th entry highlighted.'),

  spokenText('And then comes August 24th. The big one.'),

  spokenText('Treasury Secretary Scott Bessent announces Operation Economic Outcast. And the language he uses is extraordinary.'),

  spokenText('"In the Second World War, D-Day marked the historic beginning of a campaign with our allies to target and drive the enemy from its positions, including those in third countries. Today, in that same spirit, we are launching an economic onslaught against Iran\'s financial connections around the globe."'),

  stageDirection('PAUSE — 3 seconds'),

  sourceNote('Source: Treasury (official), https://home.treasury.gov/news/press-releases/sb0613'),

  spokenText('He compared it to D-Day. The Treasury Secretary of the United States compared an economic sanctions campaign to the Allied invasion of Normandy. That\'s not measured diplomatic language. That\'s war rhetoric — from the Treasury Department.'),

  spokenText('And the scope of Operation Economic Outcast is massive. It targets five of what Treasury calls "Iran\'s most vital lifelines": digital assets, technology, gold, aviation, and shipping. It expands secondary sanctions risk for anyone doing business with Iran. It gives every country a defined timeline to shut down Iran-related activity. And Treasury says: "If they fail to act, Treasury will act."'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('"If they fail to act, Treasury will act." That\'s a threat to the entire international financial system. Do business with Iran, and you risk being cut off from the U.S. financial system. It\'s the financial equivalent of a naval blockade — and it was launched three months after the White House said the war was "terminated."'),

  spokenText('Bessent went further. He said: "America is no longer managing the Iranian threat — we are ending it." And: "Those who tether themselves to Tehran should expect to share in the isolation of a withering regime."'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('"We are ending it." Not "we have ended it." Not "the war is over." "We are ending it." Present tense. Ongoing. The Treasury Secretary is describing an active campaign — in August, in a war that was declared over in May.'),

  divider(),

  segmentHeading('SEGMENT 4: THE STRAIT OF HORMUZ EXTORTION SCHEME'),

  stageDirection('IMAGE: Dashboard screenshot — Carrier Posture tab, regional map.'),

  spokenText('On July 29th — between the "terminated" declaration and the "Economic D-Day" launch — OFAC disrupted something remarkable. An IRGC-backed extortion scheme in the Strait of Hormuz.'),

  spokenText('Here\'s how it worked. Iran had established two entities — the Persian Gulf Marine Insurance Company and something called HormuzSafe. These weren\'t real insurance companies. They were extortion fronts. They forced commercial vessels transiting the Strait of Hormuz to purchase "mandatory maritime insurance" — protection from risks like seizure. But here\'s the catch: the risks were created by Iran itself. Iran was threatening to seize ships, and then selling "insurance" against that threat. It was a protection racket — state-run, in one of the world\'s most critical shipping lanes.'),

  sourceNote('Source: Treasury (official), https://home.treasury.gov/news/press-releases/sb0581'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('Bessent\'s response was blunt: "With its economy in freefall and inflation in the triple digits, the regime is desperate for cash. The United States will not allow Iran to hold global commerce hostage or use international shipping to finance the IRGC\'s terrorism, aggression, and repression."'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('The Treasury also revealed that since the beginning of 2026, OFAC had sanctioned over 100 vessels linked to Iran\'s shadow fleet. One hundred ships. That\'s not a targeted operation. That\'s a systemic campaign to dismantle Iran\'s oil smuggling network — the same network that funds the IRGC, the same IRGC that CENTCOM is striking.'),

  divider(),

  segmentHeading('SEGMENT 5: H.R. 5334 — SANCTIONS INTO LAW'),

  stageDirection('IMAGE: Dashboard screenshot — Timeline tab, September 18th entry.'),

  spokenText('And then September 18th. One day after Trump said "hopefully we\'re toward the end of the war." One day after Speaker Johnson said the nuclear issue is "taken care of." The President signs H.R. 5334 into law — the Lindsey O. Graham Sanctioning Russia and Iran Act of 2026.'),

  sourceNote('Source: White House (official), https://www.whitehouse.gov/briefings-statements/2026/09/congressional-bill-h-r-5334-signed-into-law/'),

  stageDirection('PAUSE — 3 seconds'),

  spokenText('This isn\'t an executive order that can be reversed with a pen. This is legislation. Passed by Congress. Signed into law. It extends existing sanctions on Iran and authorizes expanded statutory sanctions, tariffs, and prohibitions. It makes the economic pressure campaign permanent — or at least as permanent as legislation can be.'),

  spokenText('You don\'t sign sanctions into law for a conflict that\'s "taken care of." You don\'t extend statutory sanctions for a war that\'s "terminated." This is a legislative commitment to sustained economic pressure — a signal to the market, to Iran, and to the international community that the economic war continues regardless of what the White House says about the military one.'),

  divider(),

  segmentHeading('SEGMENT 6: THE ANALYSIS — ECONOMIC WAR WHILE SAYING "WAR IS OVER"'),

  stageDirection('IMAGE: Dashboard screenshot — Analysis tab, reconciliation section.'),

  spokenText('Let\'s step back and look at the full picture.'),

  spokenText('The economic pressure campaign against Iran consists of 11 documented actions from February to September 2026. It started before the military campaign — EO 14382 on February 6th, twenty-two days before Operation Epic Fury. It escalated throughout the conflict — from targeted sanctions on shadow fleet vessels to a global "economic D-Day" targeting five vital sectors. And it culminated in legislation — signed into law one day after the President said the war was ending.'),

  spokenText('Meanwhile, the White House was saying: "terminated" (May 1st). "We achieved the objectives" (May 5th). "Not at war at all" (September 10th). "Taken care of" (September 17th).'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('The economic pressure escalated simultaneously with the military de-escalation rhetoric. Operation Economic Outcast was launched on August 24th — nearly four months after the war was "terminated." The Strait of Hormuz extortion disruption happened on July 29th — three months after "termination." H.R. 5334 was signed September 18th — the day after "taken care of."'),

  spokenText('This is not a coincidence. This is a strategy. The White House handles the political narrative — declaring victory, de-escalating rhetorically, pivoting to domestic issues like gas prices. Meanwhile, the Treasury handles the actual pressure — escalating sanctions, disrupting networks, cutting off financial lifelines, and ultimately codifying the pressure into law.'),

  spokenText('It\'s a good cop, bad cop routine. The White House is the good cop — "we\'re not at war, we achieved our objectives, it\'s taken care of." The Treasury is the bad cop — "we\'re launching an economic onslaught, we\'re severing every lifeline, Tehran will stand alone." And the Pentagon is somewhere in between — conducting strikes while refusing to set a definitive timeframe.'),

  stageDirection('PAUSE — 3 seconds'),

  spokenText('The question is: does this work? Can you sustain an economic war while publicly declaring military victory? Can you sign sanctions legislation while saying the conflict is "taken care of"? The answer, based on the evidence, is that the operational reality persists regardless of the declaratory policy. The sanctions keep coming. The strikes keep happening. The carriers keep patrolling. And the gap between what they say and what they do keeps widening.'),

  divider(),

  segmentHeading('CLOSING'),

  stageDirection('MUSIC: Theme returns. 10 seconds. Fade under.'),

  spokenText('In our next episode — Part 3, "Carriers and Combat" — we\'ll look at the military operations in detail. From Operation Epic Fury\'s 100-aircraft opening salvo, to the USS Abraham Lincoln\'s extraordinary 264-day deployment, to the carrier posture that has two strike groups in the Arabian Sea with no carrier inside the Persian Gulf. We\'ll trace the CENTCOM strike timeline and the naval blockade of Iranian ports.'),

  spokenText('The full dashboard with all sources is linked in the show notes. Every quote, every date, every sanction — verified and linked to official government sources.'),

  stageDirection('IMAGE: Dashboard URL — https://iran-conflict-tracker.pplx.app'),

  spokenText('I\'m your host. This has been Mixed Messages, Part 2: Economic D-Day. Thanks for listening.'),

  stageDirection('MUSIC: Theme swells. 15 seconds. Fade out.'),

  stageDirection('END OF EPISODE 2'),
];

// === EPISODE 3 SCRIPT ===
const ep3 = [
  ...episodeTitle('EPISODE 3: CARRIERS AND COMBAT', 'Part 3 of the Mixed Messages Series', '35-40 minutes'),

  stageDirection('COLD OPEN — No music. Hard cut.'),

  spokenText('"264 consecutive days at sea. One and a half million pounds of ordnance dropped. The longest carrier deployment since the Vietnam War."'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('That\'s the USS Abraham Lincoln. It finally left the Middle East in September 2026 — heading home to San Diego after nearly nine months of continuous combat operations. But it wasn\'t replaced by nothing. It was replaced by the USS George Washington, which was already on station. And the USS George H. W. Bush was there too. And the USS Theodore Roosevelt was preparing to deploy.'),

  sourceNote('Source: USNI News Fleet Tracker, https://news.usni.org/2026/09/14/usni-news-fleet-and-marine-tracker-sept-14-2026'),

  stageDirection('MUSIC: Theme. 15 seconds. Fade under.'),

  stageDirection('IMAGE: Title card — "MIXED MESSAGES: Carriers and Combat"'),

  spokenText('Welcome back to Mixed Messages. In Parts 1 and 2, we traced the rhetorical contradictions — the White House saying "terminated" while the Pentagon continues strikes, the Treasury waging economic war while the President declares peace. Today, we\'re looking at the hardware. The steel. The carriers, the strike groups, the CENTCOM operations that have been running continuously since February 28th.'),

  spokenText('This is the part of the conflict that doesn\'t fit into a tweet or a press release. You can say "taken care of" as many times as you want, but the carriers are still there. And they\'re not leaving.'),

  divider(),

  segmentHeading('SEGMENT 1: OPERATION EPIC FURY — THE OPENING STRIKE'),

  stageDirection('IMAGE: Dashboard screenshot — Military tracker, February 28th entry.'),

  spokenText('February 28th, 2026. 1:15 AM Eastern. Operation Epic Fury begins.'),

  spokenText('Over 100 aircraft launched from land bases and carriers simultaneously. More than 1,000 targets struck in the first 24 hours. General Dan Caine, the Chairman of the Joint Chiefs, described it as "the culmination of months, and in some cases, years, of deliberate planning and refinement against this particular target set."'),

  sourceNote('Source: Defense.gov (official), https://www.defense.gov/News/News-Stories/Article/Article/4418826/hegseth-says-epic-fury-goals-in-iran-are-laser-focused/'),

  spokenText('"Months and years of deliberate planning." This wasn\'t a response to a specific provocation. This was a pre-planned, pre-positioned campaign. The intelligence had been gathered, the targets had been mapped, and the forces were in place — waiting for the order.'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('Hegseth\'s briefing that day laid out the objectives with unusual clarity: "Destroy Iranian offensive missiles, destroy Iranian missile production, destroy their navy and other security infrastructure, and they will never have nuclear weapons." Four objectives. All of them military. All of them requiring sustained operations — not a single strike, but a campaign.'),

  spokenText('And then March 4th. A U.S. submarine torpedoes an Iranian warship off the coast of Sri Lanka. The first submarine-launched torpedo attack since World War II. Think about that. The last time a U.S. submarine fired a torpedo in combat was in the 1940s. And now it happened again — in a war the White House would declare "terminated" two months later.'),

  sourceNote('Source: Politico, https://www.politico.com/news/2026/03/04/hegset-iran-war-just-begun-00811889'),

  divider(),

  segmentHeading('SEGMENT 2: THE CARRIER BUILD-UP'),

  stageDirection('IMAGE: Dashboard screenshot — Carrier Posture tab, all four carrier cards visible.'),

  spokenText('The carrier story is, in many ways, the story of this conflict. Because carriers don\'t lie. You can spin a press release. You can declare "terminated." But a 100,000-ton aircraft carrier sitting in the Arabian Sea is a fact. It\'s there. Everyone can see it. And it\'s not leaving because the White House said the war is over.'),

  spokenText('April 25th, 2026. For the first time since 2003 — since the invasion of Iraq — three U.S. aircraft carriers were operating simultaneously in the Middle East. The Abraham Lincoln, the George Washington, and the George H. W. Bush. Three strike groups. Hundreds of aircraft. Tens of thousands of sailors.'),

  sourceNote('Source: House of Saud, https://houseofsaud.com/three-carriers-middle-east-2026/'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('But here\'s the detail that matters: no U.S. carrier was publicly confirmed inside the Persian Gulf. All three operated in the Arabian Sea and the Gulf of Oman — outside the Gulf. Public reporting attributed this posture partly to the risk posed by Iranian mines and anti-ship missile systems in the Strait of Hormuz. The U.S. Navy wasn\'t willing to put a carrier inside the Gulf — the waterway was too dangerous, too narrow, too easy to mine.'),

  spokenText('So the most powerful navy in the history of the world, with three carriers in the region, couldn\'t put one inside the Persian Gulf. That tells you something about the threat environment. This isn\'t a permissive security situation. This is contested waters.'),

  divider(),

  segmentHeading('SEGMENT 3: THE CENTCOM STRIKE TIMELINE'),

  stageDirection('IMAGE: Dashboard screenshot — Military tracker, showing all 13 entries.'),

  spokenText('Let me walk you through the strike timeline. Because the pattern is revealing.'),

  spokenText('February 28th: Operation Epic Fury launches — 1,000+ targets in 24 hours. March 4th: submarine torpedo attack. April 13th: USS Abraham Lincoln enters the Gulf of Oman, 200 kilometers from the Iranian coast.'),

  spokenText('Then a gap. No documented strikes in May or June — during the exact period when the White House declared the war "terminated" and signed the MOU with Iran. But then July.'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('July 7th: CENTCOM completes a new round of retaliatory strikes. July 8th: CENTCOM completes another round. July 13th: CENTCOM completes new strikes on Iranian military targets. July 20th: CENTCOM finishes the latest strikes. July 23rd: the 13th night of precision strikes.'),

  sourceNote('Sources: CENTCOM (official), multiple releases at https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/'),

  spokenText('Four rounds of strikes in July. Plus a 13th night of precision strikes. This is not the behavior of a military that believes the war is over. This is sustained, systematic combat operations.'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('Then September. September 1st: CENTCOM strikes on IRGC targets — air defense systems, radar, maritime assets, mine-laying capabilities. September 5th: Iran targets two U.S. Navy warships. CENTCOM destroys three IRGC oil tankers in response. September 8th: Iran targets another American warship. The U.S. destroys five more IRGC tankers. Two exchanges of fire in one week.'),

  sourceNote('Sources: CENTCOM (official), https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/'),

  stageDirection('PAUSE — 3 seconds'),

  spokenText('Two exchanges of fire in one week. In a war that was "terminated" in May. Iran is shooting at U.S. warships. The U.S. is destroying Iranian tankers. This is active combat. There is no definition of "terminated" that includes two naval engagements in seven days.'),

  divider(),

  segmentHeading('SEGMENT 4: THE BLOCKADE'),

  stageDirection('IMAGE: Dashboard screenshot — Carrier Posture tab, regional posture note.'),

  spokenText('There\'s another dimension to this that doesn\'t get enough attention. The blockade.'),

  spokenText('According to the CENTCOM SASC Posture Statement for 2026 — the official posture statement delivered to the Senate Armed Services Committee — "United States air and naval forces continue to enforce a presidentially directed blockade against Iranian ports and merchant vessels while enabling neutral vessels to transit."'),

  sourceNote('Source: CENTCOM (official), https://www.centcom.mil/ABOUT-US/SASC-POSTURE-STATEMENT-2026/'),

  stageDirection('PAUSE — 3 seconds'),

  spokenText('A presidentially directed blockade. The United States Navy is blockading Iranian ports. Not a "maritime interdiction operation." Not a "quarantine." A blockade — the legal term for an act of war under international law.'),

  spokenText('And the scale is significant. CENTCOM reports that U.S. forces had redirected 91 commercial ships to ensure compliance with the blockade. Marines from the 31st Marine Expeditionary Unit boarded suspected violators — including the M/T Celestial Sea, an Iranian-flagged oil tanker, and the M/V Blue Star III, a commercial ship suspected of attempting to transit to Iran.'),

  spokenText('The U.S. maintains approximately 19 warships in the Arabian Sea enforcing this blockade. Nineteen warships. In a war that\'s "taken care of."'),

  divider(),

  segmentHeading('SEGMENT 5: THE ABRAHAM LINCOLN — 264 DAYS'),

  stageDirection('IMAGE: Dashboard screenshot — Carrier Posture tab, Lincoln card.'),

  spokenText('Let me tell you about the USS Abraham Lincoln.'),

  spokenText('The Lincoln deployed to the Middle East and spent 264 consecutive days at sea. No port calls. No breaks. Just continuous combat operations for nearly nine months. During that time, its air wing dropped over 1.5 million pounds of ordnance on Iranian targets.'),

  sourceNote('Source: USNI News Fleet Tracker, https://news.usni.org/2026/09/14/usni-news-fleet-and-marine-tracker-sept-14-2026'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('264 days. 1.5 million pounds of bombs. The Lincoln finally made a port visit to Thailand on September 2nd through 6th — its first port call in nearly nine months. Then it transited to the South China Sea, heading back to San Diego. Expected to arrive late September or early October.'),

  spokenText('The Navy has said it\'s applying lessons from the Lincoln deployment — supply shortages, morale issues, the toll of extended deployments — to the Theodore Roosevelt, which is preparing to relieve the George Washington. The Roosevelt is expected to deploy for seven or more months.'),

  spokenText('Seven months. That takes us into 2027. The Roosevelt hasn\'t even left San Diego yet, and it\'s already projected to be in the Arabian Sea through the spring of 2027. In a war that\'s "taken care of."'),

  divider(),

  segmentHeading('SEGMENT 6: FORWARD OUTLOOK — THE CARRIERS AREN\'T LEAVING'),

  stageDirection('IMAGE: Dashboard screenshot — Carrier Posture tab, Roosevelt card and regional note.'),

  spokenText('As of September 14th, 2026 — the latest USNI Fleet Tracker data — here\'s the carrier picture.'),

  spokenText('The USS George Washington is in the Arabian Sea, operating with Carrier Air Wing 5. It\'s conducting night flight operations. It\'s enforcing the blockade. It\'s providing cover for commercial vessels transiting the Strait of Hormuz.'),

  spokenText('The USS George H. W. Bush is also in the Arabian Sea. It\'s been in the region since April 2026. The second carrier in CENTCOM\'s area of responsibility.'),

  spokenText('The USS Abraham Lincoln is heading home — 264 days, 1.5 million pounds of ordnance, and one port call later.'),

  spokenText('And the USS Theodore Roosevelt is in San Diego, preparing to deploy. It\'s expected to depart in the coming weeks for the Arabian Sea, where it will relieve the George Washington. The deployment is expected to last seven or more months.'),

  sourceNote('Source: USNI News / Stripes, https://www.stripes.com/branches/navy/2026-09-09/navy-lincoln-roosevelt-ford-middle-east-iran-22796716.html'),

  stageDirection('PAUSE — 3 seconds'),

  spokenText('So the forward outlook is clear. Two carriers will remain in the Arabian Sea through the end of 2026. The Roosevelt will deploy for seven-plus months — taking us into 2027. The blockade continues. The strikes continue. The CENTCOM SASC Posture Statement confirms that U.S. forces maintain a "ready and resilient posture to deter aggression, defend U.S. forces, enable partners, and provide credible military power, when directed."'),

  sourceNote('Source: CENTCOM (official), https://www.centcom.mil/ABOUT-US/SASC-POSTURE-STATEMENT-2026/'),

  spokenText('"Credible military power." In a war that\'s "taken care of."'),

  spokenText('The carriers tell a story that the rhetoric can\'t obscure. They\'re the most visible, most undeniable evidence of the gap between declaratory policy and operational reality. You can spin a statement. You can issue a press release. But you can\'t hide a carrier strike group in the Arabian Sea.'),

  divider(),

  segmentHeading('CLOSING'),

  stageDirection('MUSIC: Theme returns. 10 seconds. Fade under.'),

  spokenText('In our final episode — Part 4, "The Reconciliation" — we\'ll bring it all together. The declaratory policy. The observed force posture. And the gap between them. We\'ll examine the Hegseth-Caine transcript in detail, hear from experts like former Defense Secretary Leon Panetta, and lay out what this means for American foreign policy and democratic accountability.'),

  spokenText('The full dashboard is linked in the show notes. Every carrier position, every strike, every source — verified and linked.'),

  stageDirection('IMAGE: Dashboard URL — https://iran-conflict-tracker.pplx.app'),

  spokenText('I\'m your host. This has been Mixed Messages, Part 3: Carriers and Combat. Thanks for listening.'),

  stageDirection('MUSIC: Theme swells. 15 seconds. Fade out.'),

  stageDirection('END OF EPISODE 3'),
];

// === EPISODE 4 SCRIPT ===
const ep4 = [
  ...episodeTitle('EPISODE 4: THE RECONCILIATION', 'Part 4 of the Mixed Messages Series — Series Finale', '35-40 minutes'),

  stageDirection('COLD OPEN — No music. Hard cut.'),

  spokenText('"We wouldn\'t want to set a definitive timeframe on that. But we are very much on plan."'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('"Each day we continue to attack deeper into Iranian territory. And the pressure will continue. In conclusion, we will continue major combat operations."'),

  stageDirection('PAUSE — 3 seconds'),

  spokenText('Those are the words of Secretary of War Pete Hegseth and General Dan Caine, Chairman of the Joint Chiefs of Staff, spoken at a Pentagon press briefing on March 19th, 2026. Official Defense Department transcript. On the record. For the world to see.'),

  spokenText('Five days later, the White House declared the war "terminated." And for the next five months, the gap between what the Pentagon said and what the White House said has only grown.'),

  stageDirection('MUSIC: Theme. 15 seconds. Fade under.'),

  stageDirection('IMAGE: Title card — "MIXED MESSAGES: The Reconciliation"'),

  spokenText('Welcome to the final episode of Mixed Messages. Over the past three episodes, we\'ve tracked the rhetorical shifts, the economic war, and the military operations. Today, in Part 4, we bring it all together. We\'re doing the reconciliation — the side-by-side analysis of what officials say versus what the government does, and what that gap means for American democracy.'),

  divider(),

  segmentHeading('SEGMENT 1: THE DECLARATORY POLICY'),

  stageDirection('IMAGE: Dashboard screenshot — Analysis tab, left column: "Declaratory Policy."'),

  spokenText('Let\'s start with what they say. The declaratory policy — the official, stated position of the United States government regarding the Iran conflict.'),

  spokenText('On May 1st, President Trump declared: "The hostilities that began on February 28, 2026, have terminated." Full stop. The war is over.'),

  sourceNote('Source: Reuters, https://www.reuters.com/world/asia-pacific/white-house-says-iran-war-terminated-war-powers-deadline-arrives-2026-05-01/'),

  spokenText('On May 5th, Secretary of State Marco Rubio said: "Operation Epic Fury is over. We achieved the objectives of that operation. We\'re now on to this Project Freedom."'),

  sourceNote('Source: State Department, https://www.state.gov'),

  spokenText('On June 19th, the White House announced: "President Donald J. Trump and Vice President JD Vance have secured a historic breakthrough by signing a Memorandum of Understanding with Iran."'),

  sourceNote('Source: White House (official), https://www.whitehouse.gov/releases/2026/06/president-trumps-iran-agreement-is-america-first-in-action/'),

  spokenText('On September 10th, Vice President Vance said: "The U.S. is not at war at all." And Trump called the conflict "small potatoes."'),

  sourceNote('Source: The Atlantic, https://www.theatlantic.com/national-security/2026/09/trump-iran-war-navy/688563/'),

  spokenText('On September 15th, Attorney General Todd Blanche said: "I disagree with that characterization, as does most of Congress."'),

  sourceNote('Source: CNN, https://transcripts.cnn.com/show/cnc/date/2026-09-15/segment/10'),

  spokenText('And on September 17th, Speaker Johnson said the nuclear issue is "taken care of," and Trump said: "Hopefully we\'re toward the end of the war. They want to make a deal."'),

  sourceNote('Source: CBS News, https://www.cbsnews.com/live-updates/iran-war-us-trump-oil-strait-of-hormuz/'),

  stageDirection('PAUSE — 3 seconds'),

  spokenText('That\'s the declaratory policy. Terminated. Achieved. Historic breakthrough. Not at war. Taken care of. Toward the end. A clear, consistent narrative: the war is over, the objectives were met, and we\'re moving on.'),

  divider(),

  segmentHeading('SEGMENT 2: THE OBSERVED FORCE POSTURE'),

  stageDirection('IMAGE: Dashboard screenshot — Analysis tab, middle column: "Observed Force Posture."'),

  spokenText('Now here\'s what they do. The observed force posture — the actual military and economic actions taken by the United States government during this same period.'),

  spokenText('Two aircraft carriers — the USS George Washington and the USS George H. W. Bush — are in the Arabian Sea as of September 14th. The USS Theodore Roosevelt is preparing to deploy for seven-plus months to relieve the George Washington — taking us into 2027.'),

  sourceNote('Source: USNI News Fleet Tracker, https://news.usni.org/2026/09/14/usni-news-fleet-and-marine-tracker-sept-14-2026'),

  spokenText('50,000 U.S. service members are deployed across the Middle East. The CENTCOM SASC Posture Statement confirms that U.S. forces "initiated Operation EPIC FURY at the direction of the President" and "continue to enforce a presidentially directed blockade against Iranian ports."'),

  sourceNote('Source: CENTCOM (official), https://www.centcom.mil/ABOUT-US/SASC-POSTURE-STATEMENT-2026/'),

  spokenText('CENTCOM has conducted active strikes on IRGC targets as recently as September 8th — including the destruction of 5 IRGC tankers after Iran targeted an American warship. Two exchanges of fire in one week.'),

  sourceNote('Source: CENTCOM (official), https://www.centcom.mil/MEDIA/PUBLIC-RELEASES/'),

  spokenText('The Treasury launched Operation Economic Outcast on August 24th — described as "an economic D-Day" — targeting five vital sectors: digital assets, technology, gold, aviation, and shipping.'),

  sourceNote('Source: Treasury (official), https://home.treasury.gov/news/press-releases/sb0613'),

  spokenText('And on September 18th — one day after Trump said "toward the end of the war" — the President signed H.R. 5334, the Lindsey O. Graham Sanctioning Russia and Iran Act of 2026, into law, extending and expanding statutory sanctions on Iran.'),

  sourceNote('Source: White House (official), https://www.whitehouse.gov/briefings-statements/2026/09/congressional-bill-h-r-5334-signed-into-law/'),

  stageDirection('PAUSE — 3 seconds'),

  spokenText('That\'s the observed force posture. Two carriers. 50,000 troops. Active strikes. A blockade. Economic war. Sanctions legislation. A clear, consistent reality: the war continues.'),

  divider(),

  segmentHeading('SEGMENT 3: THE HEGSETH-CAINE TRANSCRIPT — THE PENTAGON\'S OWN WORDS'),

  stageDirection('IMAGE: Dashboard screenshot — Conflict Matrix tab, "Use of Force" and "Duration" rows.'),

  spokenText('The single most important document in this entire analysis is the March 19th Hegseth-Caine press briefing transcript. It\'s an official Defense Department transcript — the Pentagon\'s own words, on the record, before the White House began its "terminated" narrative.'),

  spokenText('In that transcript, Hegseth says the objectives are "unchanged, on target and on plan." He says: "We wouldn\'t want to set a definitive timeframe on that." He says: "It will be at the president\'s choosing, ultimately, where we say, hey, we\'ve achieved what we need to." And he says: "So, no time set on that, but we\'re very much on track, absolutely."'),

  sourceNote('Source: Defense.gov transcript (official), https://www.defense.gov/News/Transcripts/Transcript/Article/4438625/'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('"No time set." "At the president\'s choosing." These are not the words of a military planning an exit. These are the words of a military settling in for an indefinite campaign.'),

  spokenText('And then Caine — the Chairman of the Joint Chiefs, the highest-ranking military officer in the United States — says: "Each day we continue to attack deeper into Iranian territory. And the pressure will continue. In conclusion, we will continue major combat operations."'),

  stageDirection('PAUSE — 3 seconds'),

  spokenText('"We will continue major combat operations." That\'s the Pentagon\'s position. Stated on March 19th. Never retracted. Never walked back. The White House declared the war "terminated" on May 1st — six weeks later — but the Pentagon has never contradicted Caine\'s statement. The strikes continued. The carriers remained. The blockade was enforced.'),

  spokenText('This is institutional awareness. The military knows the war continues. The Treasury knows the war continues. CENTCOM knows the war continues — they\'re conducting the strikes. The only people who say the war is over are in the White House and the Department of Justice.'),

  divider(),

  segmentHeading('SEGMENT 4: THE GAP ANALYSIS'),

  stageDirection('IMAGE: Dashboard screenshot — Analysis tab, right column: "The Gap."'),

  spokenText('So what\'s the gap? What\'s the distance between the declaratory policy and the observed force posture?'),

  spokenText('The gap is this: the rhetorical shift from "only just begun" on March 4th to "terminated" on May 1st to "not at war at all" on September 10th occurred while force levels remained constant or increased. The military didn\'t draw down. The carriers didn\'t come home. The strikes didn\'t stop. The sanctions didn\'t pause. The only thing that changed was the language.'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('Economic pressure escalated simultaneously with military de-escalation rhetoric. Operation Economic Outcast — the "economic D-Day" — was launched on August 24th, nearly four months after the White House declared the war "terminated." The Treasury Secretary compared it to D-Day. The President signed sanctions into law on September 18th. These are not the actions of a government that believes the conflict is "taken care of."'),

  spokenText('The Pentagon\'s own projections — the internal memo projecting operations through September, the CNO\'s statements about deployment extensions having no clear endpoint, the Hegseth-Caine transcript — all contradict the White House claims of resolution. This suggests an institutional awareness of a sustained conflict that the political leadership declines to acknowledge.'),

  spokenText('In other words: the government knows the war isn\'t over. The military knows. The Treasury knows. CENTCOM knows. Congress knows — they passed the sanctions legislation. The only people claiming the war is over are the President, the Vice President, and the Attorney General. And their claims are contradicted by every operational metric available.'),

  divider(),

  segmentHeading('SEGMENT 5: EXPERT ASSESSMENT — PANETTA\'S WARNING'),

  stageDirection('IMAGE: Quote card — Leon Panetta quote.'),

  spokenText('On September 6th, 2026, The Guardian published an interview with former Defense Secretary and CIA Director Leon Panetta. His assessment was blunt.'),

  spokenText('Panetta warned that the war was likely to continue for another six months — through March 2027 — absent a resolution. He pointed to the sustained carrier presence, the ongoing CENTCOM operations, and the gap between the administration\'s rhetoric and the reality on the ground.'),

  sourceNote('Source: The Guardian, https://www.theguardian.com/world/2026/sep/06/iran-war-trump-leon-panetta-interview'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('Six more months. Through March 2027. That\'s the forward outlook from a former Secretary of Defense who has access to the public data — the same data on our dashboard. Two carriers in the Arabian Sea. A third preparing to deploy for seven-plus months. CENTCOM conducting active strikes. A blockade in effect. Sanctions escalating. And a White House that says it\'s "taken care of."'),

  spokenText('Panetta\'s assessment aligns with the operational data. The Theodore Roosevelt deployment — seven-plus months — takes us into 2027. The sustained two-carrier presence has been maintained since April. The CENTCOM SASC Posture Statement describes a "ready and resilient posture" with no indication of drawdown. Everything points to continuation.'),

  divider(),

  segmentHeading('SEGMENT 6: WHAT THIS MEANS'),

  stageDirection('IMAGE: Dashboard screenshot — Full dashboard overview.'),

  spokenText('So what does all of this mean? What\'s the takeaway from four episodes of tracking the gap between what the government says and what it does?'),

  spokenText('First: the declaratory policy is irreconcilable with the observed force posture. You cannot say "terminated" while conducting strikes. You cannot say "not at war" while enforcing a blockade. You cannot say "taken care of" while signing sanctions into law. These are not matters of interpretation. They are facts.'),

  stageDirection('PAUSE — 2 seconds'),

  spokenText('Second: the gap is strategic, not accidental. The White House handles the political narrative. The Treasury handles the economic war. The Pentagon handles the military operations. They\'re operating on different tracks — one de-escalating rhetorically, the other two escalating operationally. This is a deliberate structure, not a communications failure.'),

  spokenText('Third: the operational reality will persist regardless of the declaratory policy. The carriers will remain. The strikes will continue. The sanctions will keep coming. The Roosevelt will deploy. The blockade will be enforced. Because the military and the Treasury are operating on their own timelines — not the White House\'s political timeline.'),

  stageDirection('PAUSE — 3 seconds'),

  spokenText('And fourth — and this is the one that matters most for our democracy: the gap between rhetoric and reality is a choice. The American people are being told the war is over. The military is conducting combat operations. The Treasury is waging economic war. Congress is passing sanctions legislation. And the public is left to figure out which version is real.'),

  spokenText('The data on our dashboard — 52 timeline events, 11 economic actions, 13 military operations, 4 carrier deployments, 25 analysis points — all sourced to official government publications and verified reporting — tells a clear story. The war is not over. The war continues. And the gap between what they say and what they do is the story of this conflict.'),

  divider(),

  segmentHeading('CLOSING'),

  stageDirection('MUSIC: Theme returns, fuller arrangement. 15 seconds. Fade under.'),

  spokenText('That brings us to the end of our Mixed Messages series on the Iran conflict. Over four episodes, we\'ve tracked the rhetorical arc from "only just begun" to "terminated" to "taken care of" — and mapped it against the operational reality of sustained carrier presence, CENTCOM strikes, economic warfare, and sanctions legislation.'),

  spokenText('The full dashboard — with all 52 timeline events, the conflict matrix, the economic and military trackers, the carrier posture data, and the reconciliation analysis — is live and linked in the show notes. Every quote is attributed. Every source is linked. Every claim is verified.'),

  stageDirection('IMAGE: Dashboard URL — https://iran-conflict-tracker.pplx.app'),

  spokenText('If this series has been valuable, please share it. The more people who understand the gap between rhetoric and reality, the better equipped we are as citizens to hold our government accountable.'),

  spokenText('I\'m your host. This has been Mixed Messages, Part 4: The Reconciliation. The series finale. Thank you for listening.'),

  stageDirection('MUSIC: Theme swells to full. 20 seconds. Fade out.'),

  stageDirection('END OF EPISODE 4 — END OF SERIES'),
];

// === BUILD DOCUMENT ===
const allContent = [
  // Cover page
  new Paragraph({
    spacing: { before: 2000, after: 200 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'MIXED MESSAGES', bold: true, size: 56, font: FONT_HEADING, color: COLOR_ACCENT })],
  }),
  new Paragraph({
    spacing: { before: 0, after: 100 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'The Iran Conflict', size: 36, font: FONT, color: '555555' })],
  }),
  new Paragraph({
    spacing: { before: 100, after: 400 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'A Four-Part Podcast Series Script', size: 24, font: FONT, color: COLOR_STAGE, italics: true })],
  }),
  new Paragraph({
    spacing: { before: 200, after: 100 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'Full Production Scripts with Stage Directions, Pauses,\nImage Cues, and Running Time Estimates', size: 22, font: FONT, color: COLOR_SOURCE })],
  }),
  new Paragraph({
    spacing: { before: 600, after: 100 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'Based on the Iran Conflict Policy Tracker Dashboard', size: 20, font: FONT, color: COLOR_SOURCE, italics: true })],
  }),
  new Paragraph({
    spacing: { before: 100, after: 100 },
    alignment: AlignmentType.CENTER,
    children: [
      new ExternalHyperlink({
        children: [new TextRun({ text: 'https://iran-conflict-tracker.pplx.app', style: 'Hyperlink', size: 20 })],
        link: 'https://iran-conflict-tracker.pplx.app',
      }),
    ],
  }),
  new Paragraph({
    spacing: { before: 400, after: 0 },
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: 'September 2026', size: 20, font: FONT, color: COLOR_STAGE })],
  }),
  new Paragraph({ pageBreakBefore: true, children: [] }),
  
  // Table of contents
  new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 200, after: 200 },
    children: [new TextRun({ text: 'Series Overview', bold: true, size: 36, font: FONT_HEADING, color: COLOR_ACCENT })],
  }),
  new Paragraph({
    spacing: { before: 100, after: 100, line: 360 },
    children: [new TextRun({ text: 'This four-part series tracks the gap between official U.S. government statements about the 2026 Iran conflict and the actual military, economic, and naval operations being conducted. Each episode runs 35-40 minutes and includes full spoken content, stage directions, pause cues, image insertion points, and source citations.', size: 22, font: FONT })],
  }),
  new Paragraph({ spacing: { before: 200, after: 100 }, children: [new TextRun({ text: 'Episode 1: The War That Isn\'t a War — White House rhetoric vs. operational reality', size: 22, font: FONT, bold: true })] }),
  new Paragraph({ spacing: { before: 60, after: 100 }, children: [new TextRun({ text: 'Episode 2: Economic D-Day — The sanctions and economic pressure campaign', size: 22, font: FONT, bold: true })] }),
  new Paragraph({ spacing: { before: 60, after: 100 }, children: [new TextRun({ text: 'Episode 3: Carriers and Combat — Military operations and naval posture', size: 22, font: FONT, bold: true })] }),
  new Paragraph({ spacing: { before: 60, after: 100 }, children: [new TextRun({ text: 'Episode 4: The Reconciliation — Side-by-side analysis and series finale', size: 22, font: FONT, bold: true })] }),

  // Episodes
  ...ep1,
  ...ep2,
  ...ep3,
  ...ep4,
];

const doc = new Document({
  styles: {
    default: { document: { run: { font: FONT, size: 24 } } },
    paragraphStyles: [
      {
        id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 36, bold: true, font: FONT_HEADING, color: COLOR_ACCENT },
        paragraph: { spacing: { before: 280, after: 140 }, outlineLevel: 0 },
      },
      {
        id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run: { size: 28, bold: true, font: FONT_HEADING, color: COLOR_ACCENT },
        paragraph: { spacing: { before: 220, after: 110 }, outlineLevel: 1 },
      },
    ],
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 },
      },
    },
    headers: {
      default: new Header({
        children: [new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({ text: 'Mixed Messages — Iran Conflict Series', italics: true, color: '999999', size: 16, font: FONT })],
        })],
      }),
    },
    footers: {
      default: new Footer({
        children: [new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({ text: 'Page ', size: 16, font: FONT, color: '999999' }),
            new TextRun({ children: [PageNumber.CURRENT], size: 16, font: FONT, color: '999999' }),
            new TextRun({ text: ' of ', size: 16, font: FONT, color: '999999' }),
            new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 16, font: FONT, color: '999999' }),
          ],
        })],
      }),
    },
    children: allContent,
  }],
});

(async () => {
  const buf = await Packer.toBuffer(doc);
  fs.writeFileSync('/home/user/workspace/iran-dashboard/podcast-scripts.docx', buf);
  console.log('DOCX generated successfully');
  console.log('Approximate word count:', allContent.length, 'paragraphs');
})();
